from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from flask_cors import CORS
from functools import wraps
import os
import logging
from datetime import datetime

logging.basicConfig(level=logging.DEBUG)

print("🚀 App wird gestartet...")

app = Flask(__name__)
app.secret_key = os.getenv('FLASK_SECRET_KEY', 'default_secret_key')

# Azure-kompatible Session-Konfiguration
os.makedirs('/tmp/sessions', exist_ok=True)

# CORS für Frontend-Kommunikation - erweitert für Azure
CORS(app, 
     supports_credentials=True, 
     origins=[
         'http://localhost:3000',
         'https://localhost:3000', 
         'http://192.168.50.99:3000',
         'http://localhost:3001',
         'https://localhost:3001',
         'http://192.168.50.99:3001',
         'https://la-zeiterfassung-fyd4cge3d9e3cac4.azurewebsites.net',
         'http://la-zeiterfassung-fyd4cge3d9e3cac4.azurewebsites.net',
         '*'
     ],
     allow_headers=['Content-Type', 'Authorization'],
     methods=['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'])

# Test-User (in Produktion: Datenbank)
TEST_USERS = {
    'monteur@test.com': {
        'password': 'test123',
        'name': 'Monteur Test',
        'role': 'Monteur'
    },
    'admin@test.com': {
        'password': 'test123',
        'name': 'Admin Test',
        'role': 'Admin'
    }
}

# Role-Decorator
def requires_role(role):
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            if 'user' not in session or session['user'].get('role') != role:
                flash('Zugriff verweigert.')
                return redirect('/login')
            return f(*args, **kwargs)
        return decorated
    return decorator

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        app.logger.debug(f"Login attempt: {email}")
        
        if email in TEST_USERS and TEST_USERS[email]['password'] == password:
            user_data = TEST_USERS[email]
            session['user'] = {
                'email': email,
                'name': user_data['name'],
                'role': user_data['role']
            }
            app.logger.debug(f"User logged in: {session['user']}")
            
            if user_data['role'] == 'Admin':
                return redirect('/buero')
            return redirect('/')
        flash('Ungültige Anmeldedaten')
    
    # Einfache HTML-Ausgabe statt render_template_string
    return """
    <!DOCTYPE html>
    <html lang="de">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Anmeldung - Zeiterfassung System</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                background-color: #f5f5f5;
                margin: 0;
                padding: 20px;
                display: flex;
                justify-content: center;
                align-items: center;
                min-height: 100vh;
            }
            .login-container {
                background: white;
                padding: 40px;
                border-radius: 10px;
                box-shadow: 0 4px 20px rgba(0,0,0,0.1);
                width: 100%;
                max-width: 400px;
            }
            .header {
                text-align: center;
                margin-bottom: 30px;
            }
            .form-group {
                margin-bottom: 20px;
            }
            label {
                display: block;
                margin-bottom: 5px;
                font-weight: bold;
                color: #333;
            }
            input[type="email"], input[type="password"] {
                width: 100%;
                padding: 12px;
                border: 2px solid #ddd;
                border-radius: 5px;
                font-size: 16px;
                box-sizing: border-box;
            }
            input[type="email"]:focus, input[type="password"]:focus {
                border-color: #0066b3;
                outline: none;
            }
            .login-btn {
                width: 100%;
                background: #0066b3;
                color: white;
                padding: 12px;
                border: none;
                border-radius: 5px;
                font-size: 16px;
                cursor: pointer;
                margin-top: 10px;
            }
            .login-btn:hover {
                background: #0052a3;
            }
            .demo-info {
                background: #e3f2fd;
                padding: 15px;
                border-radius: 5px;
                margin-top: 20px;
                font-size: 14px;
            }
        </style>
    </head>
    <body>
        <div class="login-container">
            <div class="header">
                <h1>🚀 Zeiterfassung System</h1>
                <h2>Lackner Aufzüge</h2>
            </div>
            
            <form method="POST" action="/login">
                <div class="form-group">
                    <label for="email">E-Mail:</label>
                    <input type="email" id="email" name="email" required>
                </div>
                
                <div class="form-group">
                    <label for="password">Passwort:</label>
                    <input type="password" id="password" name="password" required>
                </div>
                
                <button type="submit" class="login-btn">🔐 Anmelden</button>
            </form>
            
            <div class="demo-info">
                <h4>📋 Test-Anmeldedaten:</h4>
                <p><strong>Monteur:</strong><br>
                E-Mail: monteur@test.com<br>
                Passwort: test123</p>
                
                <p><strong>Administrator:</strong><br>
                E-Mail: admin@test.com<br>
                Passwort: test123</p>
            </div>
        </div>
    </body>
    </html>
    """

@app.route('/logout')
def logout():
    app.logger.debug(f"Logout: {session.get('user')}")
    session.clear()
    session.modified = True
    
    # Response mit explizitem Cookie-Löschen
    response = redirect('/login')
    response.delete_cookie('session', domain='.azurewebsites.net')
    response.delete_cookie('session', domain='la-zeiterfassung-fyd4cge3d9e3cac4.azurewebsites.net')
    response.delete_cookie('session')  # Ohne Domain
    return response

@app.route('/')
def index():
    app.logger.debug(f"Index route - Session: {session}")
    if 'user' not in session:
        return redirect('/login')
    if session['user'].get('role') == 'Admin':
        return redirect('/buero')
    # Monteur-Frontend
    user = session['user']
    today = datetime.now().strftime('%Y-%m-%d')
    return f"""
    <!DOCTYPE html>
    <html lang="de">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Monteur Dashboard - Zeiterfassung System</title>
        <style>
            body {{
                font-family: Arial, sans-serif;
                max-width: 800px;
                margin: 0 auto;
                padding: 20px;
                background-color: #f5f5f5;
            }}
            .container {{
                background: white;
                padding: 30px;
                border-radius: 10px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }}
            .header {{
                text-align: center;
                color: #2c3e50;
                margin-bottom: 30px;
            }}
            .user-info {{
                background: #e8f4fd;
                padding: 15px;
                border-radius: 5px;
                margin: 15px 0;
            }}
            .logout-btn {{
                background: #e74c3c;
                color: white;
                padding: 10px 20px;
                border: none;
                border-radius: 5px;
                cursor: pointer;
                text-decoration: none;
                display: inline-block;
                margin: 10px 0;
            }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>🚀 Monteur Dashboard</h1>
                <h2>Lackner Aufzüge</h2>
            </div>
            
            <div class="user-info">
                <h3>👤 Angemeldet als: {user['name']}</h3>
                <p><strong>E-Mail:</strong> {user['email']}</p>
                <p><strong>Rolle:</strong> {user['role']}</p>
                <a href="/logout" class="logout-btn">🚪 Abmelden</a>
            </div>
            
            <div class="status">
                <h3>✅ Monteur Dashboard</h3>
                <p>Willkommen im Monteur-Bereich!</p>
                <p><strong>Datum:</strong> {today}</p>
            </div>
        </div>
    </body>
    </html>
    """

@app.route('/buero')
@requires_role('Admin')
def buero():
    # Büro-Frontend
    user = session['user']
    return f"""
    <!DOCTYPE html>
    <html lang="de">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Büro Interface - Zeiterfassung System</title>
        <style>
            body {{
                font-family: Arial, sans-serif;
                max-width: 1200px;
                margin: 0 auto;
                padding: 20px;
                background-color: #f5f5f5;
            }}
            .container {{
                background: white;
                padding: 30px;
                border-radius: 10px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }}
            .header {{
                text-align: center;
                color: #2c3e50;
                margin-bottom: 30px;
                border-bottom: 3px solid #0066b3;
                padding-bottom: 20px;
            }}
            .user-info {{
                background: #e8f4fd;
                padding: 15px;
                border-radius: 5px;
                margin: 15px 0;
            }}
            .logout-btn {{
                background: #e74c3c;
                color: white;
                padding: 10px 20px;
                border: none;
                border-radius: 5px;
                cursor: pointer;
                text-decoration: none;
                display: inline-block;
                margin: 10px 0;
            }}
            .admin-section {{
                background: #f8f9fa;
                padding: 20px;
                border-radius: 8px;
                margin: 20px 0;
                border-left: 4px solid #0066b3;
            }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>🏢 Büro Interface</h1>
                <h2>Lackner Aufzüge - Administrationsbereich</h2>
            </div>
            
            <div class="user-info">
                <h3>👤 Administrator: {user['name']}</h3>
                <p><strong>E-Mail:</strong> {user['email']}</p>
                <p><strong>Rolle:</strong> {user['role']}</p>
                <a href="/logout" class="logout-btn">🚪 Abmelden</a>
            </div>
            
            <div class="admin-section">
                <h2>📊 Verwaltungsfunktionen</h2>
                <p>Hier können Sie alle Monteure und deren Daten verwalten, Aufträge zuordnen und das System administrieren.</p>
                
                <h3>🎯 Verfügbare Funktionen:</h3>
                <ul>
                    <li>👥 Monteur-Verwaltung</li>
                    <li>📋 Auftragsverwaltung</li>
                    <li>⏰ Zeiterfassung-Übersicht</li>
                    <li>📅 Urlaubsverwaltung</li>
                    <li>📈 Berichte & Statistiken</li>
                    <li>⚙️ System-Einstellungen</li>
                </ul>
            </div>
        </div>
    </body>
    </html>
    """

@app.route('/api/status')
def api_status():
    user = session.get('user', None)
    app.logger.debug(f"API Status - Session user: {user}")
    
    response_data = {
        'message': 'Zeiterfassung App läuft!',
        'status': 'success',
        'environment': 'Azure' if os.getenv('WEBSITE_HOSTNAME') else 'Local',
        'user': user
    }
    
    return jsonify(response_data)

@app.route('/health')
def health():
    return jsonify({
        'status': 'healthy',
        'message': 'App ist bereit'
    })

print("✅ App bereit für gunicorn")
