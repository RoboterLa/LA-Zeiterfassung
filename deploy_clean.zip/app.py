from flask import Flask, jsonify
import os

print("🚀 App wird gestartet...")

app = Flask(__name__)

@app.route('/')
def home():
    return jsonify({
        'message': 'Zeiterfassung App läuft!',
        'status': 'success',
        'environment': 'Azure' if os.getenv('WEBSITE_HOSTNAME') else 'Local'
    })

@app.route('/health')
def health():
    return jsonify({
        'status': 'healthy',
        'message': 'App ist bereit'
    })

print("✅ App bereit für gunicorn")
