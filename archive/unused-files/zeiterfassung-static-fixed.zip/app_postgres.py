from flask import Flask, request, jsonify, session, send_from_directory
from flask_cors import CORS
from datetime import datetime
import os
from database_postgres import PostgreSQLDatabase

app = Flask(__name__)
app.secret_key = 'zeiterfassung-secret-key-2025'
CORS(app, supports_credentials=True)

db = PostgreSQLDatabase()

@app.route('/health')
def health_check():
    return jsonify({
        'service': 'zeiterfassung-app',
        'status': 'healthy',
        'database': db.get_database_status(),
        'timestamp': datetime.now().isoformat()
    })

@app.route('/api/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    
    user = db.authenticate_user(username, password)
    if user:
        session['user_id'] = user['id']
        session['username'] = user['username']
        session['role'] = user['role']
        return jsonify({'success': True, 'user': user})
    else:
        return jsonify({'success': False, 'message': 'Ungültige Anmeldedaten'}), 401

@app.route('/api/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({'success': True})

@app.route('/api/time-entries', methods=['GET'])
def get_time_entries():
    user_id = session.get('user_id')
    entries = db.get_time_entries(user_id)
    return jsonify(entries)

@app.route('/api/time-entries', methods=['POST'])
def add_time_entry():
    data = request.get_json()
    user_id = session.get('user_id')
    
    result = db.add_time_entry(
        user_id=user_id,
        start_time=data.get('start_time'),
        end_time=data.get('end_time'),
        description=data.get('description'),
        order_id=data.get('order_id')
    )
    
    if result['success']:
        return jsonify(result)
    else:
        return jsonify(result), 400

@app.route('/api/time-entries/<int:entry_id>', methods=['PUT'])
def update_time_entry(entry_id):
    data = request.get_json()
    
    result = db.update_time_entry(
        entry_id=entry_id,
        end_time=data.get('end_time'),
        description=data.get('description')
    )
    
    if result['success']:
        return jsonify(result)
    else:
        return jsonify(result), 400

@app.route('/api/orders', methods=['GET'])
def get_orders():
    orders = db.get_orders()
    return jsonify(orders)

@app.route('/api/orders', methods=['POST'])
def add_order():
    data = request.get_json()
    
    result = db.add_order(
        order_number=data.get('order_number'),
        customer_name=data.get('customer_name'),
        description=data.get('description')
    )
    
    if result['success']:
        return jsonify(result)
    else:
        return jsonify(result), 400

@app.route('/api/emergencies', methods=['GET'])
def get_emergencies():
    emergencies = db.get_emergencies()
    return jsonify(emergencies)

@app.route('/api/emergencies', methods=['POST'])
def add_emergency():
    data = request.get_json()
    
    result = db.add_emergency(
        title=data.get('title'),
        description=data.get('description'),
        priority=data.get('priority', 'medium')
    )
    
    if result['success']:
        return jsonify(result)
    else:
        return jsonify(result), 400

# Frontend Routes
@app.route('/')
def serve_frontend():
    return send_from_directory('build', 'index.html')

@app.route('/static/<path:path>')
def serve_static_files(path):
    return send_from_directory('build/static', path)

@app.route('/favicon.ico')
def serve_favicon():
    return send_from_directory('build', 'favicon.ico')

@app.route('/manifest.json')
def serve_manifest():
    return send_from_directory('build', 'manifest.json')

@app.route('/logo192.png')
def serve_logo192():
    return send_from_directory('build', 'logo192.png')

@app.route('/logo512.png')
def serve_logo512():
    return send_from_directory('build', 'logo512.png')

@app.route('/<path:path>')
def serve_static(path):
    return send_from_directory('build', path)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000) 