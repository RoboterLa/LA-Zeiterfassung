import pyodbc
import os
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

class AzureDatabase:
    def __init__(self):
        self.connection_string = self._get_connection_string()
        self.init_database()
    
    def _get_connection_string(self):
        """Get connection string from environment or use default"""
        # Azure SQL Database Connection String
        server = os.environ.get('AZURE_SQL_SERVER', 'zeiterfassung-sql.database.windows.net')
        database = os.environ.get('AZURE_SQL_DATABASE', 'zeiterfassung-db')
        username = os.environ.get('AZURE_SQL_USERNAME', 'sqladmin@zeiterfassung-sql')
        password = os.environ.get('AZURE_SQL_PASSWORD', '')
        
        if not password:
            logger.warning("AZURE_SQL_PASSWORD not set, using mock data")
            return None
        
        return f"Driver={{ODBC Driver 17 for SQL Server}};Server=tcp:{server},1433;Database={database};Uid={username};Pwd={password};Encrypt=yes;TrustServerCertificate=no;"
    
    def get_connection(self):
        """Get database connection"""
        if not self.connection_string:
            raise Exception("Database connection not configured")
        
        try:
            return pyodbc.connect(self.connection_string)
        except Exception as e:
            logger.error(f"Database connection failed: {e}")
            raise
    
    def init_database(self):
        """Initialize database tables"""
        if not self.connection_string:
            logger.info("Using mock data (no database connection)")
            return
        
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            # Create users table
            cursor.execute('''
                IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='users' AND xtype='U')
                CREATE TABLE users (
                    id INT IDENTITY(1,1) PRIMARY KEY,
                    email VARCHAR(100) UNIQUE NOT NULL,
                    password VARCHAR(100) NOT NULL,
                    name VARCHAR(100) NOT NULL,
                    role VARCHAR(50) NOT NULL,
                    created_at DATETIME DEFAULT GETDATE()
                )
            ''')
            
            # Create time_entries table
            cursor.execute('''
                IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='time_entries' AND xtype='U')
                CREATE TABLE time_entries (
                    id INT IDENTITY(1,1) PRIMARY KEY,
                    user_id INT FOREIGN KEY REFERENCES users(id),
                    clock_in DATETIME,
                    clock_out DATETIME,
                    location VARCHAR(255),
                    notes TEXT,
                    created_at DATETIME DEFAULT GETDATE()
                )
            ''')
            
            # Create orders table
            cursor.execute('''
                IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='orders' AND xtype='U')
                CREATE TABLE orders (
                    id INT IDENTITY(1,1) PRIMARY KEY,
                    title VARCHAR(255) NOT NULL,
                    description TEXT,
                    customer VARCHAR(255),
                    location VARCHAR(255),
                    order_type VARCHAR(50),
                    priority VARCHAR(50),
                    status VARCHAR(50),
                    assigned_to INT FOREIGN KEY REFERENCES users(id),
                    created_date DATE,
                    due_date DATE,
                    created_at DATETIME DEFAULT GETDATE()
                )
            ''')
            
            # Create emergencies table
            cursor.execute('''
                IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='emergencies' AND xtype='U')
                CREATE TABLE emergencies (
                    id INT IDENTITY(1,1) PRIMARY KEY,
                    title VARCHAR(255) NOT NULL,
                    description TEXT,
                    location VARCHAR(255),
                    priority VARCHAR(50),
                    status VARCHAR(50),
                    assigned_to INT FOREIGN KEY REFERENCES users(id),
                    reported_at DATETIME,
                    created_at DATETIME DEFAULT GETDATE()
                )
            ''')
            
            # Insert default users if they don't exist
            cursor.execute('''
                IF NOT EXISTS (SELECT * FROM users WHERE email = 'monteur')
                INSERT INTO users (email, password, name, role) VALUES 
                ('monteur', 'monteur', 'Monteur', 'monteur'),
                ('buero', 'buero', 'Büro', 'buero')
            ''')
            
            conn.commit()
            conn.close()
            logger.info("Database initialized successfully")
            
        except Exception as e:
            logger.error(f"Database initialization failed: {e}")
            # Fall back to mock data
            self.connection_string = None
    
    def get_user_by_credentials(self, email, password):
        """Authenticate user"""
        if not self.connection_string:
            # Fall back to mock data
            mock_users = [
                {'id': 1, 'email': 'monteur', 'password': 'monteur', 'name': 'Monteur', 'role': 'monteur'},
                {'id': 2, 'email': 'buero', 'password': 'buero', 'name': 'Büro', 'role': 'buero'}
            ]
            return next((u for u in mock_users if u['email'] == email and u['password'] == password), None)
        
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('SELECT id, email, password, name, role FROM users WHERE email = ? AND password = ?', (email, password))
            row = cursor.fetchone()
            conn.close()
            
            if row:
                return {
                    'id': row[0],
                    'email': row[1],
                    'password': row[2],
                    'name': row[3],
                    'role': row[4]
                }
            return None
            
        except Exception as e:
            logger.error(f"Database query failed: {e}")
            return None
    
    def get_user_by_id(self, user_id):
        """Get user by ID"""
        if not self.connection_string:
            # Fall back to mock data
            mock_users = [
                {'id': 1, 'email': 'monteur', 'password': 'monteur', 'name': 'Monteur', 'role': 'monteur'},
                {'id': 2, 'email': 'buero', 'password': 'buero', 'name': 'Büro', 'role': 'buero'}
            ]
            return next((u for u in mock_users if u['id'] == user_id), None)
        
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('SELECT id, email, password, name, role FROM users WHERE id = ?', (user_id,))
            row = cursor.fetchone()
            conn.close()
            
            if row:
                return {
                    'id': row[0],
                    'email': row[1],
                    'password': row[2],
                    'name': row[3],
                    'role': row[4]
                }
            return None
            
        except Exception as e:
            logger.error(f"Database query failed: {e}")
            return None
    
    def get_time_entries(self, user_id):
        """Get time entries for user"""
        if not self.connection_string:
            # Fall back to mock data
            return [
                {'id': 1, 'user_id': 1, 'clock_in': '08:00:00', 'clock_out': '17:00:00', 'location': 'Hauptstraße 15, München', 'notes': 'Wartung Aufzug'},
                {'id': 2, 'user_id': 1, 'clock_in': '07:30:00', 'clock_out': None, 'location': 'Marienplatz 1, München', 'notes': 'Reparatur'}
            ]
        
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('''
                SELECT id, user_id, clock_in, clock_out, location, notes 
                FROM time_entries 
                WHERE user_id = ? 
                ORDER BY created_at DESC
            ''', (user_id,))
            
            entries = []
            for row in cursor.fetchall():
                entries.append({
                    'id': row[0],
                    'user_id': row[1],
                    'clock_in': row[2].strftime('%H:%M:%S') if row[2] else None,
                    'clock_out': row[3].strftime('%H:%M:%S') if row[3] else None,
                    'location': row[4],
                    'notes': row[5]
                })
            
            conn.close()
            return entries
            
        except Exception as e:
            logger.error(f"Database query failed: {e}")
            return []
    
    def create_time_entry(self, user_id, clock_in, location):
        """Create new time entry"""
        if not self.connection_string:
            return {'success': True, 'message': 'Mock time entry created'}
        
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO time_entries (user_id, clock_in, location) 
                VALUES (?, ?, ?)
            ''', (user_id, clock_in, location))
            conn.commit()
            conn.close()
            return {'success': True, 'message': 'Time entry created'}
            
        except Exception as e:
            logger.error(f"Database insert failed: {e}")
            return {'success': False, 'error': str(e)}
    
    def update_time_entry(self, entry_id, clock_out, notes):
        """Update time entry with clock out"""
        if not self.connection_string:
            return {'success': True, 'message': 'Mock time entry updated'}
        
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE time_entries 
                SET clock_out = ?, notes = ? 
                WHERE id = ?
            ''', (clock_out, notes, entry_id))
            conn.commit()
            conn.close()
            return {'success': True, 'message': 'Time entry updated'}
            
        except Exception as e:
            logger.error(f"Database update failed: {e}")
            return {'success': False, 'error': str(e)}
    
    def get_orders(self, user_id=None):
        """Get orders (all or for specific user)"""
        if not self.connection_string:
            # Fall back to mock data
            return [
                {'id': 1, 'title': 'Wartung Aufzug Hauptstraße 15', 'description': 'Regelmäßige Wartung', 'customer': 'Gebäudeverwaltung München', 'location': 'Hauptstraße 15, München', 'order_type': 'maintenance', 'priority': 'normal', 'status': 'assigned', 'assigned_to': 1, 'created_date': '2025-01-20', 'due_date': '2025-01-25'},
                {'id': 2, 'title': 'Reparatur Aufzug Marienplatz', 'description': 'Dringende Reparatur', 'customer': 'Stadt München', 'location': 'Marienplatz 1, München', 'order_type': 'repair', 'priority': 'urgent', 'status': 'in_progress', 'assigned_to': 1, 'created_date': '2025-01-19', 'due_date': '2025-01-22'}
            ]
        
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            
            if user_id:
                cursor.execute('''
                    SELECT id, title, description, customer, location, order_type, priority, status, assigned_to, created_date, due_date
                    FROM orders 
                    WHERE assigned_to = ?
                    ORDER BY created_at DESC
                ''', (user_id,))
            else:
                cursor.execute('''
                    SELECT id, title, description, customer, location, order_type, priority, status, assigned_to, created_date, due_date
                    FROM orders 
                    ORDER BY created_at DESC
                ''')
            
            orders = []
            for row in cursor.fetchall():
                orders.append({
                    'id': row[0],
                    'title': row[1],
                    'description': row[2],
                    'customer': row[3],
                    'location': row[4],
                    'order_type': row[5],
                    'priority': row[6],
                    'status': row[7],
                    'assigned_to': row[8],
                    'created_date': row[9].strftime('%Y-%m-%d') if row[9] else None,
                    'due_date': row[10].strftime('%Y-%m-%d') if row[10] else None
                })
            
            conn.close()
            return orders
            
        except Exception as e:
            logger.error(f"Database query failed: {e}")
            return []
    
    def create_order(self, order_data):
        """Create new order"""
        if not self.connection_string:
            return {'success': True, 'message': 'Mock order created'}
        
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO orders (title, description, customer, location, order_type, priority, status, assigned_to, created_date, due_date)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                order_data['title'],
                order_data.get('description'),
                order_data.get('customer'),
                order_data['location'],
                order_data.get('order_type', 'maintenance'),
                order_data.get('priority', 'normal'),
                order_data.get('status', 'new'),
                order_data.get('assigned_to'),
                order_data.get('created_date', datetime.now().strftime('%Y-%m-%d')),
                order_data.get('due_date')
            ))
            conn.commit()
            conn.close()
            return {'success': True, 'message': 'Order created'}
            
        except Exception as e:
            logger.error(f"Database insert failed: {e}")
            return {'success': False, 'error': str(e)}
    
    def get_emergencies(self):
        """Get all emergencies"""
        if not self.connection_string:
            # Fall back to mock data
            return [
                {'id': 1, 'title': 'Aufzug steckt fest', 'description': 'Aufzug ist stecken geblieben', 'location': 'Marienplatz 1, München', 'priority': 'urgent', 'status': 'active', 'assigned_to': 1, 'reported_at': '2025-01-20 10:30:00'}
            ]
        
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('''
                SELECT id, title, description, location, priority, status, assigned_to, reported_at
                FROM emergencies 
                ORDER BY created_at DESC
            ''')
            
            emergencies = []
            for row in cursor.fetchall():
                emergencies.append({
                    'id': row[0],
                    'title': row[1],
                    'description': row[2],
                    'location': row[3],
                    'priority': row[4],
                    'status': row[5],
                    'assigned_to': row[6],
                    'reported_at': row[7].strftime('%Y-%m-%d %H:%M:%S') if row[7] else None
                })
            
            conn.close()
            return emergencies
            
        except Exception as e:
            logger.error(f"Database query failed: {e}")
            return []
    
    def create_emergency(self, emergency_data):
        """Create new emergency"""
        if not self.connection_string:
            return {'success': True, 'message': 'Mock emergency created'}
        
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO emergencies (title, description, location, priority, status, assigned_to, reported_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (
                emergency_data['title'],
                emergency_data.get('description'),
                emergency_data['location'],
                emergency_data.get('priority', 'normal'),
                emergency_data.get('status', 'active'),
                emergency_data.get('assigned_to'),
                emergency_data.get('reported_at', datetime.now())
            ))
            conn.commit()
            conn.close()
            return {'success': True, 'message': 'Emergency created'}
            
        except Exception as e:
            logger.error(f"Database insert failed: {e}")
            return {'success': False, 'error': str(e)} 