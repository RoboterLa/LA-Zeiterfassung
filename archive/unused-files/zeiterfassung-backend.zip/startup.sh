#!/bin/bash
cd /home/site/wwwroot
python app.py 