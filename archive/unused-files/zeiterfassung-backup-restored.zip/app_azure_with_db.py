from flask import Flask, request, jsonify, session, send_from_directory
from flask_cors import CORS
from datetime import datetime
import os
from database_azure import AzureDatabase

app = Flask(__name__)
app.secret_key = 'zeiterfassung-secret-key-2025'
CORS(app, supports_credentials=True)

# Initialize Azure Database
db = AzureDatabase()

@app.route('/health')
def health_check():
    return jsonify({
        'service': 'zeiterfassung-app',
        'status': 'healthy',
        'database': 'connected' if db.connection_string else 'mock',
        'timestamp': datetime.now().isoformat()
    })

@app.route('/api/auth/login', methods=['POST'])
def login():
    try:
        data = request.get_json()
        email = data.get('email')
        password = data.get('password')
        
        if not email or not password:
            return jsonify({'success': False, 'error': 'Email und Passwort erforderlich'}), 400
        
        user = db.get_user_by_credentials(email, password)
        
        if user:
            session['user_id'] = user['id']
            session['user_role'] = user['role']
            return jsonify({
                'success': True,
                'message': 'Erfolgreich angemeldet',
                'user': {k: v for k, v in user.items() if k != 'password'}
            })
        else:
            return jsonify({'success': False, 'error': 'Ungültige Anmeldedaten'}), 401
            
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/auth/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({'success': True, 'message': 'Erfolgreich abgemeldet'})

@app.route('/api/auth/me')
def get_current_user():
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({'success': False, 'error': 'Nicht angemeldet'}), 401
    
    try:
        user = db.get_user_by_id(user_id)
        
        if user:
            return jsonify({
                'success': True,
                'user': {k: v for k, v in user.items() if k != 'password'}
            })
        else:
            return jsonify({'success': False, 'error': 'Benutzer nicht gefunden'}), 404
            
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/monteur/time-entries')
def get_time_entries():
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({'success': False, 'error': 'Nicht angemeldet'}), 401
    
    try:
        entries = db.get_time_entries(user_id)
        return jsonify({
            'success': True,
            'time_entries': entries
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/monteur/clock-in', methods=['POST'])
def clock_in():
    try:
        data = request.get_json()
        location = data.get('location', 'Standort')
        user_id = session.get('user_id')
        
        if not user_id:
            return jsonify({'success': False, 'error': 'Nicht angemeldet'}), 401
        
        clock_in_time = datetime.now()
        result = db.create_time_entry(user_id, clock_in_time, location)
        
        if result['success']:
            return jsonify({
                'success': True,
                'message': f'Erfolgreich eingestempelt um {clock_in_time.strftime("%H:%M")}',
                'location': location
            })
        else:
            return jsonify({'success': False, 'error': result.get('error', 'Unbekannter Fehler')}), 500
            
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/monteur/clock-out', methods=['POST'])
def clock_out():
    try:
        data = request.get_json()
        notes = data.get('notes', '')
        user_id = session.get('user_id')
        
        if not user_id:
            return jsonify({'success': False, 'error': 'Nicht angemeldet'}), 401
        
        # Get latest time entry for user
        entries = db.get_time_entries(user_id)
        if not entries or entries[0].get('clock_out'):
            return jsonify({'success': False, 'error': 'Kein aktiver Zeiteintrag gefunden'}), 400
        
        latest_entry = entries[0]
        clock_out_time = datetime.now()
        result = db.update_time_entry(latest_entry['id'], clock_out_time, notes)
        
        if result['success']:
            return jsonify({
                'success': True,
                'message': f'Erfolgreich ausgestempelt um {clock_out_time.strftime("%H:%M")}',
                'notes': notes
            })
        else:
            return jsonify({'success': False, 'error': result.get('error', 'Unbekannter Fehler')}), 500
            
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/monteur/current-status')
def get_current_status():
    try:
        user_id = session.get('user_id')
        if not user_id:
            return jsonify({'success': False, 'error': 'Nicht angemeldet'}), 401
        
        entries = db.get_time_entries(user_id)
        is_working = False
        
        if entries and not entries[0].get('clock_out'):
            is_working = True
        
        return jsonify({
            'success': True,
            'is_working': is_working,
            'current_time': datetime.now().strftime("%H:%M:%S")
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/monteur/orders')
def get_monteur_orders():
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({'success': False, 'error': 'Nicht angemeldet'}), 401
    
    try:
        orders = db.get_orders(user_id)
        return jsonify({
            'success': True,
            'orders': orders
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/monteur/orders/<int:order_id>/status', methods=['PUT'])
def update_order_status(order_id):
    try:
        data = request.get_json()
        new_status = data.get('status')
        
        # TODO: Implement order status update in database
        return jsonify({
            'success': True,
            'message': f'Auftrag {order_id} Status auf {new_status} geändert'
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/buero/orders')
def get_all_orders():
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({'success': False, 'error': 'Nicht angemeldet'}), 401
    
    try:
        orders = db.get_orders()  # Get all orders
        return jsonify({
            'success': True,
            'orders': orders
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/buero/orders', methods=['POST'])
def create_order():
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['title', 'location']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'success': False, 'error': f'{field} ist erforderlich'}), 400
        
        result = db.create_order(data)
        
        if result['success']:
            return jsonify({
                'success': True,
                'message': 'Auftrag erfolgreich erstellt'
            })
        else:
            return jsonify({'success': False, 'error': result.get('error', 'Unbekannter Fehler')}), 500
            
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/buero/emergencies')
def get_emergencies():
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({'success': False, 'error': 'Nicht angemeldet'}), 401
    
    try:
        emergencies = db.get_emergencies()
        return jsonify({
            'success': True,
            'emergencies': emergencies
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/buero/emergencies', methods=['POST'])
def create_emergency():
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['title', 'location']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'success': False, 'error': f'{field} ist erforderlich'}), 400
        
        result = db.create_emergency(data)
        
        if result['success']:
            return jsonify({
                'success': True,
                'message': 'Notfall erfolgreich erstellt'
            })
        else:
            return jsonify({'success': False, 'error': result.get('error', 'Unbekannter Fehler')}), 500
            
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/buero/customers')
def get_customers():
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({'success': False, 'error': 'Nicht angemeldet'}), 401
    
    try:
        customers = [
            {'id': 1, 'name': 'Gebäudeverwaltung München', 'contact': 'Herr Meyer', 'phone': '089-123456'},
            {'id': 2, 'name': 'Stadt München', 'contact': 'Frau Schmidt', 'phone': '089-654321'},
            {'id': 3, 'name': 'Bauprojekt GmbH', 'contact': 'Herr Weber', 'phone': '089-789123'}
        ]
        return jsonify({
            'success': True,
            'customers': customers
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/buero/users')
def get_users():
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({'success': False, 'error': 'Nicht angemeldet'}), 401
    
    try:
        # Get all users from database
        users = []
        if db.connection_string:
            try:
                conn = db.get_connection()
                cursor = conn.cursor()
                cursor.execute('SELECT id, name, role FROM users')
                for row in cursor.fetchall():
                    users.append({
                        'id': row[0],
                        'name': row[1],
                        'role': row[2]
                    })
                conn.close()
            except Exception as e:
                logger.error(f"Failed to get users from database: {e}")
                # Fall back to mock data
                users = [
                    {'id': 1, 'name': 'Monteur', 'role': 'monteur'},
                    {'id': 2, 'name': 'Büro', 'role': 'buero'}
                ]
        else:
            # Mock data
            users = [
                {'id': 1, 'name': 'Monteur', 'role': 'monteur'},
                {'id': 2, 'name': 'Büro', 'role': 'buero'}
            ]
        
        return jsonify({
            'success': True,
            'users': users
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

# Frontend Routes
@app.route('/static/<path:filename>')
def serve_static_files(filename):
    return send_from_directory('build/static', filename)

@app.route('/static/js/<path:filename>')
def serve_js_files(filename):
    return send_from_directory('build/static/js', filename)

@app.route('/static/css/<path:filename>')
def serve_css_files(filename):
    return send_from_directory('build/static/css', filename)

@app.route('/favicon.ico')
def serve_favicon():
    return send_from_directory('build', 'favicon.ico')

@app.route('/manifest.json')
def serve_manifest():
    return send_from_directory('build', 'manifest.json')

@app.route('/logo192.png')
def serve_logo192():
    return send_from_directory('build', 'logo192.png')

@app.route('/logo512.png')
def serve_logo512():
    return send_from_directory('build', 'logo512.png')

@app.route('/')
def serve_frontend():
    return send_from_directory('build', 'index.html')

@app.route('/<path:path>')
def serve_react_routes(path):
    # Alle anderen Pfade zur index.html für React Router
    return send_from_directory('build', 'index.html')

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 8080))
    app.run(host='0.0.0.0', port=port, debug=False) 