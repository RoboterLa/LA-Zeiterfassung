# Azure Portal Deployment Instructions

## 1. Environment Variables im Azure Portal setzen:

Gehe zu: Azure Portal > LA-Zeiterfassung > Configuration > Application settings

Setze folgende Environment Variables:

- FLASK_ENV = production
- DATABASE_URL = sqlite:///zeiterfassung.db
- CLIENT_ID = bce7f739-d799-4c57-8758-7b6b21999678
- CLIENT_SECRET = eKN8Q~dojyFDd2Bdt8BSiHVVapJuko3bgqbvhcOr
- SECRET_KEY = [generiere einen zufälligen String]
- PYTHON_VERSION = 3.11
- SCM_DO_BUILD_DURING_DEPLOYMENT = true

## 2. Deployment Package hochladen:

1. Gehe zu: Azure Portal > LA-Zeiterfassung > Deployment Center
2. Wähle "Manual deployment"
3. Lade diese ZIP-Datei hoch
4. Klicke auf "Deploy"

## 3. Nach dem Deployment:

1. Gehe zu: Azure Portal > LA-Zeiterfassung > Restart
2. Warte 2-3 Minuten
3. Teste die URL: https://la-zeiterfassung-fyd4cge3d9e3cac4.germanywestcentral-01.azurewebsites.net/

## 4. Migration ausführen:

Nach dem ersten Start, führe die Migration aus:
POST https://la-zeiterfassung-fyd4cge3d9e3cac4.germanywestcentral-01.azurewebsites.net/migrate
