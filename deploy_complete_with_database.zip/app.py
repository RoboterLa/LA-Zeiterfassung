from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from flask_cors import CORS
from functools import wraps
import os
import logging
import sqlite3
import csv
import uuid
from datetime import datetime, timedelta
import json

logging.basicConfig(level=logging.DEBUG)

print("🚀 App wird gestartet...")

app = Flask(__name__)
app.secret_key = os.getenv('FLASK_SECRET_KEY', 'default_secret_key')

# Azure-kompatible Session-Konfiguration
os.makedirs('/tmp/sessions', exist_ok=True)

# CORS für Frontend-Kommunikation - erweitert für Azure
CORS(app, 
     supports_credentials=True, 
     origins=[
         'http://localhost:3000',
         'https://localhost:3000', 
         'http://192.168.50.99:3000',
         'http://localhost:3001',
         'https://localhost:3001',
         'http://192.168.50.99:3001',
         'https://la-zeiterfassung-fyd4cge3d9e3cac4.azurewebsites.net',
         'http://la-zeiterfassung-fyd4cge3d9e3cac4.azurewebsites.net',
         '*'
     ],
     allow_headers=['Content-Type', 'Authorization'],
     methods=['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'])

# Test-User (in Produktion: Datenbank)
TEST_USERS = {
    'monteur@test.com': {
        'password': 'test123',
        'name': 'Monteur Test',
        'role': 'Monteur'
    },
    'admin@test.com': {
        'password': 'test123',
        'name': 'Admin Test',
        'role': 'Admin'
    }
}

# Datenbank-Funktionen
def get_db_connection():
    conn = sqlite3.connect('zeiterfassung.db')
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Aufträge Tabelle
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS auftraege (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            art TEXT NOT NULL,
            uhrzeit TEXT NOT NULL,
            standort TEXT NOT NULL,
            coords TEXT,
            details TEXT,
            done BOOLEAN DEFAULT FALSE,
            priority TEXT DEFAULT 'normal',
            mitarbeiter TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Zeiterfassung Tabelle
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS zeiterfassung (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            elevator_id TEXT,
            location TEXT,
            date TEXT NOT NULL,
            activity_type TEXT NOT NULL,
            start_time TEXT NOT NULL,
            end_time TEXT,
            emergency_week BOOLEAN DEFAULT FALSE,
            notes TEXT,
            status TEXT DEFAULT 'pending',
            mitarbeiter TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Arbeitszeit Tabelle
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS arbeitszeit (
            id TEXT PRIMARY KEY,
            datum TEXT NOT NULL,
            start TEXT NOT NULL,
            stop TEXT,
            dauer TEXT,
            notdienstwoche BOOLEAN DEFAULT FALSE,
            quelle TEXT DEFAULT 'manuell',
            bemerkung TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Urlaub Tabelle
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS urlaub (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            start_date TEXT NOT NULL,
            end_date TEXT NOT NULL,
            reason TEXT,
            status TEXT DEFAULT 'pending',
            mitarbeiter TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Test-Daten einfügen
    cursor.execute('SELECT COUNT(*) FROM auftraege')
    if cursor.fetchone()[0] == 0:
        test_auftraege = [
            ('Reparatur', '09:00', 'Hauptbahnhof, München', '[]', 'Aufzug klemmt, Notruf ausgelöst', False, 'high'),
            ('Wartung', '10:30', 'Sendlinger Tor, München', '[]', 'Regelmäßige Wartung, Ölwechsel', False, 'normal'),
            ('Notdienst', '14:00', 'Krankenhaus, Salzburg', '[]', 'Aufzug steckt fest', False, 'critical'),
            ('Reparatur', '16:00', 'Bürogebäude, Wien', '[]', 'Tür klemmt', True, 'normal'),
            ('Wartung', '08:00', 'Einkaufszentrum, Graz', '[]', 'Monatliche Inspektion', False, 'normal')
        ]
        cursor.executemany('''
            INSERT INTO auftraege (art, uhrzeit, standort, coords, details, done, priority)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', test_auftraege)
    
    cursor.execute('SELECT COUNT(*) FROM zeiterfassung')
    if cursor.fetchone()[0] == 0:
        test_zeiterfassung = [
            ('E001', 'Hauptbahnhof, München', '2025-07-29', 'Wartung', '08:00', '12:00', False, 'Regelmäßige Wartung', 'completed'),
            ('E002', 'Sendlinger Tor, München', '2025-07-29', 'Reparatur', '13:00', '17:00', False, 'Tür klemmt', 'pending'),
            ('E003', 'Krankenhaus, Salzburg', '2025-07-30', 'Notdienst', '09:00', '11:00', True, 'Dringender Notruf', 'pending')
        ]
        cursor.executemany('''
            INSERT INTO zeiterfassung (elevator_id, location, date, activity_type, start_time, end_time, emergency_week, notes, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', test_zeiterfassung)
    
    cursor.execute('SELECT COUNT(*) FROM arbeitszeit')
    if cursor.fetchone()[0] == 0:
        test_arbeitszeit = [
            (str(uuid.uuid4()), '2025-07-29', '08:00', '17:00', '9:00', False, 'manuell', 'Vollzeit'),
            (str(uuid.uuid4()), '2025-07-28', '08:30', '16:30', '8:00', False, 'manuell', 'Normalarbeit'),
            (str(uuid.uuid4()), '2025-07-27', '09:00', '18:00', '9:00', True, 'manuell', 'Überstunden')
        ]
        cursor.executemany('''
            INSERT INTO arbeitszeit (id, datum, start, stop, dauer, notdienstwoche, quelle, bemerkung)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', test_arbeitszeit)
    
    cursor.execute('SELECT COUNT(*) FROM urlaub')
    if cursor.fetchone()[0] == 0:
        test_urlaub = [
            ('2025-08-15', '2025-08-20', 'Sommerurlaub'),
            ('2025-09-10', '2025-09-15', 'Kurzer Urlaub'),
            ('2025-12-20', '2025-12-31', 'Weihnachtsurlaub')
        ]
        cursor.executemany('''
            INSERT INTO urlaub (start_date, end_date, reason)
            VALUES (?, ?, ?)
        ''', test_urlaub)
    
    conn.commit()
    conn.close()

# Datenbank initialisieren
init_db()

# Role-Decorator
def requires_role(role):
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            if 'user' not in session or session['user'].get('role') != role:
                flash('Zugriff verweigert.')
                return redirect('/login')
            return f(*args, **kwargs)
        return decorated
    return decorator

# API-Endpunkte für AJAX-Calls
@app.route('/api/auftraege', methods=['GET', 'POST'])
def api_auftraege():
    if 'user' not in session:
        return jsonify({'error': 'Nicht angemeldet'}), 401
    
    conn = get_db_connection()
    
    if request.method == 'GET':
        # Filter-Parameter
        status = request.args.get('status', 'all')
        priority = request.args.get('priority', 'all')
        
        query = 'SELECT * FROM auftraege WHERE 1=1'
        params = []
        
        if status != 'all':
            if status == 'done':
                query += ' AND done = 1'
            elif status == 'pending':
                query += ' AND done = 0'
        
        if priority != 'all':
            query += ' AND priority = ?'
            params.append(priority)
        
        query += ' ORDER BY created_at DESC'
        
        cursor = conn.execute(query, params)
        auftraege = cursor.fetchall()
        
        result = []
        for auftrag in auftraege:
            result.append({
                'id': auftrag['id'],
                'art': auftrag['art'],
                'uhrzeit': auftrag['uhrzeit'],
                'standort': auftrag['standort'],
                'coords': auftrag['coords'],
                'details': auftrag['details'],
                'done': bool(auftrag['done']),
                'priority': auftrag['priority'],
                'mitarbeiter': auftrag['mitarbeiter'],
                'created_at': auftrag['created_at']
            })
        
        conn.close()
        return jsonify(result)
    
    elif request.method == 'POST':
        data = request.get_json()
        
        cursor = conn.execute('''
            INSERT INTO auftraege (art, uhrzeit, standort, coords, details, priority, mitarbeiter)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (
            data['art'],
            data['uhrzeit'],
            data['standort'],
            data.get('coords', '[]'),
            data.get('details', ''),
            data.get('priority', 'normal'),
            session['user']['email']
        ))
        
        conn.commit()
        conn.close()
        
        return jsonify({'success': True, 'id': cursor.lastrowid})

@app.route('/api/auftraege/<int:auftrag_id>', methods=['PUT', 'DELETE'])
def api_auftrag_detail(auftrag_id):
    if 'user' not in session:
        return jsonify({'error': 'Nicht angemeldet'}), 401
    
    conn = get_db_connection()
    
    if request.method == 'PUT':
        data = request.get_json()
        
        conn.execute('''
            UPDATE auftraege 
            SET art = ?, uhrzeit = ?, standort = ?, coords = ?, details = ?, done = ?, priority = ?
            WHERE id = ?
        ''', (
            data['art'],
            data['uhrzeit'],
            data['standort'],
            data.get('coords', '[]'),
            data.get('details', ''),
            data.get('done', False),
            data.get('priority', 'normal'),
            auftrag_id
        ))
        
        conn.commit()
        conn.close()
        return jsonify({'success': True})
    
    elif request.method == 'DELETE':
        conn.execute('DELETE FROM auftraege WHERE id = ?', (auftrag_id,))
        conn.commit()
        conn.close()
        return jsonify({'success': True})

@app.route('/api/zeiterfassung', methods=['GET', 'POST'])
def api_zeiterfassung():
    if 'user' not in session:
        return jsonify({'error': 'Nicht angemeldet'}), 401
    
    conn = get_db_connection()
    
    if request.method == 'GET':
        cursor = conn.execute('''
            SELECT * FROM zeiterfassung 
            ORDER BY date DESC, start_time DESC
        ''')
        zeiterfassung = cursor.fetchall()
        
        result = []
        for entry in zeiterfassung:
            result.append({
                'id': entry['id'],
                'elevator_id': entry['elevator_id'],
                'location': entry['location'],
                'date': entry['date'],
                'activity_type': entry['activity_type'],
                'start_time': entry['start_time'],
                'end_time': entry['end_time'],
                'emergency_week': bool(entry['emergency_week']),
                'notes': entry['notes'],
                'status': entry['status'],
                'mitarbeiter': entry['mitarbeiter'],
                'created_at': entry['created_at']
            })
        
        conn.close()
        return jsonify(result)
    
    elif request.method == 'POST':
        data = request.get_json()
        
        cursor = conn.execute('''
            INSERT INTO zeiterfassung (elevator_id, location, date, activity_type, start_time, end_time, emergency_week, notes, status, mitarbeiter)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            data.get('elevator_id', ''),
            data['location'],
            data['date'],
            data['activity_type'],
            data['start_time'],
            data.get('end_time', ''),
            data.get('emergency_week', False),
            data.get('notes', ''),
            'pending',
            session['user']['email']
        ))
        
        conn.commit()
        conn.close()
        
        return jsonify({'success': True, 'id': cursor.lastrowid})

@app.route('/api/arbeitszeit', methods=['GET', 'POST'])
def api_arbeitszeit():
    if 'user' not in session:
        return jsonify({'error': 'Nicht angemeldet'}), 401
    
    conn = get_db_connection()
    
    if request.method == 'GET':
        # Filter-Parameter
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        
        query = 'SELECT * FROM arbeitszeit WHERE 1=1'
        params = []
        
        if start_date:
            query += ' AND datum >= ?'
            params.append(start_date)
        
        if end_date:
            query += ' AND datum <= ?'
            params.append(end_date)
        
        query += ' ORDER BY datum DESC, start DESC'
        
        cursor = conn.execute(query, params)
        arbeitszeit = cursor.fetchall()
        
        result = []
        for entry in arbeitszeit:
            result.append({
                'id': entry['id'],
                'datum': entry['datum'],
                'start': entry['start'],
                'stop': entry['stop'],
                'dauer': entry['dauer'],
                'notdienstwoche': bool(entry['notdienstwoche']),
                'quelle': entry['quelle'],
                'bemerkung': entry['bemerkung'],
                'created_at': entry['created_at']
            })
        
        conn.close()
        return jsonify(result)
    
    elif request.method == 'POST':
        data = request.get_json()
        
        cursor = conn.execute('''
            INSERT INTO arbeitszeit (id, datum, start, stop, dauer, notdienstwoche, quelle, bemerkung)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            str(uuid.uuid4()),
            data['datum'],
            data['start'],
            data.get('stop', ''),
            data.get('dauer', ''),
            data.get('notdienstwoche', False),
            data.get('quelle', 'manuell'),
            data.get('bemerkung', '')
        ))
        
        conn.commit()
        conn.close()
        
        return jsonify({'success': True})

@app.route('/api/urlaub', methods=['GET', 'POST'])
def api_urlaub():
    if 'user' not in session:
        return jsonify({'error': 'Nicht angemeldet'}), 401
    
    conn = get_db_connection()
    
    if request.method == 'GET':
        cursor = conn.execute('''
            SELECT * FROM urlaub 
            ORDER BY start_date ASC
        ''')
        urlaub = cursor.fetchall()
        
        result = []
        for entry in urlaub:
            result.append({
                'id': entry['id'],
                'start_date': entry['start_date'],
                'end_date': entry['end_date'],
                'reason': entry['reason'],
                'status': entry['status'],
                'mitarbeiter': entry['mitarbeiter'],
                'created_at': entry['created_at']
            })
        
        conn.close()
        return jsonify(result)
    
    elif request.method == 'POST':
        data = request.get_json()
        
        cursor = conn.execute('''
            INSERT INTO urlaub (start_date, end_date, reason, status, mitarbeiter)
            VALUES (?, ?, ?, ?, ?)
        ''', (
            data['start_date'],
            data['end_date'],
            data.get('reason', ''),
            'pending',
            session['user']['email']
        ))
        
        conn.commit()
        conn.close()
        
        return jsonify({'success': True, 'id': cursor.lastrowid})

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        app.logger.debug(f"Login attempt: {email}")
        
        if email in TEST_USERS and TEST_USERS[email]['password'] == password:
            user_data = TEST_USERS[email]
            session['user'] = {
                'email': email,
                'name': user_data['name'],
                'role': user_data['role']
            }
            app.logger.debug(f"User logged in: {session['user']}")
            
            if user_data['role'] == 'Admin':
                return redirect('/buero')
            return redirect('/')
        flash('Ungültige Anmeldedaten')
    
    # Einfache HTML-Ausgabe statt render_template_string
    return """
    <!DOCTYPE html>
    <html lang="de">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Anmeldung - Zeiterfassung System</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                background-color: #f5f5f5;
                margin: 0;
                padding: 20px;
                display: flex;
                justify-content: center;
                align-items: center;
                min-height: 100vh;
            }
            .login-container {
                background: white;
                padding: 40px;
                border-radius: 10px;
                box-shadow: 0 4px 20px rgba(0,0,0,0.1);
                width: 100%;
                max-width: 400px;
            }
            .header {
                text-align: center;
                margin-bottom: 30px;
            }
            .form-group {
                margin-bottom: 20px;
            }
            label {
                display: block;
                margin-bottom: 5px;
                font-weight: bold;
                color: #333;
            }
            input[type="email"], input[type="password"] {
                width: 100%;
                padding: 12px;
                border: 2px solid #ddd;
                border-radius: 5px;
                font-size: 16px;
                box-sizing: border-box;
            }
            input[type="email"]:focus, input[type="password"]:focus {
                border-color: #0066b3;
                outline: none;
            }
            .login-btn {
                width: 100%;
                background: #0066b3;
                color: white;
                padding: 12px;
                border: none;
                border-radius: 5px;
                font-size: 16px;
                cursor: pointer;
                margin-top: 10px;
            }
            .login-btn:hover {
                background: #0052a3;
            }
            .demo-info {
                background: #e3f2fd;
                padding: 15px;
                border-radius: 5px;
                margin-top: 20px;
                font-size: 14px;
            }
        </style>
    </head>
    <body>
        <div class="login-container">
            <div class="header">
                <h1>🚀 Zeiterfassung System</h1>
                <h2>Lackner Aufzüge</h2>
            </div>
            
            <form method="POST" action="/login">
                <div class="form-group">
                    <label for="email">E-Mail:</label>
                    <input type="email" id="email" name="email" required>
                </div>
                
                <div class="form-group">
                    <label for="password">Passwort:</label>
                    <input type="password" id="password" name="password" required>
                </div>
                
                <button type="submit" class="login-btn">🔐 Anmelden</button>
            </form>
            
            <div class="demo-info">
                <h4>📋 Test-Anmeldedaten:</h4>
                <p><strong>Monteur:</strong><br>
                E-Mail: monteur@test.com<br>
                Passwort: test123</p>
                
                <p><strong>Administrator:</strong><br>
                E-Mail: admin@test.com<br>
                Passwort: test123</p>
            </div>
        </div>
    </body>
    </html>
    """

@app.route('/logout')
def logout():
    app.logger.debug(f"Logout: {session.get('user')}")
    session.clear()
    session.modified = True
    
    # Response mit explizitem Cookie-Löschen
    response = redirect('/login')
    response.delete_cookie('session', domain='.azurewebsites.net')
    response.delete_cookie('session', domain='la-zeiterfassung-fyd4cge3d9e3cac4.azurewebsites.net')
    response.delete_cookie('session')  # Ohne Domain
    return response

@app.route('/')
def index():
    app.logger.debug(f"Index route - Session: {session}")
    if 'user' not in session:
        return redirect('/login')
    if session['user'].get('role') == 'Admin':
        return redirect('/buero')
    # Monteur-Frontend - Vollständiges Dashboard mit allen Features
    user = session['user']
    today = datetime.now().strftime('%Y-%m-%d')
    return f"""
    <!DOCTYPE html>
    <html lang="de">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Monteur Dashboard - Zeiterfassung System</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
        <script>
            tailwind.config = {{
                theme: {{
                    extend: {{
                        colors: {{
                            primary: '#0066b3',
                            secondary: '#f8fafc'
                        }}
                    }}
                }}
            }}
        </script>
    </head>
    <body class="bg-gray-50">
        <!-- Header -->
        <header class="bg-blue-600 text-white shadow-lg">
            <div class="container mx-auto px-4 py-3">
                <div class="flex justify-between items-center">
                    <div class="flex items-center space-x-4">
                        <i class="fas fa-clock text-2xl"></i>
                        <h1 class="text-xl font-bold">Zeiterfassung System</h1>
                    </div>
                    <div class="flex items-center space-x-4">
                        <span class="text-sm">Willkommen, {user['name']}</span>
                        <a href="/logout" class="bg-red-500 hover:bg-red-600 px-3 py-1 rounded text-sm">
                            <i class="fas fa-sign-out-alt mr-1"></i>Abmelden
                        </a>
                    </div>
                </div>
            </div>
        </header>

        <!-- Navigation -->
        <nav class="bg-white shadow-sm border-b">
            <div class="container mx-auto px-4">
                <div class="flex space-x-8 py-3">
                    <a href="/" class="text-blue-600 font-semibold border-b-2 border-blue-600 pb-2">
                        <i class="fas fa-home mr-2"></i>Dashboard
                    </a>
                    <a href="/zeiterfassung" class="text-gray-600 hover:text-blue-600">
                        <i class="fas fa-stopwatch mr-2"></i>Zeiterfassung
                    </a>
                    <a href="/arbeitszeit" class="text-gray-600 hover:text-blue-600">
                        <i class="fas fa-clock mr-2"></i>Arbeitszeit
                    </a>
                    <a href="/meine-auftraege" class="text-gray-600 hover:text-blue-600">
                        <i class="fas fa-tasks mr-2"></i>Meine Aufträge
                    </a>
                    <a href="/urlaub" class="text-gray-600 hover:text-blue-600">
                        <i class="fas fa-umbrella-beach mr-2"></i>Urlaub
                    </a>
                </div>
            </div>
        </nav>

        <!-- Main Content -->
        <main class="container mx-auto px-4 py-8">
            <!-- Begrüßung -->
            <div class="mb-8">
                <h1 class="text-3xl font-bold text-gray-900 mb-2">
                    Guten Tag, {user['name']}
                </h1>
                <p class="text-gray-600">Willkommen im Zeiterfassungssystem</p>
            </div>

            <!-- Überstunden-Warnung -->
            <div id="overtime-warning" class="mb-6 bg-red-50 border border-red-200 rounded-lg p-4 hidden">
                <div class="flex items-center justify-between">
                    <div class="flex items-center">
                        <i class="fas fa-exclamation-triangle text-red-600 mr-3"></i>
                        <div>
                            <h3 class="text-lg font-semibold text-red-800 mb-1">
                                Überstunden-Warnung
                            </h3>
                            <p class="text-red-700">
                                Es wurden <span id="overtime-count">0</span> Tag(e) mit überschrittenen Arbeitszeiten gefunden.
                            </p>
                            <div id="overtime-details" class="mt-2 text-sm text-red-600">
                            </div>
                        </div>
                    </div>
                    <a href="/arbeitszeit?show_overtime=true" class="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors text-sm font-medium">
                        Arbeitszeit prüfen
                    </a>
                </div>
            </div>

            <!-- Meine Aufträge heute und Arbeitszeit Timer - 50/50 Layout -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
                <!-- Meine Aufträge heute -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <div class="flex items-center justify-between mb-4">
                        <div class="flex items-center">
                            <i class="fas fa-tasks text-blue-600 mr-2"></i>
                            <h2 class="text-lg font-semibold text-gray-900">Meine Aufträge heute</h2>
                        </div>
                        <a href="/meine-auftraege" class="text-sm text-blue-600 hover:text-blue-800 font-medium">
                            Alle Aufträge anzeigen →
                        </a>
                    </div>
                    
                    <!-- Auftrags-Statistiken -->
                    <div class="grid grid-cols-2 gap-4 mb-4">
                        <div class="text-center p-3 bg-green-50 rounded-lg">
                            <div class="text-2xl font-bold text-green-600" id="auftraege-erledigt">0</div>
                            <div class="text-sm text-green-700">Erledigt</div>
                        </div>
                        <div class="text-center p-3 bg-orange-50 rounded-lg">
                            <div class="text-2xl font-bold text-orange-600" id="auftraege-offen">2</div>
                            <div class="text-sm text-orange-700">Offen</div>
                        </div>
                    </div>

                    <!-- Nächste Aufträge -->
                    <div class="mb-4">
                        <div class="font-semibold text-blue-600 mb-3">
                            Nächste Aufträge (<span id="auftraege-offen-count">2</span> offen)
                        </div>
                        <div id="auftraege-list" class="space-y-2">
                            <!-- Aufträge werden hier dynamisch geladen -->
                        </div>
                    </div>

                    <!-- Schnellzugriff auf Aufträge -->
                    <div class="text-sm text-gray-600">
                        <a href="/meine-auftraege" class="text-blue-600 hover:text-blue-800 font-medium">
                            → Zu allen Aufträgen
                        </a>
                    </div>
                </div>

                <!-- Arbeitszeit Timer -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <div class="flex items-center justify-between mb-4">
                        <div class="flex items-center">
                            <i class="fas fa-stopwatch text-blue-600 mr-2"></i>
                            <h2 class="text-lg font-semibold text-gray-900">Arbeitszeit Timer</h2>
                        </div>
                        <a href="/arbeitszeit" class="text-sm text-blue-600 hover:text-blue-800 font-medium">
                            Alle Arbeitszeiten anzeigen →
                        </a>
                    </div>
                    
                    <!-- Timer und Steuerung -->
                    <div class="text-center mb-6">
                        <div class="text-3xl font-extrabold mb-4 text-blue-900" id="timer-display">0:00:00h</div>
                        <div class="flex gap-4 justify-center mb-4">
                            <button id="start-btn" class="bg-green-600 hover:bg-green-700 text-white font-semibold px-6 py-3 rounded-lg text-base">
                                Start
                            </button>
                            <button id="pause-btn" class="bg-yellow-600 hover:bg-yellow-700 text-white font-semibold px-6 py-3 rounded-lg text-base disabled:bg-gray-400 disabled:cursor-not-allowed" disabled>
                                Pause
                            </button>
                            <button id="stop-btn" class="bg-red-600 hover:bg-red-700 text-white font-semibold px-6 py-3 rounded-lg text-base disabled:bg-gray-400 disabled:cursor-not-allowed" disabled>
                                Stop
                            </button>
                        </div>
                        
                        <!-- Notdienstwoche Toggle -->
                        <div class="flex items-center justify-center gap-2 mb-4">
                            <input type="checkbox" id="notdienstwoche-check" class="h-4 w-4 text-blue-600 border-gray-300 rounded">
                            <label for="notdienstwoche-check" class="text-sm text-gray-700">
                                Notdienstwoche
                            </label>
                        </div>
                    </div>

                    <!-- Statistiken -->
                    <div class="grid grid-cols-4 gap-2 mb-4">
                        <div class="text-center p-2 bg-blue-50 rounded">
                            <div class="text-sm font-bold text-blue-900" id="arbeitszeit-display">0:00h</div>
                            <div class="text-xs text-blue-700">Arbeitszeit</div>
                        </div>
                        <div class="text-center p-2 bg-orange-50 rounded">
                            <div class="text-sm font-bold text-orange-600" id="pause-display">0:00h</div>
                            <div class="text-xs text-orange-700">Pausenzeit</div>
                        </div>
                        <div class="text-center p-2 bg-green-50 rounded">
                            <div class="text-sm font-bold text-green-700" id="geplantes-ende">--:--</div>
                            <div class="text-xs text-green-700">Geplantes Ende</div>
                        </div>
                        <div class="text-center p-2 bg-gray-50 rounded">
                            <div class="text-sm font-bold text-gray-700" id="status-display">Bereit</div>
                            <div class="text-xs text-gray-700">Status</div>
                        </div>
                    </div>

                    <!-- Warnungen -->
                    <div id="timer-warning" class="hidden">
                        <div class="bg-yellow-100 border border-yellow-400 text-yellow-800 px-3 py-2 rounded mb-3 flex items-center text-sm">
                            <i class="fas fa-exclamation-triangle text-yellow-600 mr-2"></i>
                            <span class="font-medium" id="warning-text"></span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Tageszusammenfassung und Wetter/Wetterwarnungen/Urlaub -->
            <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                <!-- Tageszusammenfassung - 50% (2 Spalten) -->
                <div class="md:col-span-2">
                    <div class="bg-white rounded-lg shadow-md p-4 h-full flex flex-col justify-between">
                        <div class="flex items-center mb-3">
                            <i class="fas fa-chart-bar text-green-600 mr-2"></i>
                            <h2 class="text-lg font-semibold text-gray-900">Tageszusammenfassung</h2>
                        </div>
                        
                        <!-- Große Statuszahlen -->
                        <div class="grid grid-cols-2 gap-4">
                            <!-- Benachrichtigungen -->
                            <div onclick="window.location.href='/approve-entries'" class="p-6 rounded-lg border-2 cursor-pointer transition-all hover:shadow-md hover:scale-105 bg-green-50 border-green-200 hover:bg-green-100">
                                <div class="text-center">
                                    <div class="text-4xl font-bold text-green-600" id="benachrichtigungen-count">0</div>
                                    <div class="text-sm font-semibold text-gray-700 mb-3">Benachrichtigungen</div>
                                    <div class="text-xs text-gray-600 mb-3">Keine neuen Benachrichtigungen</div>
                                    <div class="text-xs text-blue-600 font-medium">→ Zur Genehmigung</div>
                                </div>
                            </div>

                            <!-- Notfälle -->
                            <div onclick="window.location.href='/meine-auftraege'" class="p-6 rounded-lg border-2 bg-orange-50 border-orange-200 cursor-pointer transition-all hover:shadow-md hover:scale-105 hover:bg-orange-100">
                                <div class="text-center">
                                    <div class="text-4xl font-bold text-orange-600">0</div>
                                    <div class="text-sm font-semibold text-gray-700 mb-3">Notfälle</div>
                                    <div class="text-xs text-gray-600 mb-3">Keine aktiven Notfälle</div>
                                    <div class="text-xs text-blue-600 font-medium">→ Zu den Aufträgen</div>
                                </div>
                            </div>

                            <!-- Offene Aufgaben -->
                            <div onclick="window.location.href='/zeiterfassung'" class="p-6 rounded-lg border-2 bg-blue-50 border-blue-200 cursor-pointer transition-all hover:shadow-md hover:scale-105 hover:bg-blue-100">
                                <div class="text-center">
                                    <div class="text-4xl font-bold text-blue-600" id="offene-aufgaben-count">0</div>
                                    <div class="text-sm font-semibold text-gray-700 mb-3">Offene Aufgaben</div>
                                    <div class="text-xs text-gray-600 mb-3">Alle Aufgaben erledigt</div>
                                    <div class="text-xs text-blue-600 font-medium">→ Zur Zeiterfassung</div>
                                </div>
                            </div>

                            <!-- Nächster Urlaub -->
                            <div onclick="window.location.href='/urlaub'" class="p-6 rounded-lg border-2 bg-purple-50 border-purple-200 cursor-pointer transition-all hover:shadow-md hover:scale-105 hover:bg-purple-100">
                                <div class="text-center">
                                    <div class="text-4xl font-bold text-purple-600" id="urlaub-count">25</div>
                                    <div class="text-sm font-semibold text-gray-700 mb-3">Nächster Urlaub</div>
                                    <div class="text-xs text-gray-600 mb-3">25 Tage übrig</div>
                                    <div class="text-xs text-blue-600 font-medium">→ Zum Urlaub</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Wetter - 25% (1 Spalte) -->
                <div class="w-full">
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <div class="flex items-center mb-4">
                            <i class="fas fa-cloud-sun text-yellow-500 mr-2"></i>
                            <h2 class="text-lg font-semibold text-gray-900">Wetter</h2>
                        </div>
                        <div class="text-center">
                            <div class="text-4xl mb-2">☀️</div>
                            <div class="text-2xl font-bold text-gray-700">22°C</div>
                            <div class="text-gray-600">Sonnig, Wien</div>
                            <div class="text-sm text-gray-500 mt-2">Perfekt für Außeneinsätze</div>
                        </div>
                    </div>
                </div>
                
                <!-- Wetterwarnungen und Urlaub - 25% (1 Spalte) -->
                <div class="w-full">
                    <!-- Wetterwarnungen oben -->
                    <div class="bg-white rounded-lg shadow-md p-4 mb-4">
                        <div class="flex items-center justify-between mb-3">
                            <div class="flex items-center">
                                <i class="fas fa-exclamation-triangle text-gray-600 mr-2"></i>
                                <h3 class="text-sm font-semibold text-gray-900">Wetterwarnungen</h3>
                            </div>
                            <div class="text-xs text-blue-600 font-medium cursor-pointer hover:underline">
                                → Wetterdienst prüfen
                            </div>
                        </div>
                        
                        <div class="space-y-2">
                            <!-- Status -->
                            <div class="flex items-center justify-between p-2 bg-gray-50 rounded">
                                <span class="text-xs font-medium text-gray-700">Status</span>
                                <span class="text-xs font-semibold text-green-600">Keine Warnungen</span>
                            </div>
                        </div>
                    </div>

                    <!-- Urlaub unten -->
                    <div class="bg-white rounded-lg shadow-md p-4">
                        <div class="flex items-center mb-3">
                            <i class="fas fa-umbrella-beach text-purple-600 mr-2"></i>
                            <h3 class="text-sm font-semibold text-gray-900">Urlaub</h3>
                        </div>
                        <div class="grid grid-cols-3 gap-2">
                            <div class="text-center">
                                <div class="text-lg font-bold text-purple-600">25</div>
                                <div class="text-xs text-gray-600">Übrig</div>
                            </div>
                            <div class="text-center">
                                <div class="text-lg font-bold text-green-600">5</div>
                                <div class="text-xs text-gray-600">Verbraucht</div>
                            </div>
                            <div class="text-center">
                                <div class="text-lg font-bold text-blue-600">3</div>
                                <div class="text-xs text-gray-600">Geplant</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Zeiteinträge und Wetterwarnungen - 50% Breite -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                <!-- Zeiteinträge Box -->
                <div class="w-full">
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <div class="flex items-center mb-4">
                            <i class="fas fa-clock text-blue-600 mr-2"></i>
                            <h2 class="text-lg font-semibold text-gray-900">Zeiteinträge</h2>
                        </div>
                        
                        <div class="grid grid-cols-1 gap-4">
                            <!-- Offene Zeiteinträge -->
                            <div onclick="window.location.href='/zeiterfassung'" class="p-4 rounded-lg border border-gray-200 cursor-pointer transition-all hover:shadow-md hover:scale-105 hover:bg-gray-50">
                                <div class="flex items-center justify-between mb-2">
                                    <div class="flex items-center">
                                        <i class="fas fa-clock mr-2 text-gray-600"></i>
                                        <span class="text-sm font-medium text-gray-700">Offene Zeiteinträge</span>
                                    </div>
                                    <div class="text-lg font-bold text-gray-900" id="offene-zeiteintraege-count">0</div>
                                </div>
                                <div class="text-xs text-gray-600">Alle Zeiteinträge abgeschlossen</div>
                            </div>

                            <!-- Letzte Zeiteinträge -->
                            <div onclick="window.location.href='/zeiterfassung'" class="p-4 rounded-lg border border-gray-200 cursor-pointer transition-all hover:shadow-md hover:scale-105 hover:bg-gray-50">
                                <div class="flex items-center justify-between mb-2">
                                    <div class="flex items-center">
                                        <i class="fas fa-check mr-2 text-gray-600"></i>
                                        <span class="text-sm font-medium text-gray-700">Letzte Zeiteinträge</span>
                                    </div>
                                    <div class="text-lg font-bold text-gray-900" id="letzte-zeiteintraege-count">0</div>
                                </div>
                                <div class="text-xs text-gray-600">Keine Einträge in den letzten 24h</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Heutige Aktivitäten -->
            <div class="mb-8">
                <div class="bg-white rounded-lg shadow-md p-6">
                    <div class="flex items-center mb-4">
                        <i class="fas fa-calendar-day text-blue-600 mr-2"></i>
                        <h2 class="text-lg font-semibold text-gray-900">Heutige Aktivitäten</h2>
                    </div>
                    <div id="heutige-aktivitaeten">
                        <p class="text-gray-500">Keine Aktivitäten für heute</p>
                    </div>
                </div>
            </div>
        </main>

        <script>
            // Vollständige Timer-Funktionalität
            let timer = 0;
            let timerInterval;
            let isRunning = false;
            let isPaused = false;
            let pauseStart = null;
            let pauseGesamt = 0;
            let arbeitszeitStart = null;
            let arbeitszeitGesamt = 0;
            let notdienstwoche = false;
            
            // LocalStorage Funktionen
            function saveState() {{
                const heute = new Date().toDateString();
                localStorage.setItem('arbeitszeitLastDate', heute);
                
                if (arbeitszeitStart) {{
                    localStorage.setItem('arbeitszeitStart', arbeitszeitStart.getTime().toString());
                }}
                localStorage.setItem('arbeitszeitGesamt', arbeitszeitGesamt.toString());
                localStorage.setItem('arbeitszeitPauseGesamt', pauseGesamt.toString());
                localStorage.setItem('arbeitszeitIsPaused', isPaused.toString());
                localStorage.setItem('notdienstwoche', notdienstwoche ? '1' : '0');
            }}
            
            function loadState() {{
                const heute = new Date().toDateString();
                const savedLastDate = localStorage.getItem('arbeitszeitLastDate');
                
                // Prüfe ob neuer Tag
                if (savedLastDate && savedLastDate !== heute) {{
                    // Neuer Tag - alles zurücksetzen
                    localStorage.removeItem('arbeitszeitStart');
                    localStorage.removeItem('arbeitszeitGesamt');
                    localStorage.removeItem('arbeitszeitPauseGesamt');
                    localStorage.removeItem('arbeitszeitIsPaused');
                    localStorage.setItem('arbeitszeitLastDate', heute);
                    return;
                }}
                
                const savedStart = localStorage.getItem('arbeitszeitStart');
                const savedGesamt = localStorage.getItem('arbeitszeitGesamt');
                const savedPauseGesamt = localStorage.getItem('arbeitszeitPauseGesamt');
                const savedIsPaused = localStorage.getItem('arbeitszeitIsPaused');
                const savedNotdienst = localStorage.getItem('notdienstwoche');
                
                if (savedStart && savedStart !== 'null' && savedStart !== '') {{
                    const startTime = new Date(parseInt(savedStart));
                    if (startTime.toDateString() === heute) {{
                        arbeitszeitStart = startTime;
                        isRunning = true;
                    }}
                }}
                
                if (savedGesamt) {{
                    arbeitszeitGesamt = parseInt(savedGesamt);
                }}
                
                if (savedPauseGesamt) {{
                    pauseGesamt = parseInt(savedPauseGesamt);
                }}
                
                if (savedIsPaused === 'true') {{
                    isPaused = true;
                }}
                
                if (savedNotdienst === '1') {{
                    notdienstwoche = true;
                    document.getElementById('notdienstwoche-check').checked = true;
                }}
                
                updateTimerDisplay();
                updateButtonStates();
            }}
            
            function updateTimerDisplay() {{
                if (arbeitszeitStart) {{
                    let aktuell = 0;
                    
                    if (!isPaused) {{
                        // Timer läuft - aktuelle Zeit berechnen
                        const jetzt = new Date();
                        aktuell = Math.floor((jetzt.getTime() - arbeitszeitStart.getTime()) / 1000);
                    }} else {{
                        // Timer pausiert - Zeit zum Pause-Start berechnen
                        const pauseZeit = pauseStart ? pauseStart.getTime() : arbeitszeitStart.getTime();
                        aktuell = Math.floor((pauseZeit - arbeitszeitStart.getTime()) / 1000);
                    }}
                    
                    const gesamt = arbeitszeitGesamt + aktuell;
                    const nettoZeit = gesamt - pauseGesamt;
                    
                    const stunden = Math.floor(nettoZeit / 3600);
                    const minuten = Math.floor((nettoZeit % 3600) / 60);
                    const sekunden = nettoZeit % 60;
                    
                    document.getElementById('timer-display').textContent = 
                        `${{stunden}}:${{String(minuten).padStart(2, '0')}}:${{String(sekunden).padStart(2, '0')}}h`;
                    
                    // Statistiken aktualisieren
                    document.getElementById('arbeitszeit-display').textContent = 
                        `${{stunden}}:${{String(minuten).padStart(2, '0')}}h`;
                    
                    // Geplantes Ende berechnen (8,5h Arbeitszeit)
                    const maxArbeitszeit = 8.5 * 3600;
                    const verbleibendeArbeitszeit = maxArbeitszeit - nettoZeit;
                    
                    if (verbleibendeArbeitszeit > 0) {{
                        const jetzt = new Date();
                        const geplantesEnde = new Date(jetzt.getTime() + verbleibendeArbeitszeit * 1000);
                        document.getElementById('geplantes-ende').textContent = 
                            geplantesEnde.toLocaleTimeString('de-DE', {{ hour: '2-digit', minute: '2-digit' }});
                    }} else {{
                        document.getElementById('geplantes-ende').textContent = 'Überschritten';
                    }}
                    
                    // Warnungen
                    const warnung30Min = nettoZeit >= (8 * 3600) && nettoZeit < (8.5 * 3600);
                    const ueberschritten = nettoZeit >= (8.5 * 3600);
                    
                    if (warnung30Min && !ueberschritten) {{
                        const verbleibendeMin = Math.max(0, Math.ceil((8.5 * 3600 - nettoZeit) / 60));
                        document.getElementById('warning-text').textContent = 
                            `Warnung: In ${{verbleibendeMin}} Min. max. Arbeitszeit erreicht!`;
                        document.getElementById('timer-warning').classList.remove('hidden');
                    }} else if (ueberschritten) {{
                        document.getElementById('warning-text').textContent = '⚠️ Maximale Arbeitszeit (8,5h) überschritten!';
                        document.getElementById('timer-warning').classList.remove('hidden');
                    }} else {{
                        document.getElementById('timer-warning').classList.add('hidden');
                    }}
                }} else {{
                    document.getElementById('timer-display').textContent = '0:00:00h';
                    document.getElementById('arbeitszeit-display').textContent = '0:00h';
                    document.getElementById('geplantes-ende').textContent = '--:--';
                    document.getElementById('timer-warning').classList.add('hidden');
                }}
                
                // Pausenzeit anzeigen
                const pauseStunden = Math.floor(pauseGesamt / 3600);
                const pauseMinuten = Math.floor((pauseGesamt % 3600) / 60);
                document.getElementById('pause-display').textContent = 
                    `${{pauseStunden}}:${{String(pauseMinuten).padStart(2, '0')}}h`;
                
                // Status anzeigen
                let status = 'Bereit';
                let statusColor = 'text-gray-700';
                if (isPaused) {{
                    status = 'Pausiert';
                    statusColor = 'text-yellow-700';
                }} else if (isRunning) {{
                    status = 'Aktiv';
                    statusColor = 'text-green-700';
                }}
                document.getElementById('status-display').textContent = status;
                document.getElementById('status-display').className = `text-sm font-bold ${{statusColor}}`;
            }}
            
            function updateButtonStates() {{
                const startBtn = document.getElementById('start-btn');
                const pauseBtn = document.getElementById('pause-btn');
                const stopBtn = document.getElementById('stop-btn');
                
                startBtn.disabled = isRunning;
                pauseBtn.disabled = !isRunning;
                stopBtn.disabled = !isRunning;
                
                if (isPaused) {{
                    pauseBtn.textContent = 'Fortsetzen';
                    pauseBtn.className = 'bg-blue-600 hover:bg-blue-700 text-white font-semibold px-6 py-3 rounded-lg text-base';
                }} else {{
                    pauseBtn.textContent = 'Pause';
                    pauseBtn.className = 'bg-yellow-600 hover:bg-yellow-700 text-white font-semibold px-6 py-3 rounded-lg text-base disabled:bg-gray-400 disabled:cursor-not-allowed';
                }}
            }}
            
            // Timer-Funktionen
            function startTimer() {{
                if (!isRunning) {{
                    arbeitszeitStart = new Date();
                    isRunning = true;
                    isPaused = false;
                    pauseStart = null;
                    saveState();
                    updateTimerDisplay();
                    updateButtonStates();
                    
                    // Timer-Interval starten
                    timerInterval = setInterval(updateTimerDisplay, 1000);
                }}
            }}
            
            function pauseTimer() {{
                if (isRunning && !isPaused) {{
                    pauseStart = new Date();
                    isPaused = true;
                    saveState();
                    updateTimerDisplay();
                    updateButtonStates();
                    clearInterval(timerInterval);
                }} else if (isRunning && isPaused) {{
                    // Fortsetzen
                    const resumeTime = new Date();
                    const pauseDuration = Math.floor((resumeTime.getTime() - pauseStart.getTime()) / 1000);
                    pauseGesamt += pauseDuration;
                    pauseStart = null;
                    isPaused = false;
                    saveState();
                    updateTimerDisplay();
                    updateButtonStates();
                    
                    // Timer-Interval wieder starten
                    timerInterval = setInterval(updateTimerDisplay, 1000);
                }}
            }}
            
            function stopTimer() {{
                if (isRunning) {{
                    const stopTime = new Date();
                    const dauer = Math.floor((stopTime.getTime() - arbeitszeitStart.getTime()) / 1000);
                    
                    // Arbeitszeit-Eintrag automatisch erstellen
                    const startDate = new Date(arbeitszeitStart);
                    const formData = new FormData();
                    formData.append('datum', startDate.toISOString().split('T')[0]);
                    formData.append('start', startDate.toTimeString().slice(0, 5));
                    formData.append('stop', stopTime.toTimeString().slice(0, 5));
                    formData.append('dauer', `${{Math.floor(dauer / 3600)}}:${{String(Math.floor((dauer % 3600) / 60)).padStart(2, '0')}}`);
                    formData.append('notdienstwoche', notdienstwoche ? '1' : '0');
                    formData.append('bemerkung', 'Automatisch erstellt vom Dashboard');
                    
                    // Hier könnte ein API-Call gemacht werden
                    console.log('Arbeitszeit-Eintrag erstellt:', {{
                        datum: startDate.toISOString().split('T')[0],
                        start: startDate.toTimeString().slice(0, 5),
                        stop: stopTime.toTimeString().slice(0, 5),
                        dauer: `${{Math.floor(dauer / 3600)}}:${{String(Math.floor((dauer % 3600) / 60)).padStart(2, '0')}}`,
                        notdienstwoche: notdienstwoche ? '1' : '0',
                        bemerkung: 'Automatisch erstellt vom Dashboard'
                    }});
                    
                    arbeitszeitStart = null;
                    isRunning = false;
                    isPaused = false;
                    pauseStart = null;
                    arbeitszeitGesamt += dauer;
                    saveState();
                    updateTimerDisplay();
                    updateButtonStates();
                    clearInterval(timerInterval);
                }}
            }}
            
            // Event Listeners
            document.getElementById('start-btn').addEventListener('click', startTimer);
            document.getElementById('pause-btn').addEventListener('click', pauseTimer);
            document.getElementById('stop-btn').addEventListener('click', stopTimer);
            
            document.getElementById('notdienstwoche-check').addEventListener('change', function(e) {{
                notdienstwoche = e.target.checked;
                localStorage.setItem('notdienstwoche', notdienstwoche ? '1' : '0');
            }});
            
            // Aufträge laden
            function loadAuftraege() {{
                const auftraege = [
                    {{
                        id: '1',
                        uhrzeit: '07:30',
                        art: 'Reparatur',
                        standort: 'Hauptbahnhof, München',
                        details: 'Aufzug klemmt, Notruf ausgelöst.',
                        done: false
                    }},
                    {{
                        id: '2',
                        uhrzeit: '08:15',
                        art: 'Wartung',
                        standort: 'Sendlinger Tor, München',
                        details: 'Regelmäßige Wartung, Ölwechsel.',
                        done: false
                    }}
                ];
                
                const offeneAuftraege = auftraege.filter(a => !a.done);
                const erledigteAuftraege = auftraege.filter(a => a.done);
                
                document.getElementById('auftraege-offen').textContent = offeneAuftraege.length;
                document.getElementById('auftraege-erledigt').textContent = erledigteAuftraege.length;
                document.getElementById('auftraege-offen-count').textContent = offeneAuftraege.length;
                
                const auftraegeList = document.getElementById('auftraege-list');
                auftraegeList.innerHTML = '';
                
                if (offeneAuftraege.length > 0) {{
                    offeneAuftraege.slice(0, 3).forEach(auftrag => {{
                        const auftragDiv = document.createElement('div');
                        auftragDiv.className = 'p-3 rounded-lg border-l-4 bg-orange-50 border-orange-400';
                        auftragDiv.innerHTML = `
                            <div class="flex items-center justify-between">
                                <div class="flex-1">
                                    <div class="flex items-center gap-2">
                                        <span class="text-sm font-medium text-gray-900">
                                            ${{auftrag.uhrzeit}} - ${{auftrag.art}}
                                        </span>
                                        <span class="text-xs bg-orange-100 text-orange-800 px-2 py-1 rounded">
                                            Offen
                                        </span>
                                    </div>
                                    <div class="text-xs text-gray-600 mt-1">
                                        ${{auftrag.standort}}
                                    </div>
                                    ${{auftrag.details ? `<div class="text-xs text-gray-500 mt-1">${{auftrag.details}}</div>` : ''}}
                                </div>
                            </div>
                        `;
                        auftraegeList.appendChild(auftragDiv);
                    }});
                    
                    if (offeneAuftraege.length > 3) {{
                        const mehrDiv = document.createElement('div');
                        mehrDiv.className = 'p-2 bg-blue-50 rounded-lg text-center text-blue-600 text-xs';
                        mehrDiv.textContent = `+${{offeneAuftraege.length - 3}} weitere offene Aufträge`;
                        auftraegeList.appendChild(mehrDiv);
                    }}
                }} else if (erledigteAuftraege.length > 0) {{
                    erledigteAuftraege.slice(0, 2).forEach(auftrag => {{
                        const auftragDiv = document.createElement('div');
                        auftragDiv.className = 'p-3 rounded-lg border-l-4 bg-green-50 border-green-400';
                        auftragDiv.innerHTML = `
                            <div class="flex items-center justify-between">
                                <div class="flex-1">
                                    <div class="flex items-center gap-2">
                                        <span class="text-sm font-medium text-gray-900">
                                            ${{auftrag.uhrzeit}} - ${{auftrag.art}}
                                        </span>
                                        <span class="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">
                                            Erledigt
                                        </span>
                                    </div>
                                    <div class="text-xs text-gray-600 mt-1">
                                        ${{auftrag.standort}}
                                    </div>
                                </div>
                            </div>
                        `;
                        auftraegeList.appendChild(auftragDiv);
                    }});
                }} else {{
                    const keineDiv = document.createElement('div');
                    keineDiv.className = 'p-3 bg-gray-50 rounded-lg text-center text-gray-500 text-sm';
                    keineDiv.textContent = 'Keine Aufträge für heute';
                    auftraegeList.appendChild(keineDiv);
                }}
            }}
            
            // Initialisierung
            document.addEventListener('DOMContentLoaded', function() {{
                loadState();
                loadAuftraege();
                
                // Automatischer Neustart um Mitternacht
                setInterval(() => {{
                    const jetzt = new Date();
                    const heute = jetzt.toDateString();
                    const savedLastDate = localStorage.getItem('arbeitszeitLastDate');
                    
                    if (savedLastDate && savedLastDate !== heute) {{
                        // Neuer Tag - Timer zurücksetzen
                        arbeitszeitStart = null;
                        isRunning = false;
                        isPaused = false;
                        pauseStart = null;
                        pauseGesamt = 0;
                        arbeitszeitGesamt = 0;
                        
                        // LocalStorage zurücksetzen
                        localStorage.removeItem('arbeitszeitStart');
                        localStorage.removeItem('arbeitszeitGesamt');
                        localStorage.removeItem('arbeitszeitPauseGesamt');
                        localStorage.removeItem('arbeitszeitIsPaused');
                        localStorage.setItem('arbeitszeitLastDate', heute);
                        
                        updateTimerDisplay();
                        updateButtonStates();
                        clearInterval(timerInterval);
                    }}
                }}, 60000); // Prüfe jede Minute
            }});
        </script>
    </body>
    </html>
    """

@app.route('/zeiterfassung')
def zeiterfassung():
    if 'user' not in session:
        return redirect('/login')
    if session['user'].get('role') == 'Admin':
        return redirect('/buero')
    
    user = session['user']
    return f"""
    <!DOCTYPE html>
    <html lang="de">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Zeiterfassung - Monteur Dashboard</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    </head>
    <body class="bg-gray-50">
        <!-- Header -->
        <header class="bg-blue-600 text-white shadow-lg">
            <div class="container mx-auto px-4 py-3">
                <div class="flex justify-between items-center">
                    <div class="flex items-center space-x-4">
                        <i class="fas fa-stopwatch text-2xl"></i>
                        <h1 class="text-xl font-bold">Zeiterfassung</h1>
                    </div>
                    <div class="flex items-center space-x-4">
                        <span class="text-sm">Willkommen, {user['name']}</span>
                        <a href="/logout" class="bg-red-500 hover:bg-red-600 px-3 py-1 rounded text-sm">
                            <i class="fas fa-sign-out-alt mr-1"></i>Abmelden
                        </a>
                    </div>
                </div>
            </div>
        </header>

        <!-- Navigation -->
        <nav class="bg-white shadow-sm border-b">
            <div class="container mx-auto px-4">
                <div class="flex space-x-8 py-3">
                    <a href="/" class="text-gray-600 hover:text-blue-600">
                        <i class="fas fa-home mr-2"></i>Dashboard
                    </a>
                    <a href="/zeiterfassung" class="text-blue-600 font-semibold border-b-2 border-blue-600 pb-2">
                        <i class="fas fa-stopwatch mr-2"></i>Zeiterfassung
                    </a>
                    <a href="/arbeitszeit" class="text-gray-600 hover:text-blue-600">
                        <i class="fas fa-clock mr-2"></i>Arbeitszeit
                    </a>
                    <a href="/meine-auftraege" class="text-gray-600 hover:text-blue-600">
                        <i class="fas fa-tasks mr-2"></i>Meine Aufträge
                    </a>
                    <a href="/urlaub" class="text-gray-600 hover:text-blue-600">
                        <i class="fas fa-umbrella-beach mr-2"></i>Urlaub
                    </a>
                </div>
            </div>
        </nav>

        <!-- Main Content -->
        <main class="container mx-auto px-4 py-6">
            <!-- Statistiken -->
            <div class="bg-white rounded-lg shadow-md p-6 mb-6">
                <div class="flex flex-wrap items-center justify-between mb-4">
                    <h2 class="text-2xl font-bold text-gray-800">
                        <i class="fas fa-stopwatch mr-2 text-blue-600"></i>Zeiterfassung
                    </h2>
                    <button onclick="openNewZeiterfassungModal()" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg">
                        <i class="fas fa-plus mr-2"></i>Neuer Eintrag
                    </button>
                </div>
                
                <!-- Statistiken -->
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                    <div class="bg-blue-50 p-4 rounded-lg text-center">
                        <div class="text-2xl font-bold text-blue-600" id="total-entries">0</div>
                        <div class="text-sm text-gray-600">Gesamt Einträge</div>
                    </div>
                    <div class="bg-yellow-50 p-4 rounded-lg text-center">
                        <div class="text-2xl font-bold text-yellow-600" id="pending-entries">0</div>
                        <div class="text-sm text-gray-600">Ausstehend</div>
                    </div>
                    <div class="bg-green-50 p-4 rounded-lg text-center">
                        <div class="text-2xl font-bold text-green-600" id="completed-entries">0</div>
                        <div class="text-sm text-gray-600">Abgeschlossen</div>
                    </div>
                    <div class="bg-red-50 p-4 rounded-lg text-center">
                        <div class="text-2xl font-bold text-red-600" id="emergency-entries">0</div>
                        <div class="text-sm text-gray-600">Notdienst</div>
                    </div>
                </div>
            </div>
            
            <!-- Zeiterfassung Liste -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h3 class="text-lg font-semibold mb-4 text-gray-800">Zeiterfassung Einträge</h3>
                <div id="zeiterfassung-container" class="space-y-4">
                    <!-- Einträge werden hier dynamisch geladen -->
                </div>
            </div>
        </main>

        <!-- Neuer Zeiterfassung Modal -->
        <div id="new-zeiterfassung-modal" class="fixed inset-0 bg-black bg-opacity-50 hidden z-50">
            <div class="flex items-center justify-center min-h-screen p-4">
                <div class="bg-white rounded-lg shadow-xl max-w-md w-full">
                    <div class="flex justify-between items-center p-6 border-b">
                        <h3 class="text-lg font-semibold text-gray-900">Neuer Zeiterfassung Eintrag</h3>
                        <button onclick="closeNewZeiterfassungModal()" class="text-gray-400 hover:text-gray-600">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    <form id="new-zeiterfassung-form" class="p-6 space-y-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Aktivitätstyp</label>
                            <select name="activity_type" required class="w-full p-3 border border-gray-300 rounded-lg">
                                <option value="Wartung">⚙️ Wartung</option>
                                <option value="Reparatur">🔧 Reparatur</option>
                                <option value="Notdienst">🚨 Notdienst</option>
                                <option value="Installation">🔨 Installation</option>
                                <option value="Inspektion">📋 Inspektion</option>
                                <option value="Büro">🏢 Büro</option>
                                <option value="Krank">🏥 Krank</option>
                                <option value="Urlaub">🏖️ Urlaub</option>
                                <option value="Feiertag">🎉 Feiertag</option>
                                <option value="Überstunden">⏰ Überstunden</option>
                                <option value="Sonstige">📋 Sonstige</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Datum</label>
                            <input type="date" name="date" required class="w-full p-3 border border-gray-300 rounded-lg" value="{datetime.now().strftime('%Y-%m-%d')}">
                        </div>
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Startzeit</label>
                                <input type="time" name="start_time" required class="w-full p-3 border border-gray-300 rounded-lg">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Endzeit</label>
                                <input type="time" name="end_time" class="w-full p-3 border border-gray-300 rounded-lg">
                            </div>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Standort</label>
                            <input type="text" name="location" required class="w-full p-3 border border-gray-300 rounded-lg" placeholder="z.B. Hauptbahnhof, München">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Aufzug ID (optional)</label>
                            <input type="text" name="elevator_id" class="w-full p-3 border border-gray-300 rounded-lg" placeholder="z.B. E001">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Bemerkungen</label>
                            <textarea name="notes" rows="3" class="w-full p-3 border border-gray-300 rounded-lg" placeholder="Details zur Tätigkeit..."></textarea>
                        </div>
                        <div class="flex items-center">
                            <input type="checkbox" name="emergency_week" id="emergency_week" class="h-4 w-4 text-blue-600 border-gray-300 rounded">
                            <label for="emergency_week" class="ml-2 text-sm text-gray-700">Notdienstwoche</label>
                        </div>
                        <div class="flex justify-end space-x-3">
                            <button type="button" onclick="closeNewZeiterfassungModal()" class="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50">
                                Abbrechen
                            </button>
                            <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                                <i class="fas fa-save mr-2"></i>Speichern
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <script>
            // Zeiterfassung laden
            async function loadZeiterfassung() {{
                try {{
                    const response = await fetch('/api/zeiterfassung');
                    const zeiterfassung = await response.json();
                    
                    updateZeiterfassungList(zeiterfassung);
                    updateZeiterfassungStatistics(zeiterfassung);
                }} catch (error) {{
                    console.error('Fehler beim Laden der Zeiterfassung:', error);
                }}
            }}
            
            function updateZeiterfassungList(zeiterfassung) {{
                const container = document.getElementById('zeiterfassung-container');
                container.innerHTML = '';
                
                if (zeiterfassung.length === 0) {{
                    container.innerHTML = `
                        <div class="text-center py-8 text-gray-500">
                            <i class="fas fa-clock text-4xl mb-4"></i>
                            <p>Keine Zeiterfassung Einträge gefunden</p>
                        </div>
                    `;
                    return;
                }}
                
                zeiterfassung.forEach(entry => {{
                    const statusClass = entry.status === 'completed' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800';
                    const emergencyClass = entry.emergency_week ? 'bg-red-100 text-red-800' : '';
                    
                    const entryElement = document.createElement('div');
                    entryElement.className = 'border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow';
                    entryElement.innerHTML = `
                        <div class="flex justify-between items-start mb-3">
                            <div class="flex-1">
                                <h3 class="font-semibold text-gray-900">${{entry.activity_type}}</h3>
                                <div class="flex items-center space-x-2 mt-1">
                                    <span class="px-2 py-1 text-xs font-semibold rounded-full ${{statusClass}}">
                                        ${{entry.status === 'completed' ? 'Abgeschlossen' : 'Ausstehend'}}
                                    </span>
                                    ${{entry.emergency_week ? `<span class="px-2 py-1 text-xs font-semibold rounded-full ${{emergencyClass}}">Notdienst</span>` : ''}}
                                </div>
                            </div>
                            <div class="flex space-x-2">
                                <button onclick="deleteZeiterfassung(${{entry.id}})" class="text-red-600 hover:text-red-800">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </div>
                        <p class="text-sm text-gray-600 mb-3">${{entry.location}}</p>
                        ${{entry.elevator_id ? `<p class="text-sm text-gray-500 mb-3">Aufzug: ${{entry.elevator_id}}</p>` : ''}}
                        ${{entry.notes ? `<p class="text-sm text-gray-500 mb-3">${{entry.notes}}</p>` : ''}}
                        <div class="flex justify-between items-center text-sm text-gray-500">
                            <span>${{entry.date}} - ${{entry.start_time}}${{entry.end_time ? ` bis ${{entry.end_time}}` : ''}}</span>
                            <span class="text-gray-400">ID: ${{entry.id}}</span>
                        </div>
                    `;
                    container.appendChild(entryElement);
                }});
            }}
            
            function updateZeiterfassungStatistics(zeiterfassung) {{
                const total = zeiterfassung.length;
                const pending = zeiterfassung.filter(e => e.status === 'pending').length;
                const completed = zeiterfassung.filter(e => e.status === 'completed').length;
                const emergency = zeiterfassung.filter(e => e.emergency_week).length;
                
                document.getElementById('total-entries').textContent = total;
                document.getElementById('pending-entries').textContent = pending;
                document.getElementById('completed-entries').textContent = completed;
                document.getElementById('emergency-entries').textContent = emergency;
            }}
            
            async function deleteZeiterfassung(id) {{
                if (!confirm('Zeiterfassung Eintrag wirklich löschen?')) return;
                
                try {{
                    const response = await fetch(`/api/zeiterfassung/${{id}}`, {{
                        method: 'DELETE'
                    }});
                    
                    if (response.ok) {{
                        loadZeiterfassung();
                    }}
                }} catch (error) {{
                    console.error('Fehler beim Löschen:', error);
                }}
            }}
            
            function openNewZeiterfassungModal() {{
                document.getElementById('new-zeiterfassung-modal').classList.remove('hidden');
            }}
            
            function closeNewZeiterfassungModal() {{
                document.getElementById('new-zeiterfassung-modal').classList.add('hidden');
                document.getElementById('new-zeiterfassung-form').reset();
            }}
            
            // Formular Submit
            document.getElementById('new-zeiterfassung-form').addEventListener('submit', async function(e) {{
                e.preventDefault();
                
                const formData = new FormData(this);
                const data = {{
                    activity_type: formData.get('activity_type'),
                    date: formData.get('date'),
                    start_time: formData.get('start_time'),
                    end_time: formData.get('end_time'),
                    location: formData.get('location'),
                    elevator_id: formData.get('elevator_id'),
                    notes: formData.get('notes'),
                    emergency_week: formData.get('emergency_week') === 'on'
                }};
                
                try {{
                    const response = await fetch('/api/zeiterfassung', {{
                        method: 'POST',
                        headers: {{ 'Content-Type': 'application/json' }},
                        body: JSON.stringify(data)
                    }});
                    
                    if (response.ok) {{
                        closeNewZeiterfassungModal();
                        loadZeiterfassung();
                    }}
                }} catch (error) {{
                    console.error('Fehler beim Erstellen:', error);
                }}
            }});
            
            // Initial laden
            document.addEventListener('DOMContentLoaded', function() {{
                loadZeiterfassung();
            }});
        </script>
    </body>
    </html>
    """

@app.route('/arbeitszeit')
def arbeitszeit():
    if 'user' not in session:
        return redirect('/login')
    if session['user'].get('role') == 'Admin':
        return redirect('/buero')
    
    user = session['user']
    return f"""
    <!DOCTYPE html>
    <html lang="de">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Arbeitszeit - Monteur Dashboard</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    </head>
    <body class="bg-gray-50">
        <!-- Header -->
        <header class="bg-blue-600 text-white shadow-lg">
            <div class="container mx-auto px-4 py-3">
                <div class="flex justify-between items-center">
                    <div class="flex items-center space-x-4">
                        <i class="fas fa-clock text-2xl"></i>
                        <h1 class="text-xl font-bold">Arbeitszeit</h1>
                    </div>
                    <div class="flex items-center space-x-4">
                        <span class="text-sm">Willkommen, {user['name']}</span>
                        <a href="/logout" class="bg-red-500 hover:bg-red-600 px-3 py-1 rounded text-sm">
                            <i class="fas fa-sign-out-alt mr-1"></i>Abmelden
                        </a>
                    </div>
                </div>
            </div>
        </header>

        <!-- Navigation -->
        <nav class="bg-white shadow-sm border-b">
            <div class="container mx-auto px-4">
                <div class="flex space-x-8 py-3">
                    <a href="/" class="text-gray-600 hover:text-blue-600">
                        <i class="fas fa-home mr-2"></i>Dashboard
                    </a>
                    <a href="/zeiterfassung" class="text-gray-600 hover:text-blue-600">
                        <i class="fas fa-stopwatch mr-2"></i>Zeiterfassung
                    </a>
                    <a href="/arbeitszeit" class="text-blue-600 font-semibold border-b-2 border-blue-600 pb-2">
                        <i class="fas fa-clock mr-2"></i>Arbeitszeit
                    </a>
                    <a href="/meine-auftraege" class="text-gray-600 hover:text-blue-600">
                        <i class="fas fa-tasks mr-2"></i>Meine Aufträge
                    </a>
                    <a href="/urlaub" class="text-gray-600 hover:text-blue-600">
                        <i class="fas fa-umbrella-beach mr-2"></i>Urlaub
                    </a>
                </div>
            </div>
        </nav>

        <!-- Main Content -->
        <main class="container mx-auto px-4 py-6">
            <!-- Statistiken -->
            <div class="bg-white rounded-lg shadow-md p-6 mb-6">
                <div class="flex flex-wrap items-center justify-between mb-4">
                    <h2 class="text-2xl font-bold text-gray-800">
                        <i class="fas fa-clock mr-2 text-blue-600"></i>Arbeitszeit Übersicht
                    </h2>
                    <button onclick="openNewArbeitszeitModal()" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg">
                        <i class="fas fa-plus mr-2"></i>Neuer Eintrag
                    </button>
                </div>
                
                <!-- Statistiken -->
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                    <div class="bg-blue-50 p-4 rounded-lg text-center">
                        <div class="text-2xl font-bold text-blue-600" id="total-hours">0h</div>
                        <div class="text-sm text-gray-600">Diese Woche</div>
                    </div>
                    <div class="bg-green-50 p-4 rounded-lg text-center">
                        <div class="text-2xl font-bold text-green-600" id="avg-hours">0h</div>
                        <div class="text-sm text-gray-600">Durchschnitt/Tag</div>
                    </div>
                    <div class="bg-yellow-50 p-4 rounded-lg text-center">
                        <div class="text-2xl font-bold text-yellow-600" id="overtime-hours">0h</div>
                        <div class="text-sm text-gray-600">Überstunden</div>
                    </div>
                    <div class="bg-purple-50 p-4 rounded-lg text-center">
                        <div class="text-2xl font-bold text-purple-600" id="workdays">0</div>
                        <div class="text-sm text-gray-600">Arbeitstage</div>
                    </div>
                </div>
                
                <!-- Filter -->
                <div class="flex flex-wrap gap-4 mb-6">
                    <div class="flex items-center space-x-2">
                        <label class="text-sm font-medium text-gray-700">Von:</label>
                        <input type="date" id="start-date" onchange="loadArbeitszeit()" class="border border-gray-300 rounded px-3 py-1 text-sm">
                    </div>
                    <div class="flex items-center space-x-2">
                        <label class="text-sm font-medium text-gray-700">Bis:</label>
                        <input type="date" id="end-date" onchange="loadArbeitszeit()" class="border border-gray-300 rounded px-3 py-1 text-sm">
                    </div>
                </div>
            </div>
            
            <!-- Arbeitszeit Tabelle -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h3 class="text-lg font-semibold mb-4 text-gray-800">Arbeitszeit Einträge</h3>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Datum</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Start</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ende</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Dauer</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Notdienst</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Aktionen</th>
                            </tr>
                        </thead>
                        <tbody id="arbeitszeit-tbody" class="bg-white divide-y divide-gray-200">
                            <!-- Einträge werden hier dynamisch geladen -->
                        </tbody>
                    </table>
                </div>
            </div>
        </main>

        <!-- Neuer Arbeitszeit Modal -->
        <div id="new-arbeitszeit-modal" class="fixed inset-0 bg-black bg-opacity-50 hidden z-50">
            <div class="flex items-center justify-center min-h-screen p-4">
                <div class="bg-white rounded-lg shadow-xl max-w-md w-full">
                    <div class="flex justify-between items-center p-6 border-b">
                        <h3 class="text-lg font-semibold text-gray-900">Neuer Arbeitszeit Eintrag</h3>
                        <button onclick="closeNewArbeitszeitModal()" class="text-gray-400 hover:text-gray-600">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    <form id="new-arbeitszeit-form" class="p-6 space-y-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Datum</label>
                            <input type="date" name="datum" required class="w-full p-3 border border-gray-300 rounded-lg" value="{datetime.now().strftime('%Y-%m-%d')}">
                        </div>
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Startzeit</label>
                                <input type="time" name="start" required class="w-full p-3 border border-gray-300 rounded-lg">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Endzeit</label>
                                <input type="time" name="stop" class="w-full p-3 border border-gray-300 rounded-lg">
                            </div>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Dauer (optional)</label>
                            <input type="text" name="dauer" class="w-full p-3 border border-gray-300 rounded-lg" placeholder="z.B. 8:00">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Bemerkung</label>
                            <textarea name="bemerkung" rows="3" class="w-full p-3 border border-gray-300 rounded-lg" placeholder="Bemerkung zur Arbeitszeit..."></textarea>
                        </div>
                        <div class="flex items-center">
                            <input type="checkbox" name="notdienstwoche" id="notdienstwoche" class="h-4 w-4 text-blue-600 border-gray-300 rounded">
                            <label for="notdienstwoche" class="ml-2 text-sm text-gray-700">Notdienstwoche</label>
                        </div>
                        <div class="flex justify-end space-x-3">
                            <button type="button" onclick="closeNewArbeitszeitModal()" class="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50">
                                Abbrechen
                            </button>
                            <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                                <i class="fas fa-save mr-2"></i>Speichern
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <script>
            // Arbeitszeit laden
            async function loadArbeitszeit() {{
                const startDate = document.getElementById('start-date').value;
                const endDate = document.getElementById('end-date').value;
                
                try {{
                    let url = '/api/arbeitszeit';
                    const params = new URLSearchParams();
                    if (startDate) params.append('start_date', startDate);
                    if (endDate) params.append('end_date', endDate);
                    if (params.toString()) url += '?' + params.toString();
                    
                    const response = await fetch(url);
                    const arbeitszeit = await response.json();
                    
                    updateArbeitszeitTable(arbeitszeit);
                    updateArbeitszeitStatistics(arbeitszeit);
                }} catch (error) {{
                    console.error('Fehler beim Laden der Arbeitszeit:', error);
                }}
            }}
            
            function updateArbeitszeitTable(arbeitszeit) {{
                const tbody = document.getElementById('arbeitszeit-tbody');
                tbody.innerHTML = '';
                
                if (arbeitszeit.length === 0) {{
                    tbody.innerHTML = `
                        <tr>
                            <td colspan="6" class="px-6 py-4 text-center text-gray-500">
                                <i class="fas fa-clock text-2xl mb-2"></i>
                                <p>Keine Arbeitszeit Einträge gefunden</p>
                            </td>
                        </tr>
                    `;
                    return;
                }}
                
                arbeitszeit.forEach(entry => {{
                    const notdienstClass = entry.notdienstwoche ? 'bg-red-100 text-red-800' : 'bg-gray-100 text-gray-800';
                    const notdienstText = entry.notdienstwoche ? 'Ja' : 'Nein';
                    
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${{entry.datum}}</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${{entry.start}}</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${{entry.stop || '-'}}</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${{entry.dauer || '-'}}</td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${{notdienstClass}}">
                                ${{notdienstText}}
                            </span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            <button onclick="deleteArbeitszeit('${{entry.id}}')" class="text-red-600 hover:text-red-800">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    `;
                    tbody.appendChild(row);
                }});
            }}
            
            function updateArbeitszeitStatistics(arbeitszeit) {{
                // Berechne Statistiken
                const totalHours = arbeitszeit.reduce((sum, entry) => {{
                    if (entry.dauer) {{
                        const [hours, minutes] = entry.dauer.split(':').map(Number);
                        return sum + hours + minutes / 60;
                    }}
                    return sum;
                }}, 0);
                
                const workdays = arbeitszeit.length;
                const avgHours = workdays > 0 ? totalHours / workdays : 0;
                const overtimeHours = Math.max(0, totalHours - (workdays * 8)); // 8h pro Tag als Standard
                
                document.getElementById('total-hours').textContent = `${{totalHours.toFixed(1)}}h`;
                document.getElementById('avg-hours').textContent = `${{avgHours.toFixed(1)}}h`;
                document.getElementById('overtime-hours').textContent = `${{overtimeHours.toFixed(1)}}h`;
                document.getElementById('workdays').textContent = workdays;
            }}
            
            async function deleteArbeitszeit(id) {{
                if (!confirm('Arbeitszeit Eintrag wirklich löschen?')) return;
                
                try {{
                    const response = await fetch(`/api/arbeitszeit/${{id}}`, {{
                        method: 'DELETE'
                    }});
                    
                    if (response.ok) {{
                        loadArbeitszeit();
                    }}
                }} catch (error) {{
                    console.error('Fehler beim Löschen:', error);
                }}
            }}
            
            function openNewArbeitszeitModal() {{
                document.getElementById('new-arbeitszeit-modal').classList.remove('hidden');
            }}
            
            function closeNewArbeitszeitModal() {{
                document.getElementById('new-arbeitszeit-modal').classList.add('hidden');
                document.getElementById('new-arbeitszeit-form').reset();
            }}
            
            // Formular Submit
            document.getElementById('new-arbeitszeit-form').addEventListener('submit', async function(e) {{
                e.preventDefault();
                
                const formData = new FormData(this);
                const data = {{
                    datum: formData.get('datum'),
                    start: formData.get('start'),
                    stop: formData.get('stop'),
                    dauer: formData.get('dauer'),
                    bemerkung: formData.get('bemerkung'),
                    notdienstwoche: formData.get('notdienstwoche') === 'on'
                }};
                
                try {{
                    const response = await fetch('/api/arbeitszeit', {{
                        method: 'POST',
                        headers: {{ 'Content-Type': 'application/json' }},
                        body: JSON.stringify(data)
                    }});
                    
                    if (response.ok) {{
                        closeNewArbeitszeitModal();
                        loadArbeitszeit();
                    }}
                }} catch (error) {{
                    console.error('Fehler beim Erstellen:', error);
                }}
            }});
            
            // Initial laden
            document.addEventListener('DOMContentLoaded', function() {{
                // Setze Standard-Datum (letzte 7 Tage)
                const today = new Date();
                const weekAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);
                
                document.getElementById('start-date').value = weekAgo.toISOString().split('T')[0];
                document.getElementById('end-date').value = today.toISOString().split('T')[0];
                
                loadArbeitszeit();
            }});
        </script>
    </body>
    </html>
    """

@app.route('/meine-auftraege')
def meine_auftraege():
    if 'user' not in session:
        return redirect('/login')
    if session['user'].get('role') == 'Admin':
        return redirect('/buero')
    
    user = session['user']
    return f"""
    <!DOCTYPE html>
    <html lang="de">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Meine Aufträge - Monteur Dashboard</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    </head>
    <body class="bg-gray-50">
        <!-- Header -->
        <header class="bg-blue-600 text-white shadow-lg">
            <div class="container mx-auto px-4 py-3">
                <div class="flex justify-between items-center">
                    <div class="flex items-center space-x-4">
                        <i class="fas fa-tasks text-2xl"></i>
                        <h1 class="text-xl font-bold">Meine Aufträge</h1>
                    </div>
                    <div class="flex items-center space-x-4">
                        <span class="text-sm">Willkommen, {user['name']}</span>
                        <a href="/logout" class="bg-red-500 hover:bg-red-600 px-3 py-1 rounded text-sm">
                            <i class="fas fa-sign-out-alt mr-1"></i>Abmelden
                        </a>
                    </div>
                </div>
            </div>
        </header>

        <!-- Navigation -->
        <nav class="bg-white shadow-sm border-b">
            <div class="container mx-auto px-4">
                <div class="flex space-x-8 py-3">
                    <a href="/" class="text-gray-600 hover:text-blue-600">
                        <i class="fas fa-home mr-2"></i>Dashboard
                    </a>
                    <a href="/zeiterfassung" class="text-gray-600 hover:text-blue-600">
                        <i class="fas fa-stopwatch mr-2"></i>Zeiterfassung
                    </a>
                    <a href="/arbeitszeit" class="text-gray-600 hover:text-blue-600">
                        <i class="fas fa-clock mr-2"></i>Arbeitszeit
                    </a>
                    <a href="/meine-auftraege" class="text-blue-600 font-semibold border-b-2 border-blue-600 pb-2">
                        <i class="fas fa-tasks mr-2"></i>Meine Aufträge
                    </a>
                    <a href="/urlaub" class="text-gray-600 hover:text-blue-600">
                        <i class="fas fa-umbrella-beach mr-2"></i>Urlaub
                    </a>
                </div>
            </div>
        </nav>

        <!-- Main Content -->
        <main class="container mx-auto px-4 py-6">
            <!-- Filter und Statistiken -->
            <div class="bg-white rounded-lg shadow-md p-6 mb-6">
                <div class="flex flex-wrap items-center justify-between mb-4">
                    <h2 class="text-2xl font-bold text-gray-800">
                        <i class="fas fa-tasks mr-2 text-blue-600"></i>Meine Aufträge
                    </h2>
                    <button onclick="openNewAuftragModal()" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg">
                        <i class="fas fa-plus mr-2"></i>Neuer Auftrag
                    </button>
                </div>
                
                <!-- Filter -->
                <div class="flex flex-wrap gap-4 mb-6">
                    <div class="flex items-center space-x-2">
                        <label class="text-sm font-medium text-gray-700">Status:</label>
                        <select id="status-filter" onchange="loadAuftraege()" class="border border-gray-300 rounded px-3 py-1 text-sm">
                            <option value="all">Alle</option>
                            <option value="pending">Offen</option>
                            <option value="done">Erledigt</option>
                        </select>
                    </div>
                    <div class="flex items-center space-x-2">
                        <label class="text-sm font-medium text-gray-700">Priorität:</label>
                        <select id="priority-filter" onchange="loadAuftraege()" class="border border-gray-300 rounded px-3 py-1 text-sm">
                            <option value="all">Alle</option>
                            <option value="critical">Kritisch</option>
                            <option value="high">Hoch</option>
                            <option value="normal">Normal</option>
                            <option value="low">Niedrig</option>
                        </select>
                    </div>
                </div>
                
                <!-- Statistiken -->
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                    <div class="bg-blue-50 p-4 rounded-lg text-center">
                        <div class="text-2xl font-bold text-blue-600" id="total-count">0</div>
                        <div class="text-sm text-gray-600">Gesamt</div>
                    </div>
                    <div class="bg-yellow-50 p-4 rounded-lg text-center">
                        <div class="text-2xl font-bold text-yellow-600" id="pending-count">0</div>
                        <div class="text-sm text-gray-600">Offen</div>
                    </div>
                    <div class="bg-green-50 p-4 rounded-lg text-center">
                        <div class="text-2xl font-bold text-green-600" id="done-count">0</div>
                        <div class="text-sm text-gray-600">Erledigt</div>
                    </div>
                    <div class="bg-red-50 p-4 rounded-lg text-center">
                        <div class="text-2xl font-bold text-red-600" id="critical-count">0</div>
                        <div class="text-sm text-gray-600">Kritisch</div>
                    </div>
                </div>
            </div>
            
            <!-- Aufträge Liste -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <div id="auftraege-container" class="space-y-4">
                    <!-- Aufträge werden hier dynamisch geladen -->
                </div>
            </div>
        </main>

        <!-- Neuer Auftrag Modal -->
        <div id="new-auftrag-modal" class="fixed inset-0 bg-black bg-opacity-50 hidden z-50">
            <div class="flex items-center justify-center min-h-screen p-4">
                <div class="bg-white rounded-lg shadow-xl max-w-md w-full">
                    <div class="flex justify-between items-center p-6 border-b">
                        <h3 class="text-lg font-semibold text-gray-900">Neuer Auftrag</h3>
                        <button onclick="closeNewAuftragModal()" class="text-gray-400 hover:text-gray-600">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    <form id="new-auftrag-form" class="p-6 space-y-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Art</label>
                            <select name="art" required class="w-full p-3 border border-gray-300 rounded-lg">
                                <option value="Reparatur">🔧 Reparatur</option>
                                <option value="Wartung">⚙️ Wartung</option>
                                <option value="Notdienst">🚨 Notdienst</option>
                                <option value="Installation">🔨 Installation</option>
                                <option value="Inspektion">📋 Inspektion</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Uhrzeit</label>
                            <input type="time" name="uhrzeit" required class="w-full p-3 border border-gray-300 rounded-lg">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Standort</label>
                            <input type="text" name="standort" required class="w-full p-3 border border-gray-300 rounded-lg" placeholder="z.B. Hauptbahnhof, München">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Details</label>
                            <textarea name="details" rows="3" class="w-full p-3 border border-gray-300 rounded-lg" placeholder="Beschreibung der Tätigkeit..."></textarea>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Priorität</label>
                            <select name="priority" class="w-full p-3 border border-gray-300 rounded-lg">
                                <option value="normal">Normal</option>
                                <option value="high">Hoch</option>
                                <option value="critical">Kritisch</option>
                                <option value="low">Niedrig</option>
                            </select>
                        </div>
                        <div class="flex justify-end space-x-3">
                            <button type="button" onclick="closeNewAuftragModal()" class="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50">
                                Abbrechen
                            </button>
                            <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                                <i class="fas fa-save mr-2"></i>Speichern
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <script>
            // Aufträge laden
            async function loadAuftraege() {{
                const statusFilter = document.getElementById('status-filter').value;
                const priorityFilter = document.getElementById('priority-filter').value;
                
                try {{
                    const response = await fetch(`/api/auftraege?status=${{statusFilter}}&priority=${{priorityFilter}}`);
                    const auftraege = await response.json();
                    
                    updateAuftraegeList(auftraege);
                    updateStatistics(auftraege);
                }} catch (error) {{
                    console.error('Fehler beim Laden der Aufträge:', error);
                }}
            }}
            
            function updateAuftraegeList(auftraege) {{
                const container = document.getElementById('auftraege-container');
                container.innerHTML = '';
                
                if (auftraege.length === 0) {{
                    container.innerHTML = `
                        <div class="text-center py-8 text-gray-500">
                            <i class="fas fa-inbox text-4xl mb-4"></i>
                            <p>Keine Aufträge gefunden</p>
                        </div>
                    `;
                    return;
                }}
                
                auftraege.forEach(auftrag => {{
                    const statusClass = auftrag.done ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800';
                    const statusText = auftrag.done ? 'Erledigt' : 'Offen';
                    const priorityClass = getPriorityClass(auftrag.priority);
                    const priorityText = getPriorityText(auftrag.priority);
                    
                    const auftragElement = document.createElement('div');
                    auftragElement.className = 'border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow';
                    auftragElement.innerHTML = `
                        <div class="flex justify-between items-start mb-3">
                            <div class="flex-1">
                                <h3 class="font-semibold text-gray-900">${{auftrag.art}}</h3>
                                <div class="flex items-center space-x-2 mt-1">
                                    <span class="px-2 py-1 text-xs font-semibold rounded-full ${{statusClass}}">
                                        ${{statusText}}
                                    </span>
                                    <span class="px-2 py-1 text-xs font-semibold rounded-full ${{priorityClass}}">
                                        ${{priorityText}}
                                    </span>
                                </div>
                            </div>
                            <div class="flex space-x-2">
                                <button onclick="toggleAuftragStatus(${{auftrag.id}}, ${{!auftrag.done}})" class="text-blue-600 hover:text-blue-800">
                                    <i class="fas fa-${{auftrag.done ? 'undo' : 'check'}}"></i>
                                </button>
                                <button onclick="deleteAuftrag(${{auftrag.id}})" class="text-red-600 hover:text-red-800">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </div>
                        <p class="text-sm text-gray-600 mb-3">${{auftrag.standort}}</p>
                        ${{auftrag.details ? `<p class="text-sm text-gray-500 mb-3">${{auftrag.details}}</p>` : ''}}
                        <div class="flex justify-between items-center text-sm text-gray-500">
                            <span>${{auftrag.uhrzeit}}</span>
                            <span class="text-gray-400">ID: ${{auftrag.id}}</span>
                        </div>
                    `;
                    container.appendChild(auftragElement);
                }});
            }}
            
            function updateStatistics(auftraege) {{
                const total = auftraege.length;
                const pending = auftraege.filter(a => !a.done).length;
                const done = auftraege.filter(a => a.done).length;
                const critical = auftraege.filter(a => a.priority === 'critical').length;
                
                document.getElementById('total-count').textContent = total;
                document.getElementById('pending-count').textContent = pending;
                document.getElementById('done-count').textContent = done;
                document.getElementById('critical-count').textContent = critical;
            }}
            
            function getPriorityClass(priority) {{
                switch(priority) {{
                    case 'critical': return 'bg-red-100 text-red-800';
                    case 'high': return 'bg-orange-100 text-orange-800';
                    case 'normal': return 'bg-blue-100 text-blue-800';
                    case 'low': return 'bg-gray-100 text-gray-800';
                    default: return 'bg-blue-100 text-blue-800';
                }}
            }}
            
            function getPriorityText(priority) {{
                switch(priority) {{
                    case 'critical': return 'Kritisch';
                    case 'high': return 'Hoch';
                    case 'normal': return 'Normal';
                    case 'low': return 'Niedrig';
                    default: return 'Normal';
                }}
            }}
            
            async function toggleAuftragStatus(id, done) {{
                try {{
                    const response = await fetch(`/api/auftraege/${{id}}`, {{
                        method: 'PUT',
                        headers: {{ 'Content-Type': 'application/json' }},
                        body: JSON.stringify({{ done: done }})
                    }});
                    
                    if (response.ok) {{
                        loadAuftraege();
                    }}
                }} catch (error) {{
                    console.error('Fehler beim Aktualisieren:', error);
                }}
            }}
            
            async function deleteAuftrag(id) {{
                if (!confirm('Auftrag wirklich löschen?')) return;
                
                try {{
                    const response = await fetch(`/api/auftraege/${{id}}`, {{
                        method: 'DELETE'
                    }});
                    
                    if (response.ok) {{
                        loadAuftraege();
                    }}
                }} catch (error) {{
                    console.error('Fehler beim Löschen:', error);
                }}
            }}
            
            function openNewAuftragModal() {{
                document.getElementById('new-auftrag-modal').classList.remove('hidden');
            }}
            
            function closeNewAuftragModal() {{
                document.getElementById('new-auftrag-modal').classList.add('hidden');
                document.getElementById('new-auftrag-form').reset();
            }}
            
            // Formular Submit
            document.getElementById('new-auftrag-form').addEventListener('submit', async function(e) {{
                e.preventDefault();
                
                const formData = new FormData(this);
                const data = {{
                    art: formData.get('art'),
                    uhrzeit: formData.get('uhrzeit'),
                    standort: formData.get('standort'),
                    details: formData.get('details'),
                    priority: formData.get('priority')
                }};
                
                try {{
                    const response = await fetch('/api/auftraege', {{
                        method: 'POST',
                        headers: {{ 'Content-Type': 'application/json' }},
                        body: JSON.stringify(data)
                    }});
                    
                    if (response.ok) {{
                        closeNewAuftragModal();
                        loadAuftraege();
                    }}
                }} catch (error) {{
                    console.error('Fehler beim Erstellen:', error);
                }}
            }});
            
            // Initial laden
            document.addEventListener('DOMContentLoaded', function() {{
                loadAuftraege();
            }});
        </script>
    </body>
    </html>
    """

@app.route('/urlaub')
def urlaub():
    if 'user' not in session:
        return redirect('/login')
    if session['user'].get('role') == 'Admin':
        return redirect('/buero')
    
    user = session['user']
    return f"""
    <!DOCTYPE html>
    <html lang="de">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Urlaub - Monteur Dashboard</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    </head>
    <body class="bg-gray-50">
        <!-- Header -->
        <header class="bg-blue-600 text-white shadow-lg">
            <div class="container mx-auto px-4 py-3">
                <div class="flex justify-between items-center">
                    <div class="flex items-center space-x-4">
                        <i class="fas fa-umbrella-beach text-2xl"></i>
                        <h1 class="text-xl font-bold">Urlaub</h1>
                    </div>
                    <div class="flex items-center space-x-4">
                        <span class="text-sm">Willkommen, {user['name']}</span>
                        <a href="/logout" class="bg-red-500 hover:bg-red-600 px-3 py-1 rounded text-sm">
                            <i class="fas fa-sign-out-alt mr-1"></i>Abmelden
                        </a>
                    </div>
                </div>
            </div>
        </header>

        <!-- Navigation -->
        <nav class="bg-white shadow-sm border-b">
            <div class="container mx-auto px-4">
                <div class="flex space-x-8 py-3">
                    <a href="/" class="text-gray-600 hover:text-blue-600">
                        <i class="fas fa-home mr-2"></i>Dashboard
                    </a>
                    <a href="/zeiterfassung" class="text-gray-600 hover:text-blue-600">
                        <i class="fas fa-stopwatch mr-2"></i>Zeiterfassung
                    </a>
                    <a href="/arbeitszeit" class="text-gray-600 hover:text-blue-600">
                        <i class="fas fa-clock mr-2"></i>Arbeitszeit
                    </a>
                    <a href="/meine-auftraege" class="text-gray-600 hover:text-blue-600">
                        <i class="fas fa-tasks mr-2"></i>Meine Aufträge
                    </a>
                    <a href="/urlaub" class="text-blue-600 font-semibold border-b-2 border-blue-600 pb-2">
                        <i class="fas fa-umbrella-beach mr-2"></i>Urlaub
                    </a>
                </div>
            </div>
        </nav>

        <!-- Main Content -->
        <main class="container mx-auto px-4 py-6">
            <!-- Statistiken -->
            <div class="bg-white rounded-lg shadow-md p-6 mb-6">
                <div class="flex flex-wrap items-center justify-between mb-4">
                    <h2 class="text-2xl font-bold text-gray-800">
                        <i class="fas fa-umbrella-beach mr-2 text-blue-600"></i>Urlaub & Feiertage
                    </h2>
                    <button onclick="openNewUrlaubModal()" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg">
                        <i class="fas fa-plus mr-2"></i>Neuer Antrag
                    </button>
                </div>
                
                <!-- Urlaub Statistiken -->
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                    <div class="bg-blue-50 p-4 rounded-lg text-center">
                        <div class="text-2xl font-bold text-blue-600" id="total-days">30</div>
                        <div class="text-sm text-gray-600">Verfügbare Tage</div>
                    </div>
                    <div class="bg-green-50 p-4 rounded-lg text-center">
                        <div class="text-2xl font-bold text-green-600" id="taken-days">0</div>
                        <div class="text-sm text-gray-600">Genommene Tage</div>
                    </div>
                    <div class="bg-yellow-50 p-4 rounded-lg text-center">
                        <div class="text-2xl font-bold text-yellow-600" id="pending-days">0</div>
                        <div class="text-sm text-gray-600">Ausstehend</div>
                    </div>
                    <div class="bg-purple-50 p-4 rounded-lg text-center">
                        <div class="text-2xl font-bold text-purple-600" id="remaining-days">30</div>
                        <div class="text-sm text-gray-600">Verbleibende Tage</div>
                    </div>
                </div>
            </div>
            
            <!-- Urlaub Liste -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h3 class="text-lg font-semibold mb-4 text-gray-800">Meine Urlaubsanträge</h3>
                <div id="urlaub-container" class="space-y-4">
                    <!-- Urlaub Einträge werden hier dynamisch geladen -->
                </div>
            </div>
        </main>

        <!-- Neuer Urlaub Modal -->
        <div id="new-urlaub-modal" class="fixed inset-0 bg-black bg-opacity-50 hidden z-50">
            <div class="flex items-center justify-center min-h-screen p-4">
                <div class="bg-white rounded-lg shadow-xl max-w-md w-full">
                    <div class="flex justify-between items-center p-6 border-b">
                        <h3 class="text-lg font-semibold text-gray-900">Neuer Urlaubsantrag</h3>
                        <button onclick="closeNewUrlaubModal()" class="text-gray-400 hover:text-gray-600">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    <form id="new-urlaub-form" class="p-6 space-y-4">
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Von</label>
                                <input type="date" name="start_date" required class="w-full p-3 border border-gray-300 rounded-lg">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Bis</label>
                                <input type="date" name="end_date" required class="w-full p-3 border border-gray-300 rounded-lg">
                            </div>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Grund</label>
                            <textarea name="reason" rows="3" class="w-full p-3 border border-gray-300 rounded-lg" placeholder="Urlaubsgrund..."></textarea>
                        </div>
                        <div class="flex justify-end space-x-3">
                            <button type="button" onclick="closeNewUrlaubModal()" class="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50">
                                Abbrechen
                            </button>
                            <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                                <i class="fas fa-paper-plane mr-2"></i>Antrag einreichen
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <script>
            // Urlaub laden
            async function loadUrlaub() {{
                try {{
                    const response = await fetch('/api/urlaub');
                    const urlaub = await response.json();
                    
                    updateUrlaubList(urlaub);
                    updateUrlaubStatistics(urlaub);
                }} catch (error) {{
                    console.error('Fehler beim Laden des Urlaubs:', error);
                }}
            }}
            
            function updateUrlaubList(urlaub) {{
                const container = document.getElementById('urlaub-container');
                container.innerHTML = '';
                
                if (urlaub.length === 0) {{
                    container.innerHTML = `
                        <div class="text-center py-8 text-gray-500">
                            <i class="fas fa-umbrella-beach text-4xl mb-4"></i>
                            <p>Keine Urlaubsanträge gefunden</p>
                        </div>
                    `;
                    return;
                }}
                
                urlaub.forEach(entry => {{
                    const statusClass = getStatusClass(entry.status);
                    const statusText = getStatusText(entry.status);
                    
                    const entryElement = document.createElement('div');
                    entryElement.className = 'border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow';
                    entryElement.innerHTML = `
                        <div class="flex justify-between items-start mb-3">
                            <div class="flex-1">
                                <h3 class="font-semibold text-gray-900">Urlaub vom ${{entry.start_date}} bis ${{entry.end_date}}</h3>
                                <div class="flex items-center space-x-2 mt-1">
                                    <span class="px-2 py-1 text-xs font-semibold rounded-full ${{statusClass}}">
                                        ${{statusText}}
                                    </span>
                                </div>
                            </div>
                            <div class="flex space-x-2">
                                <button onclick="deleteUrlaub(${{entry.id}})" class="text-red-600 hover:text-red-800">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </div>
                        ${{entry.reason ? `<p class="text-sm text-gray-600 mb-3">${{entry.reason}}</p>` : ''}}
                        <div class="flex justify-between items-center text-sm text-gray-500">
                            <span>${{calculateDays(entry.start_date, entry.end_date)}} Tage</span>
                            <span class="text-gray-400">ID: ${{entry.id}}</span>
                        </div>
                    `;
                    container.appendChild(entryElement);
                }});
            }}
            
            function updateUrlaubStatistics(urlaub) {{
                const totalDays = 30; // Standard Urlaubstage
                const takenDays = urlaub.filter(u => u.status === 'approved').reduce((sum, u) => {{
                    return sum + calculateDays(u.start_date, u.end_date);
                }}, 0);
                const pendingDays = urlaub.filter(u => u.status === 'pending').reduce((sum, u) => {{
                    return sum + calculateDays(u.start_date, u.end_date);
                }}, 0);
                const remainingDays = totalDays - takenDays - pendingDays;
                
                document.getElementById('total-days').textContent = totalDays;
                document.getElementById('taken-days').textContent = takenDays;
                document.getElementById('pending-days').textContent = pendingDays;
                document.getElementById('remaining-days').textContent = Math.max(0, remainingDays);
            }}
            
            function calculateDays(startDate, endDate) {{
                const start = new Date(startDate);
                const end = new Date(endDate);
                const diffTime = Math.abs(end - start);
                const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
                return diffDays;
            }}
            
            function getStatusClass(status) {{
                switch(status) {{
                    case 'approved': return 'bg-green-100 text-green-800';
                    case 'pending': return 'bg-yellow-100 text-yellow-800';
                    case 'rejected': return 'bg-red-100 text-red-800';
                    default: return 'bg-gray-100 text-gray-800';
                }}
            }}
            
            function getStatusText(status) {{
                switch(status) {{
                    case 'approved': return 'Genehmigt';
                    case 'pending': return 'Ausstehend';
                    case 'rejected': return 'Abgelehnt';
                    default: return 'Unbekannt';
                }}
            }}
            
            async function deleteUrlaub(id) {{
                if (!confirm('Urlaubsantrag wirklich löschen?')) return;
                
                try {{
                    const response = await fetch(`/api/urlaub/${{id}}`, {{
                        method: 'DELETE'
                    }});
                    
                    if (response.ok) {{
                        loadUrlaub();
                    }}
                }} catch (error) {{
                    console.error('Fehler beim Löschen:', error);
                }}
            }}
            
            function openNewUrlaubModal() {{
                document.getElementById('new-urlaub-modal').classList.remove('hidden');
            }}
            
            function closeNewUrlaubModal() {{
                document.getElementById('new-urlaub-modal').classList.add('hidden');
                document.getElementById('new-urlaub-form').reset();
            }}
            
            // Formular Submit
            document.getElementById('new-urlaub-form').addEventListener('submit', async function(e) {{
                e.preventDefault();
                
                const formData = new FormData(this);
                const data = {{
                    start_date: formData.get('start_date'),
                    end_date: formData.get('end_date'),
                    reason: formData.get('reason')
                }};
                
                try {{
                    const response = await fetch('/api/urlaub', {{
                        method: 'POST',
                        headers: {{ 'Content-Type': 'application/json' }},
                        body: JSON.stringify(data)
                    }});
                    
                    if (response.ok) {{
                        closeNewUrlaubModal();
                        loadUrlaub();
                    }}
                }} catch (error) {{
                    console.error('Fehler beim Erstellen:', error);
                }}
            }});
            
            // Initial laden
            document.addEventListener('DOMContentLoaded', function() {{
                loadUrlaub();
            }});
        </script>
    </body>
    </html>
    """

@app.route('/buero')
@requires_role('Admin')
def buero():
    # Büro-Frontend - Direkt in Azure bereitstellen
    user = session['user']
    return f"""
    <!DOCTYPE html>
    <html lang="de">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Büro Interface - Zeiterfassung System</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    </head>
    <body class="bg-gray-100">
        <!-- Header -->
        <header class="bg-blue-600 text-white shadow-lg">
            <div class="container mx-auto px-4 py-3">
                <div class="flex justify-between items-center">
                    <div class="flex items-center space-x-4">
                        <i class="fas fa-building text-2xl"></i>
                        <h1 class="text-xl font-bold">Büro Interface</h1>
                    </div>
                    <div class="flex items-center space-x-4">
                        <span class="text-sm">Administrator: {user['name']}</span>
                        <a href="/logout" class="bg-red-500 hover:bg-red-600 px-3 py-1 rounded text-sm">
                            <i class="fas fa-sign-out-alt mr-1"></i>Abmelden
                        </a>
                    </div>
                </div>
            </div>
        </header>

        <!-- Main Content -->
        <main class="container mx-auto px-4 py-6">
            <!-- Dashboard Grid -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                
                <!-- Mitarbeiter Übersicht -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h2 class="text-lg font-semibold mb-4 text-gray-800">
                        <i class="fas fa-users mr-2 text-blue-600"></i>Mitarbeiter
                    </h2>
                    <div class="space-y-3">
                        <div class="flex justify-between items-center p-2 bg-green-50 rounded">
                            <span class="text-sm">Aktive Monteure:</span>
                            <span class="font-semibold text-green-800">8</span>
                        </div>
                        <div class="flex justify-between items-center p-2 bg-yellow-50 rounded">
                            <span class="text-sm">Im Einsatz:</span>
                            <span class="font-semibold text-yellow-800">6</span>
                        </div>
                        <div class="flex justify-between items-center p-2 bg-red-50 rounded">
                            <span class="text-sm">Pause:</span>
                            <span class="font-semibold text-red-800">2</span>
                        </div>
                    </div>
                </div>

                <!-- Aufträge Verwaltung -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h2 class="text-lg font-semibold mb-4 text-gray-800">
                        <i class="fas fa-clipboard-list mr-2 text-green-600"></i>Aufträge
                    </h2>
                    <div class="space-y-3">
                        <div class="flex justify-between items-center p-2 bg-blue-50 rounded">
                            <span class="text-sm">Offen:</span>
                            <span class="font-semibold text-blue-800">15</span>
                        </div>
                        <div class="flex justify-between items-center p-2 bg-orange-50 rounded">
                            <span class="text-sm">In Bearbeitung:</span>
                            <span class="font-semibold text-orange-800">8</span>
                        </div>
                        <div class="flex justify-between items-center p-2 bg-green-50 rounded">
                            <span class="text-sm">Abgeschlossen:</span>
                            <span class="font-semibold text-green-800">12</span>
                        </div>
                    </div>
                </div>

                <!-- Schnellaktionen -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h2 class="text-lg font-semibold mb-4 text-gray-800">
                        <i class="fas fa-bolt mr-2 text-orange-500"></i>Schnellaktionen
                    </h2>
                    <div class="space-y-3">
                        <button class="w-full bg-blue-500 hover:bg-blue-600 text-white p-3 rounded">
                            <i class="fas fa-plus mr-2"></i>Neuen Auftrag erstellen
                        </button>
                        <button class="w-full bg-green-500 hover:bg-green-600 text-white p-3 rounded">
                            <i class="fas fa-user-plus mr-2"></i>Mitarbeiter hinzufügen
                        </button>
                        <button class="w-full bg-purple-500 hover:bg-purple-600 text-white p-3 rounded">
                            <i class="fas fa-chart-line mr-2"></i>Berichte generieren
                        </button>
                    </div>
                </div>

                <!-- Zeiterfassung Genehmigung -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h2 class="text-lg font-semibold mb-4 text-gray-800">
                        <i class="fas fa-clock mr-2 text-yellow-600"></i>Genehmigungen
                    </h2>
                    <div class="space-y-3">
                        <div class="flex justify-between items-center p-2 bg-yellow-50 rounded">
                            <span class="text-sm">Ausstehend:</span>
                            <span class="font-semibold text-yellow-800">5</span>
                        </div>
                        <div class="flex justify-between items-center p-2 bg-green-50 rounded">
                            <span class="text-sm">Genehmigt:</span>
                            <span class="font-semibold text-green-800">23</span>
                        </div>
                        <div class="flex justify-between items-center p-2 bg-red-50 rounded">
                            <span class="text-sm">Abgelehnt:</span>
                            <span class="font-semibold text-red-800">2</span>
                        </div>
                    </div>
                </div>

                <!-- Statistiken -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h2 class="text-lg font-semibold mb-4 text-gray-800">
                        <i class="fas fa-chart-bar mr-2 text-purple-600"></i>Statistiken
                    </h2>
                    <div class="space-y-3">
                        <div class="flex justify-between items-center">
                            <span class="text-sm text-gray-600">Durchschnittliche Arbeitszeit:</span>
                            <span class="font-semibold text-gray-800">7.8h</span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-sm text-gray-600">Aufträge pro Tag:</span>
                            <span class="font-semibold text-gray-800">4.2</span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-sm text-gray-600">Effizienz:</span>
                            <span class="font-semibold text-gray-800">94%</span>
                        </div>
                    </div>
                </div>

                <!-- Letzte Aktivitäten -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h2 class="text-lg font-semibold mb-4 text-gray-800">
                        <i class="fas fa-history mr-2 text-gray-600"></i>Aktivitäten
                    </h2>
                    <div class="space-y-2">
                        <div class="flex items-center text-sm">
                            <i class="fas fa-user text-blue-500 mr-2"></i>
                            <span>Monteur Müller hat Arbeitszeit gestartet</span>
                        </div>
                        <div class="flex items-center text-sm">
                            <i class="fas fa-check text-green-500 mr-2"></i>
                            <span>Auftrag #1234 wurde genehmigt</span>
                        </div>
                        <div class="flex items-center text-sm">
                            <i class="fas fa-plus text-purple-500 mr-2"></i>
                            <span>Neuer Auftrag #1235 erstellt</span>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </body>
    </html>
    """

@app.route('/api/status')
def api_status():
    user = session.get('user', None)
    app.logger.debug(f"API Status - Session user: {user}")
    
    # Konvertiere User-Daten in das Format, das das Frontend erwartet
    if user:
        frontend_user = {
            'id': str(user.get('id', '1')),
            'name': user.get('name', 'Unknown'),
            'email': user.get('email', ''),
            'role': user.get('role', 'Monteur'),
            'is_admin': user.get('role') == 'Admin',
            'can_approve': user.get('role') == 'Admin'
        }
    else:
        frontend_user = None
    
    response_data = {
        'message': 'Zeiterfassung App läuft!',
        'status': 'success',
        'environment': 'Azure' if os.getenv('WEBSITE_HOSTNAME') else 'Local',
        'user': frontend_user
    }
    
    return jsonify(response_data)

@app.route('/health')
def health():
    return jsonify({
        'status': 'healthy',
        'message': 'App ist bereit'
    })

print("✅ App bereit für gunicorn")
