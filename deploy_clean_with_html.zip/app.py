from flask import Flask, jsonify, render_template_string
import os

print("🚀 App wird gestartet...")

app = Flask(__name__)

@app.route('/')
def home():
    # HTML-Seite statt JSON
    html = """
    <!DOCTYPE html>
    <html lang="de">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Zeiterfassung System</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                max-width: 800px;
                margin: 0 auto;
                padding: 20px;
                background-color: #f5f5f5;
            }
            .container {
                background: white;
                padding: 30px;
                border-radius: 10px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }
            .header {
                text-align: center;
                color: #2c3e50;
                margin-bottom: 30px;
            }
            .status {
                background: #27ae60;
                color: white;
                padding: 10px;
                border-radius: 5px;
                text-align: center;
                margin: 20px 0;
            }
            .info {
                background: #ecf0f1;
                padding: 15px;
                border-radius: 5px;
                margin: 15px 0;
            }
            .endpoints {
                background: #3498db;
                color: white;
                padding: 15px;
                border-radius: 5px;
                margin: 15px 0;
            }
            .endpoint {
                background: rgba(255,255,255,0.2);
                padding: 8px;
                margin: 5px 0;
                border-radius: 3px;
                font-family: monospace;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>🚀 Zeiterfassung System</h1>
                <h2>Lackner Aufzüge</h2>
            </div>
            
            <div class="status">
                <h3>✅ System Status: Online</h3>
                <p>Die Anwendung läuft erfolgreich auf Azure</p>
            </div>
            
            <div class="info">
                <h3>📊 System Informationen</h3>
                <p><strong>Umgebung:</strong> Azure Cloud</p>
                <p><strong>Status:</strong> Aktiv und bereit</p>
                <p><strong>URL:</strong> https://la-zeiterfassung-fyd4cge3d9e3cac4.azurewebsites.net</p>
                <p><strong>Deployment:</strong> Erfolgreich abgeschlossen</p>
            </div>
            
            <div class="endpoints">
                <h3>🔗 Verfügbare Endpunkte</h3>
                <div class="endpoint">GET / - Diese Startseite</div>
                <div class="endpoint">GET /health - System-Status</div>
                <div class="endpoint">GET /api/status - JSON Status</div>
            </div>
            
            <div class="info">
                <h3>🎯 Nächste Schritte</h3>
                <ul>
                    <li>Frontend (React) mit Backend verbinden</li>
                    <li>MS365 Login aktivieren</li>
                    <li>Datenbank-Funktionen erweitern</li>
                    <li>Zeiterfassung-Features implementieren</li>
                </ul>
            </div>
        </div>
    </body>
    </html>
    """
    return html

@app.route('/api/status')
def api_status():
    return jsonify({
        'message': 'Zeiterfassung App läuft!',
        'status': 'success',
        'environment': 'Azure' if os.getenv('WEBSITE_HOSTNAME') else 'Local'
    })

@app.route('/health')
def health():
    return jsonify({
        'status': 'healthy',
        'message': 'App ist bereit'
    })

print("✅ App bereit für gunicorn")
