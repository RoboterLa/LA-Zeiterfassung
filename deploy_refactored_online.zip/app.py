from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, send_from_directory, send_file
from flask_cors import CORS
from functools import wraps
import os
import logging
import sqlite3
import csv
import uuid
from datetime import datetime, timedelta, date, time
import json
import io
from sqlalchemy import create_engine, Column, Integer, String, Date, Time, Float, Text, DateTime, ForeignKey, CheckConstraint
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
from sqlalchemy.sql import text

logging.basicConfig(level=logging.DEBUG)

print("🚀 Refactored Online App wird gestartet...")

app = Flask(__name__)
app.secret_key = os.getenv('FLASK_SECRET_KEY', 'default_secret_key')

# Azure-kompatible Session-Konfiguration
os.makedirs('/tmp/sessions', exist_ok=True)

# CORS für Frontend-Kommunikation - erweitert für Azure
CORS(app, 
     supports_credentials=True, 
     origins=[
         'http://localhost:3000',
         'https://localhost:3000', 
         'http://192.168.50.99:3000',
         'http://localhost:3001',
         'https://localhost:3001',
         'http://192.168.50.99:3001',
         'https://la-zeiterfassung-fyd4cge3d9e3cac4.azurewebsites.net',
         'http://la-zeiterfassung-fyd4cge3d9e3cac4.azurewebsites.net',
         '*'
     ],
     allow_headers=['Content-Type', 'Authorization'],
     methods=['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'])

# Test-User (in Produktion: Datenbank)
TEST_USERS = {
    'monteur@test.com': {
        'password': 'test123',
        'name': 'Monteur Test',
        'role': 'Monteur'
    },
    'admin@test.com': {
        'password': 'test123',
        'name': 'Admin Test',
        'role': 'Admin'
    }
}

# Datenbank-Funktionen
def get_db_connection():
    conn = sqlite3.connect('zeiterfassung.db')
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Aufträge Tabelle
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS auftraege (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            art TEXT NOT NULL,
            uhrzeit TEXT NOT NULL,
            standort TEXT NOT NULL,
            coords TEXT,
            details TEXT,
            done BOOLEAN DEFAULT FALSE,
            priority TEXT DEFAULT 'normal',
            mitarbeiter TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Zeiterfassung Tabelle
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS zeiterfassung (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            elevator_id TEXT,
            location TEXT,
            date TEXT NOT NULL,
            activity_type TEXT NOT NULL,
            start_time TEXT NOT NULL,
            end_time TEXT,
            emergency_week BOOLEAN DEFAULT FALSE,
            notes TEXT,
            status TEXT DEFAULT 'pending',
            mitarbeiter TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Arbeitszeit Tabelle
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS arbeitszeit (
            id TEXT PRIMARY KEY,
            datum TEXT NOT NULL,
            start TEXT NOT NULL,
            ende TEXT,
            pause TEXT DEFAULT '00:00',
            gesamt TEXT,
            mitarbeiter TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Urlaub Tabelle
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS urlaub (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            mitarbeiter TEXT NOT NULL,
            start_datum TEXT NOT NULL,
            end_datum TEXT NOT NULL,
            tage INTEGER,
            typ TEXT DEFAULT 'Urlaub',
            status TEXT DEFAULT 'pending',
            bemerkung TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    conn.commit()
    conn.close()

# Generic CRUD Service
class GenericCrudService:
    def __init__(self, table_name: str):
        self.table_name = table_name
    
    def get_all(self, filters=None):
        conn = get_db_connection()
        query = f'SELECT * FROM {self.table_name}'
        params = []
        
        if filters:
            conditions = []
            for key, value in filters.items():
                if value != 'all':
                    if key == 'status' and value == 'done':
                        conditions.append('done = 1')
                    elif key == 'status' and value == 'pending':
                        conditions.append('done = 0')
                    else:
                        conditions.append(f'{key} = ?')
                        params.append(value)
            
            if conditions:
                query += ' WHERE ' + ' AND '.join(conditions)
        
        query += ' ORDER BY created_at DESC'
        cursor = conn.execute(query, params)
        rows = cursor.fetchall()
        
        result = []
        for row in rows:
            item = dict(row)
            if 'done' in item:
                item['done'] = bool(item['done'])
            if 'emergency_week' in item:
                item['emergency_week'] = bool(item['emergency_week'])
            result.append(item)
        
        conn.close()
        return result
    
    def create(self, data):
        conn = get_db_connection()
        
        # Füge Benutzer hinzu
        if 'mitarbeiter' not in data and 'user' in session:
            data['mitarbeiter'] = session['user'].get('email')
        
        data = {k: v for k, v in data.items() if v is not None}
        
        columns = ', '.join(data.keys())
        placeholders = ', '.join(['?' for _ in data])
        values = list(data.values())
        
        query = f'INSERT INTO {self.table_name} ({columns}) VALUES ({placeholders})'
        cursor = conn.execute(query, values)
        conn.commit()
        
        new_id = cursor.lastrowid
        conn.close()
        
        return {'success': True, 'id': new_id}
    
    def update(self, item_id, data):
        conn = get_db_connection()
        
        data = {k: v for k, v in data.items() if v is not None}
        
        if not data:
            conn.close()
            return {'error': 'Keine Daten zum Aktualisieren'}
        
        set_clause = ', '.join([f'{k} = ?' for k in data.keys()])
        values = list(data.values()) + [item_id]
        
        query = f'UPDATE {self.table_name} SET {set_clause} WHERE id = ?'
        cursor = conn.execute(query, values)
        conn.commit()
        conn.close()
        
        return {'success': True}
    
    def delete(self, item_id):
        conn = get_db_connection()
        cursor = conn.execute(f'DELETE FROM {self.table_name} WHERE id = ?', (item_id,))
        conn.commit()
        conn.close()
        
        return {'success': True}

# Services
auftraege_service = GenericCrudService('auftraege')
zeiterfassung_service = GenericCrudService('zeiterfassung')
arbeitszeit_service = GenericCrudService('arbeitszeit')
urlaub_service = GenericCrudService('urlaub')

# Auth Decorator
def requires_role(role):
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            if 'user' not in session:
                return jsonify({'error': 'Nicht angemeldet'}), 401
            
            user_role = session['user'].get('role')
            if user_role != role and user_role != 'Admin':
                return jsonify({'error': 'Keine Berechtigung'}), 403
            
            return f(*args, **kwargs)
        return decorated
    return decorator

# API Routes
@app.route('/api/auftraege', methods=['GET', 'POST'])
def api_auftraege():
    if 'user' not in session:
        return jsonify({'error': 'Nicht angemeldet'}), 401
    
    if request.method == 'GET':
        filters = {
            'status': request.args.get('status', 'all'),
            'priority': request.args.get('priority', 'all')
        }
        auftraege = auftraege_service.get_all(filters)
        return jsonify(auftraege)
    
    elif request.method == 'POST':
        data = request.get_json()
        result = auftraege_service.create(data)
        return jsonify(result)

@app.route('/api/auftraege/<int:auftrag_id>', methods=['PUT', 'DELETE'])
def api_auftrag_detail(auftrag_id):
    if 'user' not in session:
        return jsonify({'error': 'Nicht angemeldet'}), 401
    
    if request.method == 'PUT':
        data = request.get_json()
        result = auftraege_service.update(auftrag_id, data)
        return jsonify(result)
    
    elif request.method == 'DELETE':
        result = auftraege_service.delete(auftrag_id)
        return jsonify(result)

@app.route('/api/arbeitszeit', methods=['GET', 'POST'])
def api_arbeitszeit():
    if 'user' not in session:
        return jsonify({'error': 'Nicht angemeldet'}), 401
    
    if request.method == 'GET':
        arbeitszeit = arbeitszeit_service.get_all()
        return jsonify(arbeitszeit)
    
    elif request.method == 'POST':
        data = request.get_json()
        result = arbeitszeit_service.create(data)
        return jsonify(result)

@app.route('/api/arbeitszeit/<string:entry_id>', methods=['PUT', 'DELETE'])
def api_arbeitszeit_detail(entry_id):
    if 'user' not in session:
        return jsonify({'error': 'Nicht angemeldet'}), 401
    
    if request.method == 'PUT':
        data = request.get_json()
        result = arbeitszeit_service.update(entry_id, data)
        return jsonify(result)
    
    elif request.method == 'DELETE':
        result = arbeitszeit_service.delete(entry_id)
        return jsonify(result)

@app.route('/api/urlaub', methods=['GET', 'POST'])
def api_urlaub():
    if 'user' not in session:
        return jsonify({'error': 'Nicht angemeldet'}), 401
    
    if request.method == 'GET':
        urlaub = urlaub_service.get_all()
        return jsonify(urlaub)
    
    elif request.method == 'POST':
        data = request.get_json()
        result = urlaub_service.create(data)
        return jsonify(result)

@app.route('/api/urlaub/<int:entry_id>', methods=['PUT', 'DELETE'])
def api_urlaub_detail(entry_id):
    if 'user' not in session:
        return jsonify({'error': 'Nicht angemeldet'}), 401
    
    if request.method == 'PUT':
        data = request.get_json()
        result = urlaub_service.update(entry_id, data)
        return jsonify(result)
    
    elif request.method == 'DELETE':
        result = urlaub_service.delete(entry_id)
        return jsonify(result)

@app.route('/api/login', methods=['POST'])
def api_login():
    data = request.get_json()
    email = data.get('email')
    password = data.get('password')
    
    if not email or not password:
        return jsonify({'error': 'E-Mail und Passwort erforderlich'}), 400
    
    if email in TEST_USERS and TEST_USERS[email]['password'] == password:
        user_data = TEST_USERS[email]
        session['user'] = {
            'email': email,
            'name': user_data['name'],
            'role': user_data['role']
        }
        
        return jsonify({
            'success': True,
            'user': session['user'],
            'redirect': '/buero' if user_data['role'] == 'Admin' else '/'
        })
    
    return jsonify({'error': 'Ungültige Anmeldedaten'}), 401

@app.route('/api/logout', methods=['POST'])
def api_logout():
    session.clear()
    session.modified = True
    return jsonify({'success': True, 'message': 'Erfolgreich abgemeldet'})

@app.route('/api/me', methods=['GET'])
def api_me():
    if 'user' not in session:
        return jsonify({'error': 'Nicht angemeldet'}), 401
    
    return jsonify({
        'user': session['user'],
        'authenticated': True
    })

@app.route('/api/status')
def api_status():
    return jsonify({
        'status': 'online',
        'version': '1.0.0',
        'user': session.get('user', {}),
        'authenticated': 'user' in session
    })

# Legacy Routes (für Kompatibilität)
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        if email in TEST_USERS and TEST_USERS[email]['password'] == password:
            user_data = TEST_USERS[email]
            session['user'] = {
                'email': email,
                'name': user_data['name'],
                'role': user_data['role']
            }
            
            if user_data['role'] == 'Admin':
                return redirect('/buero')
            return redirect('/')
        flash('Ungültige Anmeldedaten')
    
    # Inline HTML statt Template
    return """
    <!DOCTYPE html>
    <html lang="de">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Anmeldung - Zeiterfassung System</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                background-color: #f5f5f5;
                margin: 0;
                padding: 20px;
                display: flex;
                justify-content: center;
                align-items: center;
                min-height: 100vh;
            }
            .login-container {
                background: white;
                padding: 40px;
                border-radius: 10px;
                box-shadow: 0 4px 20px rgba(0,0,0,0.1);
                width: 100%;
                max-width: 400px;
            }
            .header {
                text-align: center;
                margin-bottom: 30px;
            }
            .form-group {
                margin-bottom: 20px;
            }
            label {
                display: block;
                margin-bottom: 5px;
                font-weight: bold;
                color: #333;
            }
            input[type="email"], input[type="password"] {
                width: 100%;
                padding: 12px;
                border: 2px solid #ddd;
                border-radius: 5px;
                font-size: 16px;
                box-sizing: border-box;
            }
            input[type="email"]:focus, input[type="password"]:focus {
                border-color: #0066b3;
                outline: none;
            }
            .login-btn {
                width: 100%;
                background: #0066b3;
                color: white;
                padding: 12px;
                border: none;
                border-radius: 5px;
                font-size: 16px;
                cursor: pointer;
                margin-top: 10px;
            }
            .login-btn:hover {
                background: #0052a3;
            }
            .demo-info {
                background: #e3f2fd;
                padding: 15px;
                border-radius: 5px;
                margin-top: 20px;
                font-size: 14px;
            }
        </style>
    </head>
    <body>
        <div class="login-container">
            <div class="header">
                <h1>🚀 Zeiterfassung System</h1>
                <h2>Lackner Aufzüge</h2>
            </div>
            
            <form method="POST" action="/login">
                <div class="form-group">
                    <label for="email">E-Mail:</label>
                    <input type="email" id="email" name="email" required>
                </div>
                
                <div class="form-group">
                    <label for="password">Passwort:</label>
                    <input type="password" id="password" name="password" required>
                </div>
                
                <button type="submit" class="login-btn">🔐 Anmelden</button>
            </form>
            
            <div class="demo-info">
                <h4>📋 Test-Anmeldedaten:</h4>
                <p><strong>Monteur:</strong><br>
                E-Mail: monteur@test.com<br>
                Passwort: test123</p>
                
                <p><strong>Administrator:</strong><br>
                E-Mail: admin@test.com<br>
                Passwort: test123</p>
            </div>
        </div>
    </body>
    </html>
    """

@app.route('/logout')
def logout():
    session.clear()
    session.modified = True
    return jsonify({'success': True, 'message': 'Erfolgreich abgemeldet'})

@app.route('/')
def index():
    if 'user' not in session:
        return redirect('/login')
    if session['user'].get('role') == 'Admin':
        return redirect('/buero')
    
    # Monteur Dashboard - Vollständiges Dashboard mit Lackner Design
    user = session['user']
    return f"""
    <!DOCTYPE html>
    <html lang="de">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Monteur Dashboard - Lackner Aufzüge</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
        <style>
            :root {{
                --lackner-blue: #3b82f6;
                --lackner-light-blue: #60a5fa;
                --lackner-dark-blue: #2563eb;
                --lackner-gray: #6b7280;
                --lackner-light-gray: #f3f4f6;
                --lackner-white: #ffffff;
                --lackner-border: #e5e7eb;
            }}
            
            .lackner-header {{
                background: linear-gradient(135deg, var(--lackner-blue) 0%, var(--lackner-dark-blue) 100%);
            }}
            
            .lackner-button {{
                background: var(--lackner-blue);
                color: white;
                transition: all 0.3s ease;
            }}
            .lackner-button:hover {{
                background: var(--lackner-dark-blue);
                transform: translateY(-1px);
            }}
            
            .lackner-secondary-button {{
                background: var(--lackner-white);
                color: var(--lackner-blue);
                border: 2px solid var(--lackner-blue);
                transition: all 0.3s ease;
            }}
            .lackner-secondary-button:hover {{
                background: var(--lackner-blue);
                color: white;
            }}
            
            .mobile-menu {{
                transform: translateX(-100%);
                transition: transform 0.3s ease;
            }}
            .mobile-menu.open {{
                transform: translateX(0);
            }}
            
            .card-hover {{
                transition: all 0.3s ease;
            }}
            .card-hover:hover {{
                transform: translateY(-2px);
                box-shadow: 0 10px 25px rgba(0,0,0,0.1);
            }}
            
            .timer-display {{
                font-family: 'Courier New', monospace;
                font-weight: bold;
            }}
            
            .notification-badge {{
                animation: pulse 2s infinite;
            }}
            @keyframes pulse {{
                0%, 100% {{ opacity: 1; }}
                50% {{ opacity: 0.5; }}
            }}
        </style>
    </head>
    <body class="bg-gray-50">
        <div class="min-h-screen">
            <!-- Haupt-Header mit Lackner Design -->
            <header class="lackner-header text-white shadow-lg">
                <div class="container mx-auto px-4 py-3">
                    <div class="flex justify-between items-center">
                        <!-- Logo und Titel -->
                        <div class="flex items-center space-x-4">
                            <div class="bg-white rounded-lg p-2 shadow-md">
                                <img src="https://lackner-aufzuege-gmbh.com/wp-content/uploads/2021/09/cropped-2205_lackner_r.png" 
                                     alt="Lackner Aufzüge" class="h-10">
                            </div>
                            <div>
                                <h1 class="text-xl font-bold">Zeiterfassung System</h1>
                                <p class="text-sm opacity-90">Lackner Aufzüge GmbH</p>
                            </div>
                        </div>
                        
                        <!-- Desktop Navigation -->
                        <nav class="hidden lg:flex items-center space-x-6">
                            <!-- Nur User-Menu und Notifications in der obersten Leiste -->
                        </nav>
                        
                        <!-- Rechte Seite: Zeit, Notifications, User -->
                        <div class="flex items-center space-x-4">
                            <!-- Live Zeit -->
                            <div class="text-sm hidden md:block">
                                <div id="current-time" class="font-mono text-white"></div>
                                <div id="current-date" class="text-xs opacity-90"></div>
                            </div>
                            
                            <!-- Notification Center -->
                            <div class="relative">
                                <button id="notification-btn" class="relative p-2 hover:bg-blue-700 rounded-lg transition-colors">
                                    <i class="fas fa-bell text-xl text-white"></i>
                                    <span id="notification-count" class="notification-badge absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center hidden">3</span>
                                </button>
                                
                                <!-- Notification Dropdown -->
                                <div id="notification-dropdown" class="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-xl z-50 hidden">
                                    <div class="p-4 border-b">
                                        <h3 class="font-semibold text-gray-900">Benachrichtigungen</h3>
                                    </div>
                                    <div class="max-h-64 overflow-y-auto">
                                        <div class="p-3 hover:bg-gray-50 border-b">
                                            <div class="flex items-start">
                                                <div class="bg-red-100 p-2 rounded-full mr-3">
                                                    <i class="fas fa-exclamation-triangle text-red-600"></i>
                                                </div>
                                                <div class="flex-1">
                                                    <div class="font-medium text-gray-900">Neuer Notfall-Auftrag</div>
                                                    <div class="text-sm text-gray-600">Hauptbahnhof München - Aufzug klemmt</div>
                                                    <div class="text-xs text-gray-500 mt-1">vor 5 Minuten</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="p-3 hover:bg-gray-50 border-b">
                                            <div class="flex items-start">
                                                <div class="bg-yellow-100 p-2 rounded-full mr-3">
                                                    <i class="fas fa-clock text-yellow-600"></i>
                                                </div>
                                                <div class="flex-1">
                                                    <div class="font-medium text-gray-900">Überstunden-Warnung</div>
                                                    <div class="text-sm text-gray-600">Heute bereits 7,5h gearbeitet</div>
                                                    <div class="text-xs text-gray-500 mt-1">vor 10 Minuten</div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="p-3 hover:bg-gray-50">
                                            <div class="flex items-start">
                                                <div class="bg-blue-100 p-2 rounded-full mr-3">
                                                    <i class="fas fa-cloud-rain text-blue-600"></i>
                                                </div>
                                                <div class="flex-1">
                                                    <div class="font-medium text-gray-900">Wetterwarnung</div>
                                                    <div class="text-sm text-gray-600">Starkregen in München erwartet</div>
                                                    <div class="text-xs text-gray-500 mt-1">vor 15 Minuten</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="p-3 bg-gray-50 rounded-b-lg">
                                        <a href="/notifications" class="text-blue-600 text-sm font-medium hover:underline">
                                            Alle Benachrichtigungen anzeigen →
                                        </a>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- User Menu -->
                            <div class="relative">
                                <button id="user-menu-btn" class="flex items-center space-x-2 hover:bg-blue-700 rounded-lg p-2 transition-colors">
                                    <div class="w-8 h-8 bg-white rounded-full flex items-center justify-center">
                                        <i class="fas fa-user text-blue-600"></i>
                                    </div>
                                    <span class="hidden md:block text-white">{user['name']}</span>
                                    <i class="fas fa-chevron-down text-sm text-white"></i>
                                </button>
                                
                                <!-- User Dropdown -->
                                <div id="user-dropdown" class="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-xl z-50 hidden">
                                    <div class="p-3 border-b">
                                        <div class="font-medium text-gray-900">{user['name']}</div>
                                        <div class="text-sm text-gray-600">{user['email']}</div>
                                    </div>
                                    <div class="py-1">
                                        <a href="/profile" class="block px-3 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                            <i class="fas fa-user-cog mr-2"></i>Profil
                                        </a>
                                        <a href="/settings" class="block px-3 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                            <i class="fas fa-cog mr-2"></i>Einstellungen
                                        </a>
                                        <button id="user-switch-btn" class="block w-full text-left px-3 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                            <i class="fas fa-exchange-alt mr-2"></i>Benutzer wechseln
                                        </button>
                                        <hr class="my-1">
                                        <a href="/logout" class="block px-3 py-2 text-sm text-red-600 hover:bg-gray-100">
                                            <i class="fas fa-sign-out-alt mr-2"></i>Abmelden
                                        </a>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Mobile Menu Button -->
                            <button id="mobile-menu-btn" class="lg:hidden text-white p-2 hover:bg-blue-700 rounded-lg transition-colors">
                                <i class="fas fa-bars text-xl"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </header>
            
            <!-- Mobile Navigation Menu -->
            <div id="mobile-menu" class="mobile-menu fixed inset-y-0 left-0 w-64 bg-white shadow-lg z-50 lg:hidden">
                <div class="p-4 border-b">
                    <div class="flex items-center justify-between">
                        <div class="flex items-center space-x-2">
                            <img src="https://lackner-aufzuege-gmbh.com/wp-content/uploads/2021/09/cropped-2205_lackner_r.png" 
                                 alt="Lackner Aufzüge" class="h-8">
                            <span class="font-bold text-gray-900">Menu</span>
                        </div>
                        <button id="close-mobile-menu" class="text-gray-500 hover:text-gray-700">
                            <i class="fas fa-times text-xl"></i>
                        </button>
                    </div>
                </div>
                <nav class="p-4">
                    <div class="space-y-2">
                        <a href="/" class="block px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-700 rounded-lg transition-colors">
                            <i class="fas fa-home mr-3"></i>Dashboard
                        </a>
                        <a href="/meine-auftraege" class="block px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-700 rounded-lg transition-colors">
                            <i class="fas fa-tasks mr-3"></i>Aufträge
                        </a>
                        <a href="/arbeitszeit" class="block px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-700 rounded-lg transition-colors">
                            <i class="fas fa-clock mr-3"></i>Arbeitszeit
                        </a>
                        <a href="/urlaub" class="block px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-700 rounded-lg transition-colors">
                            <i class="fas fa-umbrella-beach mr-3"></i>Urlaub
                        </a>
                        <a href="/zeiterfassung" class="block px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-700 rounded-lg transition-colors">
                            <i class="fas fa-stopwatch mr-3"></i>Zeiterfassung
                        </a>
                        <hr class="my-4">
                        <a href="/profile" class="block px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-700 rounded-lg transition-colors">
                            <i class="fas fa-user-cog mr-3"></i>Profil
                        </a>
                        <a href="/settings" class="block px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-700 rounded-lg transition-colors">
                            <i class="fas fa-cog mr-3"></i>Einstellungen
                        </a>
                        <a href="/logout" class="block px-4 py-3 text-red-600 hover:bg-red-50 rounded-lg transition-colors">
                            <i class="fas fa-sign-out-alt mr-3"></i>Abmelden
                        </a>
                    </div>
                </nav>
            </div>
            
            <!-- Mobile Menu Overlay -->
            <div id="mobile-overlay" class="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden hidden"></div>
            
                                    <!-- Untermenüband für Hauptnavigation -->
                        <div class="bg-white shadow-sm border-b">
                            <div class="container mx-auto px-4 py-3">
                                <nav class="flex items-center justify-center space-x-8">
                                    <a href="/" class="flex items-center space-x-2 px-4 py-2 rounded-lg bg-blue-50 text-blue-700 border border-blue-200">
                                        <i class="fas fa-home text-blue-600 text-lg"></i>
                                        <span class="font-medium">Dashboard</span>
                                    </a>
                                    <a href="/meine-auftraege" class="flex items-center space-x-2 px-4 py-2 rounded-lg hover:bg-blue-50 transition-colors">
                                        <i class="fas fa-tasks text-blue-600 text-lg"></i>
                                        <span class="font-medium text-gray-700">Aufträge</span>
                                    </a>
                                    <a href="/arbeitszeit" class="flex items-center space-x-2 px-4 py-2 rounded-lg hover:bg-blue-50 transition-colors">
                                        <i class="fas fa-clock text-blue-600 text-lg"></i>
                                        <span class="font-medium text-gray-700">Arbeitszeit</span>
                                    </a>
                                    <a href="/urlaub" class="flex items-center space-x-2 px-4 py-2 rounded-lg hover:bg-blue-50 transition-colors">
                                        <i class="fas fa-umbrella-beach text-blue-600 text-lg"></i>
                                        <span class="font-medium text-gray-700">Urlaub</span>
                                    </a>
                                    <a href="/zeiterfassung" class="flex items-center space-x-2 px-4 py-2 rounded-lg hover:bg-blue-50 transition-colors">
                                        <i class="fas fa-stopwatch text-blue-600 text-lg"></i>
                                        <span class="font-medium text-gray-700">Zeiterfassung</span>
                                    </a>
                                </nav>
                            </div>
                        </div>
            
            <main class="container mx-auto p-6">
                <!-- Begrüßung und Status -->
                <div class="mb-8">
                    <h1 class="text-3xl font-bold text-gray-900 mb-2">
                        Guten Tag, {user['name']}!
                    </h1>
                    <p class="text-gray-600">Willkommen im Monteur-Dashboard von Lackner Aufzüge</p>
                </div>

                <!-- Hauptbereich: Aufträge und Timer -->
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
                    <!-- Meine Aufträge -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <div class="flex items-center justify-between mb-6">
                            <div class="flex items-center">
                                <i class="fas fa-tasks text-blue-600 text-xl mr-3"></i>
                                <h2 class="text-xl font-semibold text-gray-900">Meine Aufträge heute</h2>
                            </div>
                            <a href="/meine-auftraege" class="lackner-secondary-button px-4 py-2 rounded-lg text-sm font-medium">
                                Alle Aufträge →
                            </a>
                        </div>
                        
                        <!-- Auftrags-Statistiken -->
                        <div class="grid grid-cols-3 gap-4 mb-6">
                            <div class="text-center p-3 bg-blue-50 rounded-lg">
                                <div class="text-2xl font-bold text-blue-600">2</div>
                                <div class="text-sm text-blue-700">Erledigt</div>
                            </div>
                            <div class="text-center p-3 bg-gray-50 rounded-lg">
                                <div class="text-2xl font-bold text-gray-600">3</div>
                                <div class="text-sm text-gray-700">Offen</div>
                            </div>
                            <div class="text-center p-3 bg-gray-50 rounded-lg">
                                <div class="text-2xl font-bold text-gray-600">1</div>
                                <div class="text-sm text-gray-700">Notfall</div>
                            </div>
                        </div>

                        <!-- Auftragsliste -->
                        <div class="space-y-3">
                            <!-- Notfall-Auftrag -->
                            <div class="auftrag-card p-4 bg-blue-50 border-l-4 border-blue-500 rounded-lg">
                                <div class="flex items-center justify-between">
                                    <div class="flex-1">
                                        <div class="flex items-center gap-2 mb-1">
                                            <span class="text-sm font-medium text-blue-900">08:30 - Notfall</span>
                                            <span class="text-xs bg-blue-200 text-blue-800 px-2 py-1 rounded">Notfall</span>
                                        </div>
                                        <div class="text-sm text-blue-800 font-medium">Hauptbahnhof München</div>
                                        <div class="text-xs text-blue-700 mt-1">Aufzug klemmt, Notruf ausgelöst</div>
                                    </div>
                                    <div class="flex space-x-2">
                                        <button class="lackner-button px-3 py-1 rounded text-xs">
                                            <i class="fas fa-map-marker-alt mr-1"></i>Navigation
                                        </button>
                                        <button class="bg-gray-600 text-white px-3 py-1 rounded text-xs hover:bg-gray-700">
                                            <i class="fas fa-check mr-1"></i>Erledigt
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <!-- Normaler Auftrag -->
                            <div class="auftrag-card p-4 bg-gray-50 border-l-4 border-gray-400 rounded-lg">
                                <div class="flex items-center justify-between">
                                    <div class="flex-1">
                                        <div class="flex items-center gap-2 mb-1">
                                            <span class="text-sm font-medium text-gray-900">09:15 - Wartung</span>
                                            <span class="text-xs bg-gray-200 text-gray-800 px-2 py-1 rounded">Offen</span>
                                        </div>
                                        <div class="text-sm text-gray-800 font-medium">Sendlinger Tor, München</div>
                                        <div class="text-xs text-gray-700 mt-1">Regelmäßige Wartung, Ölwechsel</div>
                                    </div>
                                    <div class="flex space-x-2">
                                        <button class="lackner-button px-3 py-1 rounded text-xs">
                                            <i class="fas fa-map-marker-alt mr-1"></i>Navigation
                                        </button>
                                        <button class="bg-gray-600 text-white px-3 py-1 rounded text-xs hover:bg-gray-700">
                                            <i class="fas fa-check mr-1"></i>Erledigt
                                        </button>
                                    </div>
                                </div>
                            </div>

                            <!-- Weitere Aufträge -->
                            <div class="auftrag-card p-4 bg-gray-50 border-l-4 border-gray-400 rounded-lg">
                                <div class="flex items-center justify-between">
                                    <div class="flex-1">
                                        <div class="flex items-center gap-2 mb-1">
                                            <span class="text-sm font-medium text-gray-900">10:30 - Reparatur</span>
                                            <span class="text-xs bg-gray-200 text-gray-800 px-2 py-1 rounded">Offen</span>
                                        </div>
                                        <div class="text-sm text-gray-800 font-medium">Karlsplatz, München</div>
                                        <div class="text-xs text-gray-700 mt-1">Türschließer defekt</div>
                                    </div>
                                    <div class="flex space-x-2">
                                        <button class="lackner-button px-3 py-1 rounded text-xs">
                                            <i class="fas fa-map-marker-alt mr-1"></i>Navigation
                                        </button>
                                        <button class="bg-gray-600 text-white px-3 py-1 rounded text-xs hover:bg-gray-700">
                                            <i class="fas fa-check mr-1"></i>Erledigt
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Arbeitszeit Timer -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <div class="flex items-center justify-between mb-6">
                            <div class="flex items-center">
                                <i class="fas fa-clock text-blue-600 text-xl mr-3"></i>
                                <h2 class="text-xl font-semibold text-gray-900">Arbeitszeit Timer</h2>
                            </div>
                            <a href="/arbeitszeit" class="lackner-secondary-button px-4 py-2 rounded-lg text-sm font-medium">
                                Alle Arbeitszeiten →
                            </a>
                        </div>
                        
                        <!-- Timer Display -->
                        <div class="text-center mb-6">
                            <div id="timer-display" class="text-4xl font-bold text-blue-900 timer-display mb-4">07:32:15</div>
                            <div class="flex justify-center space-x-4">
                                <button id="start-btn" class="lackner-button font-semibold px-6 py-3 rounded-lg">
                                    <i class="fas fa-play mr-2"></i>Start
                                </button>
                                <button id="pause-btn" class="bg-gray-600 hover:bg-gray-700 text-white font-semibold px-6 py-3 rounded-lg">
                                    <i class="fas fa-pause mr-2"></i>Pause
                                </button>
                                <button id="stop-btn" class="bg-gray-600 hover:bg-gray-700 text-white font-semibold px-6 py-3 rounded-lg">
                                    <i class="fas fa-stop mr-2"></i>Stop
                                </button>
                            </div>
                        </div>

                        <!-- Timer Statistiken -->
                        <div class="grid grid-cols-4 gap-3 mb-4">
                            <div class="text-center p-2 bg-blue-50 rounded">
                                <div class="text-sm font-bold text-blue-900">07:32</div>
                                <div class="text-xs text-blue-700">Arbeitszeit</div>
                            </div>
                            <div class="text-center p-2 bg-gray-50 rounded">
                                <div class="text-sm font-bold text-gray-700">00:45</div>
                                <div class="text-xs text-gray-600">Pausenzeit</div>
                            </div>
                            <div class="text-center p-2 bg-gray-50 rounded">
                                <div class="text-sm font-bold text-gray-700">16:45</div>
                                <div class="text-xs text-gray-600">Geplantes Ende</div>
                            </div>
                            <div class="text-center p-2 bg-gray-50 rounded">
                                <div class="text-sm font-bold text-gray-700">Aktiv</div>
                                <div class="text-xs text-gray-600">Status</div>
                            </div>
                        </div>

                        <!-- Notdienstwoche Toggle -->
                        <div class="flex items-center justify-center gap-2 mb-4">
                            <input type="checkbox" id="notdienst-toggle" class="h-4 w-4 text-blue-600 border-gray-300 rounded">
                            <label for="notdienst-toggle" class="text-sm text-gray-700">
                                Notdienstwoche
                            </label>
                        </div>

                        <!-- Warnungen -->
                        <div id="timer-warnings" class="hidden">
                            <div class="bg-yellow-100 border border-yellow-400 text-yellow-800 px-3 py-2 rounded mb-3 flex items-center text-sm">
                                <i class="fas fa-exclamation-triangle mr-2"></i>
                                <span>Warnung: In 30 Min. max. Arbeitszeit erreicht!</span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Zweiter Bereich: Wetter, Wetterwarnungen, Urlaub -->
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                    <!-- Wetter Widget -->
                    <div class="weather-card text-white rounded-lg shadow-md p-6">
                        <div class="flex items-center justify-between mb-4">
                            <div class="flex items-center">
                                <i class="fas fa-cloud-sun text-2xl mr-3"></i>
                                <h3 class="text-lg font-semibold">Wetter</h3>
                            </div>
                            <a href="#" class="text-white opacity-80 hover:opacity-100 text-sm">
                                Detailliert →
                            </a>
                        </div>
                        
                        <div class="text-center mb-4">
                            <div class="text-3xl font-bold mb-2">18°C</div>
                            <div class="text-sm opacity-90">Leicht bewölkt</div>
                            <div class="text-xs opacity-75 mt-1">Gefühlt: 16°C</div>
                        </div>

                        <div class="border-t border-white border-opacity-20 pt-4">
                            <div class="text-sm font-medium mb-3">3-Tage-Forecast</div>
                            <div class="space-y-2">
                                <div class="flex items-center justify-between">
                                    <div class="flex items-center">
                                        <i class="fas fa-sun mr-2"></i>
                                        <span class="text-sm">Heute</span>
                                    </div>
                                    <span class="text-sm font-bold">20°C</span>
                                </div>
                                <div class="flex items-center justify-between">
                                    <div class="flex items-center">
                                        <i class="fas fa-cloud mr-2"></i>
                                        <span class="text-sm">Morgen</span>
                                    </div>
                                    <span class="text-sm font-bold">17°C</span>
                                </div>
                                <div class="flex items-center justify-between">
                                    <div class="flex items-center">
                                        <i class="fas fa-cloud-rain mr-2"></i>
                                        <span class="text-sm">Übermorgen</span>
                                    </div>
                                    <span class="text-sm font-bold">15°C</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Wetterwarnungen -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <div class="flex items-center justify-between mb-4">
                            <div class="flex items-center">
                                <i class="fas fa-exclamation-triangle text-yellow-600 text-xl mr-3"></i>
                                <h3 class="text-lg font-semibold text-gray-900">Wetterwarnungen</h3>
                            </div>
                            <a href="#" class="lackner-secondary-button px-3 py-1 rounded text-sm">
                                DWD prüfen →
                            </a>
                        </div>
                        
                        <div class="space-y-3">
                            <div class="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                                <div class="flex items-center justify-between mb-1">
                                    <span class="text-sm font-medium text-yellow-800">Starkregen</span>
                                    <span class="text-xs bg-yellow-200 text-yellow-800 px-2 py-1 rounded">Aktiv</span>
                                </div>
                                <div class="text-xs text-yellow-700">München - 14:00 bis 18:00 Uhr</div>
                            </div>
                            
                            <div class="p-3 bg-gray-50 border border-gray-200 rounded-lg">
                                <div class="flex items-center justify-between mb-1">
                                    <span class="text-sm font-medium text-gray-700">Status</span>
                                    <span class="text-xs bg-green-200 text-green-800 px-2 py-1 rounded">Keine Warnungen</span>
                                </div>
                                <div class="text-xs text-gray-600">Letzte Prüfung: vor 5 Min.</div>
                            </div>
                        </div>
                    </div>

                    <!-- Urlaub -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <div class="flex items-center justify-between mb-4">
                            <div class="flex items-center">
                                <i class="fas fa-umbrella-beach text-purple-600 text-xl mr-3"></i>
                                <h3 class="text-lg font-semibold text-gray-900">Urlaub</h3>
                            </div>
                            <a href="/urlaub" class="lackner-secondary-button px-3 py-1 rounded text-sm">
                                Übersicht →
                            </a>
                        </div>
                        
                        <div class="grid grid-cols-3 gap-3 mb-4">
                            <div class="text-center">
                                <div class="text-2xl font-bold text-purple-600">25</div>
                                <div class="text-xs text-gray-600">Übrig</div>
                            </div>
                            <div class="text-center">
                                <div class="text-2xl font-bold text-green-600">5</div>
                                <div class="text-xs text-gray-600">Verbraucht</div>
                            </div>
                            <div class="text-center">
                                <div class="text-2xl font-bold text-blue-600">3</div>
                                <div class="text-xs text-gray-600">Geplant</div>
                            </div>
                        </div>

                        <div class="space-y-2">
                            <div class="p-2 bg-blue-50 rounded text-sm">
                                <div class="font-medium text-blue-900">Nächster Urlaub</div>
                                <div class="text-blue-700">15.08. - 22.08.2024</div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Dritter Bereich: Tageszusammenfassung und Route-Planer -->
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
                    <!-- Tageszusammenfassung -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <div class="flex items-center mb-4">
                            <i class="fas fa-chart-bar text-green-600 text-xl mr-3"></i>
                            <h3 class="text-lg font-semibold text-gray-900">Tageszusammenfassung</h3>
                        </div>
                        
                        <div class="grid grid-cols-2 gap-4">
                            <div class="p-4 bg-red-50 rounded-lg border-2 border-red-200 cursor-pointer hover:shadow-md transition-all">
                                <div class="text-center">
                                    <div class="text-3xl font-bold text-red-600 mb-2">3</div>
                                    <div class="text-sm font-semibold text-gray-700 mb-1">Benachrichtigungen</div>
                                    <div class="text-xs text-gray-600 mb-2">2 neue, 1 Überstunden</div>
                                    <div class="text-xs text-blue-600 font-medium">→ Zur Genehmigung</div>
                                </div>
                            </div>
                            
                            <div class="p-4 bg-orange-50 rounded-lg border-2 border-orange-200 cursor-pointer hover:shadow-md transition-all">
                                <div class="text-center">
                                    <div class="text-3xl font-bold text-orange-600 mb-2">1</div>
                                    <div class="text-sm font-semibold text-gray-700 mb-1">Notfälle</div>
                                    <div class="text-xs text-gray-600 mb-2">Hauptbahnhof München</div>
                                    <div class="text-xs text-blue-600 font-medium">→ Zu den Aufträgen</div>
                                </div>
                            </div>
                            
                            <div class="p-4 bg-blue-50 rounded-lg border-2 border-blue-200 cursor-pointer hover:shadow-md transition-all">
                                <div class="text-center">
                                    <div class="text-3xl font-bold text-blue-600 mb-2">2</div>
                                    <div class="text-sm font-semibold text-gray-700 mb-1">Offene Aufgaben</div>
                                    <div class="text-xs text-gray-600 mb-2">Zeiteinträge warten</div>
                                    <div class="text-xs text-blue-600 font-medium">→ Zur Zeiterfassung</div>
                                </div>
                            </div>
                            
                            <div class="p-4 bg-purple-50 rounded-lg border-2 border-purple-200 cursor-pointer hover:shadow-md transition-all">
                                <div class="text-center">
                                    <div class="text-3xl font-bold text-purple-600 mb-2">25</div>
                                    <div class="text-sm font-semibold text-gray-700 mb-1">Urlaubstage</div>
                                    <div class="text-xs text-gray-600 mb-2">25 übrig, 3 geplant</div>
                                    <div class="text-xs text-blue-600 font-medium">→ Zum Urlaub</div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Route-Planer -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <div class="flex items-center justify-between mb-4">
                            <div class="flex items-center">
                                <i class="fas fa-route text-blue-600 text-xl mr-3"></i>
                                <h3 class="text-lg font-semibold text-gray-900">Route-Planer</h3>
                            </div>
                            <a href="#" class="lackner-secondary-button px-3 py-1 rounded text-sm">
                                Optimieren →
                            </a>
                        </div>
                        
                        <div class="space-y-3">
                            <div class="p-3 bg-blue-50 rounded-lg">
                                <div class="flex items-center justify-between mb-2">
                                    <span class="text-sm font-medium text-blue-900">Optimierte Route</span>
                                    <span class="text-xs bg-blue-200 text-blue-800 px-2 py-1 rounded">Aktiv</span>
                                </div>
                                <div class="text-xs text-blue-700 mb-2">3 Aufträge, 45 Min. Fahrzeit</div>
                                <div class="space-y-1">
                                    <div class="flex items-center text-xs">
                                        <span class="w-4 h-4 bg-blue-500 rounded-full mr-2"></span>
                                        <span>08:30 - Hauptbahnhof (Notfall)</span>
                                    </div>
                                    <div class="flex items-center text-xs">
                                        <span class="w-4 h-4 bg-blue-500 rounded-full mr-2"></span>
                                        <span>09:15 - Sendlinger Tor (Wartung)</span>
                                    </div>
                                    <div class="flex items-center text-xs">
                                        <span class="w-4 h-4 bg-blue-500 rounded-full mr-2"></span>
                                        <span>10:30 - Karlsplatz (Reparatur)</span>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="p-3 bg-gray-50 rounded-lg">
                                <div class="flex items-center justify-between">
                                    <span class="text-sm font-medium text-gray-700">Nächste Route</span>
                                    <span class="text-xs bg-gray-200 text-gray-800 px-2 py-1 rounded">Geplant</span>
                                </div>
                                <div class="text-xs text-gray-600 mt-1">2 weitere Aufträge nach 12:00 Uhr</div>
                            </div>
                        </div>
                    </div>
                </div>


            </main>
        </div>

        <!-- JavaScript für Interaktivität -->
        <script>
            // Live Zeit aktualisieren
            function updateTime() {{
                const now = new Date();
                document.getElementById('current-time').textContent = now.toLocaleTimeString('de-DE');
                document.getElementById('current-date').textContent = now.toLocaleDateString('de-DE', {{
                    weekday: 'long',
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                }});
            }}
            updateTime();
            setInterval(updateTime, 1000);

            // Mobile Menu Toggle
            const mobileMenuBtn = document.getElementById('mobile-menu-btn');
            const mobileMenu = document.getElementById('mobile-menu');
            const mobileOverlay = document.getElementById('mobile-overlay');
            const closeMobileMenu = document.getElementById('close-mobile-menu');

            function openMobileMenu() {{
                mobileMenu.classList.add('open');
                mobileOverlay.classList.remove('hidden');
                document.body.style.overflow = 'hidden';
            }}

            function closeMobileMenuFunc() {{
                mobileMenu.classList.remove('open');
                mobileOverlay.classList.add('hidden');
                document.body.style.overflow = '';
            }}

            mobileMenuBtn.addEventListener('click', openMobileMenu);
            closeMobileMenu.addEventListener('click', closeMobileMenuFunc);
            mobileOverlay.addEventListener('click', closeMobileMenuFunc);

            // Notification Center
            document.getElementById('notification-btn').addEventListener('click', function() {{
                const dropdown = document.getElementById('notification-dropdown');
                dropdown.classList.toggle('hidden');
            }});

            // User Menu
            document.getElementById('user-menu-btn').addEventListener('click', function() {{
                const dropdown = document.getElementById('user-dropdown');
                dropdown.classList.toggle('hidden');
            }});

            // Timer Funktionalität
            let timerRunning = false;
            let startTime = null;
            let pausedTime = 0;
            let timerInterval = null;

            function updateTimer() {{
                if (timerRunning && startTime) {{
                    const now = new Date();
                    const diff = now - startTime + pausedTime;
                    const hours = Math.floor(diff / 3600000);
                    const minutes = Math.floor((diff % 3600000) / 60000);
                    const seconds = Math.floor((diff % 60000) / 1000);
                    
                    document.getElementById('timer-display').textContent = 
                        `${{hours.toString().padStart(2, '0')}}:${{minutes.toString().padStart(2, '0')}}:${{seconds.toString().padStart(2, '0')}}`;
                }}
            }}

            function resetButtons() {{
                document.getElementById('start-btn').disabled = false;
                document.getElementById('pause-btn').disabled = true;
                document.getElementById('stop-btn').disabled = true;
                document.getElementById('pause-btn').textContent = 'Pause';
            }}

            document.getElementById('start-btn').addEventListener('click', function() {{
                if (!timerRunning) {{
                    timerRunning = true;
                    startTime = new Date();
                    timerInterval = setInterval(updateTimer, 1000);
                    this.disabled = true;
                    document.getElementById('pause-btn').disabled = false;
                    document.getElementById('stop-btn').disabled = false;
                }}
            }});

            document.getElementById('pause-btn').addEventListener('click', function() {{
                if (timerRunning) {{
                    // Pause
                    clearInterval(timerInterval);
                    timerRunning = false;
                    pausedTime += new Date() - startTime;
                    this.textContent = 'Fortsetzen';
                    document.getElementById('start-btn').disabled = false;
                }} else {{
                    // Fortsetzen
                    timerRunning = true;
                    startTime = new Date();
                    timerInterval = setInterval(updateTimer, 1000);
                    this.textContent = 'Pause';
                    document.getElementById('start-btn').disabled = true;
                }}
            }});

            document.getElementById('stop-btn').addEventListener('click', function() {{
                clearInterval(timerInterval);
                timerRunning = false;
                startTime = null;
                pausedTime = 0;
                document.getElementById('timer-display').textContent = '00:00:00';
                resetButtons();
            }});

            // User Switcher
            document.getElementById('user-switch-btn').addEventListener('click', function() {{
                // Hier könnte ein Modal für User-Switching geöffnet werden
                alert('User-Switcher Feature wird implementiert...');
            }});

            // Click outside to close dropdowns
            document.addEventListener('click', function(event) {{
                if (!event.target.closest('.relative')) {{
                    document.getElementById('notification-dropdown').classList.add('hidden');
                    document.getElementById('user-dropdown').classList.add('hidden');
                }}
            }});
        </script>
    </body>
    </html>
    """

@app.route('/arbeitszeit')
def arbeitszeit():
    if 'user' not in session:
        return redirect('/login')
    
    # Arbeitszeit-Verwaltungsseite mit Lackner Design
    user = session['user']
    return f"""
    <!DOCTYPE html>
    <html lang="de">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Arbeitszeit-Verwaltung - Lackner Aufzüge</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
        <style>
            :root {{
                --lackner-blue: #3b82f6;
                --lackner-light-blue: #60a5fa;
                --lackner-dark-blue: #2563eb;
                --lackner-gray: #6b7280;
                --lackner-light-gray: #f3f4f6;
                --lackner-white: #ffffff;
                --lackner-border: #e5e7eb;
            }}
            
            .lackner-header {{
                background: linear-gradient(135deg, var(--lackner-blue) 0%, var(--lackner-dark-blue) 100%);
            }}
            
            .lackner-button {{
                background: var(--lackner-blue);
                color: white;
                transition: all 0.3s ease;
            }}
            .lackner-button:hover {{
                background: var(--lackner-dark-blue);
                transform: translateY(-1px);
            }}
            
            .lackner-secondary-button {{
                background: var(--lackner-white);
                color: var(--lackner-blue);
                border: 2px solid var(--lackner-blue);
                transition: all 0.3s ease;
            }}
            .lackner-secondary-button:hover {{
                background: var(--lackner-blue);
                color: white;
            }}
            
            .mobile-menu {{
                transform: translateX(-100%);
                transition: transform 0.3s ease;
            }}
            .mobile-menu.open {{
                transform: translateX(0);
            }}
            
            .arbeitszeit-card {{
                transition: all 0.3s ease;
            }}
            .arbeitszeit-card:hover {{
                transform: translateY(-2px);
                box-shadow: 0 10px 25px rgba(0,0,0,0.1);
            }}
            
            .timer-display {{
                font-family: 'Courier New', monospace;
                font-weight: bold;
            }}
            
            .notification-badge {{
                animation: pulse 2s infinite;
            }}
            @keyframes pulse {{
                0%, 100% {{ opacity: 1; }}
                50% {{ opacity: 0.5; }}
            }}
        </style>
    </head>
    <body class="bg-gray-50">
        <div class="min-h-screen">
            <!-- Haupt-Header mit Lackner Design -->
            <header class="lackner-header text-white shadow-lg">
                <div class="container mx-auto px-4 py-3">
                    <div class="flex justify-between items-center">
                        <!-- Logo und Titel -->
                        <div class="flex items-center space-x-4">
                            <div class="bg-white rounded-lg p-2 shadow-md">
                                <img src="https://lackner-aufzuege-gmbh.com/wp-content/uploads/2021/09/cropped-2205_lackner_r.png" 
                                     alt="Lackner Aufzüge" class="h-10">
                            </div>
                            <div>
                                <h1 class="text-xl font-bold">Arbeitszeit-Verwaltung</h1>
                                <p class="text-sm opacity-90">Lackner Aufzüge GmbH</p>
                            </div>
                        </div>
                        
                        <!-- Desktop Navigation -->
                        <nav class="hidden lg:flex items-center space-x-6">
                            <!-- Nur User-Menu und Notifications in der obersten Leiste -->
                        </nav>
                        
                        <!-- Rechte Seite: User -->
                        <div class="flex items-center space-x-4">
                            <!-- User Menu -->
                            <div class="relative">
                                <button id="user-menu-btn" class="flex items-center space-x-2 hover:bg-blue-700 rounded-lg p-2 transition-colors">
                                    <div class="w-8 h-8 bg-white rounded-full flex items-center justify-center">
                                        <i class="fas fa-user text-blue-600"></i>
                                    </div>
                                    <span class="hidden md:block text-white">{user['name']}</span>
                                    <i class="fas fa-chevron-down text-sm text-white"></i>
                                </button>
                                
                                <!-- User Dropdown -->
                                <div id="user-dropdown" class="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-xl z-50 hidden">
                                    <div class="p-3 border-b">
                                        <div class="font-medium text-gray-900">{user['name']}</div>
                                        <div class="text-sm text-gray-600">{user['email']}</div>
                                    </div>
                                    <div class="py-1">
                                        <a href="/profile" class="block px-3 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                            <i class="fas fa-user-cog mr-2"></i>Profil
                                        </a>
                                        <a href="/settings" class="block px-3 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                            <i class="fas fa-cog mr-2"></i>Einstellungen
                                        </a>
                                        <hr class="my-1">
                                        <a href="/logout" class="block px-3 py-2 text-sm text-red-600 hover:bg-gray-100">
                                            <i class="fas fa-sign-out-alt mr-2"></i>Abmelden
                                        </a>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Mobile Menu Button -->
                            <button id="mobile-menu-btn" class="lg:hidden text-white p-2 hover:bg-blue-700 rounded-lg transition-colors">
                                <i class="fas fa-bars text-xl"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </header>
            
            <!-- Mobile Navigation Menu -->
            <div id="mobile-menu" class="mobile-menu fixed inset-y-0 left-0 w-64 bg-white shadow-lg z-50 lg:hidden">
                <div class="p-4 border-b">
                    <div class="flex items-center justify-between">
                        <div class="flex items-center space-x-2">
                            <img src="https://lackner-aufzuege-gmbh.com/wp-content/uploads/2021/09/cropped-2205_lackner_r.png" 
                                 alt="Lackner Aufzüge" class="h-8">
                            <span class="font-bold text-gray-900">Menu</span>
                        </div>
                        <button id="close-mobile-menu" class="text-gray-500 hover:text-gray-700">
                            <i class="fas fa-times text-xl"></i>
                        </button>
                    </div>
                </div>
                <nav class="p-4">
                    <div class="space-y-2">
                        <a href="/" class="block px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-700 rounded-lg transition-colors">
                            <i class="fas fa-home mr-3"></i>Dashboard
                        </a>
                        <a href="/meine-auftraege" class="block px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-700 rounded-lg transition-colors">
                            <i class="fas fa-tasks mr-3"></i>Aufträge
                        </a>
                        <a href="/arbeitszeit" class="block px-4 py-3 text-blue-700 bg-blue-50 rounded-lg">
                            <i class="fas fa-clock mr-3"></i>Arbeitszeit
                        </a>
                        <a href="/urlaub" class="block px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-700 rounded-lg transition-colors">
                            <i class="fas fa-umbrella-beach mr-3"></i>Urlaub
                        </a>
                        <a href="/zeiterfassung" class="block px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-700 rounded-lg transition-colors">
                            <i class="fas fa-stopwatch mr-3"></i>Zeiterfassung
                        </a>
                        <hr class="my-4">
                        <a href="/profile" class="block px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-700 rounded-lg transition-colors">
                            <i class="fas fa-user-cog mr-3"></i>Profil
                        </a>
                        <a href="/settings" class="block px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-700 rounded-lg transition-colors">
                            <i class="fas fa-cog mr-3"></i>Einstellungen
                        </a>
                        <a href="/logout" class="block px-4 py-3 text-red-600 hover:bg-red-50 rounded-lg transition-colors">
                            <i class="fas fa-sign-out-alt mr-3"></i>Abmelden
                        </a>
                    </div>
                </nav>
            </div>
            
            <!-- Mobile Menu Overlay -->
            <div id="mobile-overlay" class="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden hidden"></div>
            
                                    <!-- Untermenüband für Hauptnavigation -->
                        <div class="bg-white shadow-sm border-b">
                            <div class="container mx-auto px-4 py-3">
                                <nav class="flex items-center justify-center space-x-8">
                                    <a href="/" class="flex items-center space-x-2 px-4 py-2 rounded-lg hover:bg-blue-50 transition-colors">
                                        <i class="fas fa-home text-blue-600 text-lg"></i>
                                        <span class="font-medium text-gray-700">Dashboard</span>
                                    </a>
                                    <a href="/meine-auftraege" class="flex items-center space-x-2 px-4 py-2 rounded-lg hover:bg-blue-50 transition-colors">
                                        <i class="fas fa-tasks text-blue-600 text-lg"></i>
                                        <span class="font-medium text-gray-700">Aufträge</span>
                                    </a>
                                    <a href="/arbeitszeit" class="flex items-center space-x-2 px-4 py-2 rounded-lg bg-blue-50 text-blue-700 border border-blue-200">
                                        <i class="fas fa-clock text-blue-600 text-lg"></i>
                                        <span class="font-medium">Arbeitszeit</span>
                                    </a>
                                    <a href="/urlaub" class="flex items-center space-x-2 px-4 py-2 rounded-lg hover:bg-blue-50 transition-colors">
                                        <i class="fas fa-umbrella-beach text-blue-600 text-lg"></i>
                                        <span class="font-medium text-gray-700">Urlaub</span>
                                    </a>
                                    <a href="/zeiterfassung" class="flex items-center space-x-2 px-4 py-2 rounded-lg hover:bg-blue-50 transition-colors">
                                        <i class="fas fa-stopwatch text-blue-600 text-lg"></i>
                                        <span class="font-medium text-gray-700">Zeiterfassung</span>
                                    </a>
                                </nav>
                            </div>
                        </div>
            
            <main class="container mx-auto p-6">
                <!-- Begrüßung und Status -->
                <div class="mb-8">
                    <h1 class="text-3xl font-bold text-gray-900 mb-2">
                        Arbeitszeit-Verwaltung
                    </h1>
                    <p class="text-gray-600">Verwalten Sie Ihre Arbeitszeiten und Zeiterfassung</p>
                </div>

                <!-- Arbeitszeit-Statistiken -->
                <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                    <div class="bg-white rounded-lg shadow-md p-6 text-center">
                        <div class="text-3xl font-bold text-blue-600 mb-2">07:32</div>
                        <div class="text-sm text-gray-600">Heute gearbeitet</div>
                        <div class="text-xs text-gray-500 mt-1">von 8:00 Stunden</div>
                    </div>
                    <div class="bg-white rounded-lg shadow-md p-6 text-center">
                        <div class="text-3xl font-bold text-blue-600 mb-2">32:15</div>
                        <div class="text-sm text-gray-600">Diese Woche</div>
                        <div class="text-xs text-gray-500 mt-1">von 40:00 Stunden</div>
                    </div>
                    <div class="bg-white rounded-lg shadow-md p-6 text-center">
                        <div class="text-3xl font-bold text-gray-700 mb-2">2:45</div>
                        <div class="text-sm text-gray-600">Überstunden</div>
                        <div class="text-xs text-gray-500 mt-1">diese Woche</div>
                    </div>
                    <div class="bg-white rounded-lg shadow-md p-6 text-center">
                        <div class="text-3xl font-bold text-blue-600 mb-2">Aktiv</div>
                        <div class="text-sm text-gray-600">Timer läuft</div>
                        <div class="text-xs text-gray-500 mt-1">seit 07:15 Uhr</div>
                    </div>
                </div>

                <!-- Hauptbereich: Timer und Einträge -->
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
                    <!-- Arbeitszeit Timer -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <div class="flex items-center mb-6">
                            <i class="fas fa-stopwatch text-blue-600 text-xl mr-3"></i>
                            <h2 class="text-xl font-semibold text-gray-900">Arbeitszeit Timer</h2>
                        </div>
                        
                        <!-- Timer Display -->
                        <div class="text-center mb-6">
                            <div id="timer-display" class="text-4xl font-bold text-blue-900 timer-display mb-4">07:32:15</div>
                            <div class="flex justify-center space-x-4">
                                <button id="start-btn" class="lackner-button font-semibold px-6 py-3 rounded-lg">
                                    <i class="fas fa-play mr-2"></i>Start
                                </button>
                                <button id="pause-btn" class="bg-yellow-600 hover:bg-yellow-700 text-white font-semibold px-6 py-3 rounded-lg">
                                    <i class="fas fa-pause mr-2"></i>Pause
                                </button>
                                <button id="stop-btn" class="bg-red-600 hover:bg-red-700 text-white font-semibold px-6 py-3 rounded-lg">
                                    <i class="fas fa-stop mr-2"></i>Stop
                                </button>
                            </div>
                        </div>

                        <!-- Timer Statistiken -->
                        <div class="grid grid-cols-4 gap-3 mb-4">
                            <div class="text-center p-2 bg-blue-50 rounded">
                                <div class="text-sm font-bold text-blue-900">07:32</div>
                                <div class="text-xs text-blue-700">Arbeitszeit</div>
                            </div>
                            <div class="text-center p-2 bg-orange-50 rounded">
                                <div class="text-sm font-bold text-orange-600">00:45</div>
                                <div class="text-xs text-orange-700">Pausenzeit</div>
                            </div>
                            <div class="text-center p-2 bg-green-50 rounded">
                                <div class="text-sm font-bold text-green-700">16:45</div>
                                <div class="text-xs text-green-700">Geplantes Ende</div>
                            </div>
                            <div class="text-center p-2 bg-gray-50 rounded">
                                <div class="text-sm font-bold text-gray-700">Aktiv</div>
                                <div class="text-xs text-gray-600">Status</div>
                            </div>
                        </div>

                        <!-- Notdienstwoche Toggle -->
                        <div class="flex items-center justify-center gap-2 mb-4">
                            <input type="checkbox" id="notdienst-toggle" class="h-4 w-4 text-blue-600 border-gray-300 rounded">
                            <label for="notdienst-toggle" class="text-sm text-gray-700">
                                Notdienstwoche
                            </label>
                        </div>

                        <!-- Warnungen -->
                        <div id="timer-warnings" class="hidden">
                            <div class="bg-yellow-100 border border-yellow-400 text-yellow-800 px-3 py-2 rounded mb-3 flex items-center text-sm">
                                <i class="fas fa-exclamation-triangle mr-2"></i>
                                <span>Warnung: In 30 Min. max. Arbeitszeit erreicht!</span>
                            </div>
                        </div>
                    </div>

                    <!-- Neuer Arbeitszeit-Eintrag -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <div class="flex items-center mb-6">
                            <i class="fas fa-plus-circle text-green-600 text-xl mr-3"></i>
                            <h2 class="text-xl font-semibold text-gray-900">Neuer Arbeitszeit-Eintrag</h2>
                        </div>
                        
                        <form id="arbeitszeit-form" class="space-y-4">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label for="datum" class="block text-sm font-medium text-gray-700 mb-2">
                                        Datum
                                    </label>
                                    <input type="date" id="datum" name="datum" 
                                           class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                           required>
                                </div>
                                <div>
                                    <label for="activity-type" class="block text-sm font-medium text-gray-700 mb-2">
                                        Tätigkeit
                                    </label>
                                    <select id="activity-type" name="activity_type" 
                                            class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                                        <option value="Wartung">Wartung</option>
                                        <option value="Reparatur">Reparatur</option>
                                        <option value="Notdienst">Notdienst</option>
                                        <option value="Installation">Installation</option>
                                        <option value="Administration">Administration</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label for="start-time" class="block text-sm font-medium text-gray-700 mb-2">
                                        Startzeit
                                    </label>
                                    <input type="time" id="start-time" name="start_time" 
                                           class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                           required>
                                </div>
                                <div>
                                    <label for="end-time" class="block text-sm font-medium text-gray-700 mb-2">
                                        Endzeit
                                    </label>
                                    <input type="time" id="end-time" name="end_time" 
                                           class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                           required>
                                </div>
                            </div>
                            
                            <div>
                                <label for="location" class="block text-sm font-medium text-gray-700 mb-2">
                                    Standort
                                </label>
                                <input type="text" id="location" name="location" 
                                       class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                       placeholder="z.B. Hauptbahnhof München">
                            </div>
                            
                            <div>
                                <label for="notes" class="block text-sm font-medium text-gray-700 mb-2">
                                    Notizen
                                </label>
                                <textarea id="notes" name="notes" rows="3" 
                                          class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                          placeholder="Optionale Notizen zur Tätigkeit..."></textarea>
                            </div>
                            
                            <div class="flex space-x-4">
                                <button type="submit" class="lackner-button px-6 py-3 rounded-lg font-medium">
                                    <i class="fas fa-save mr-2"></i>Eintrag speichern
                                </button>
                                <button type="button" id="reset-form" class="lackner-secondary-button px-6 py-3 rounded-lg font-medium">
                                    <i class="fas fa-undo mr-2"></i>Zurücksetzen
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Arbeitszeit-Einträge Übersicht -->
                <div class="bg-white rounded-lg shadow-md p-6 mb-8">
                    <div class="flex items-center justify-between mb-6">
                        <div class="flex items-center">
                            <i class="fas fa-list-alt text-gray-600 text-xl mr-3"></i>
                            <h2 class="text-xl font-semibold text-gray-900">Meine Arbeitszeit-Einträge</h2>
                        </div>
                        <div class="flex space-x-2">
                            <button id="filter-all" class="lackner-button px-3 py-1 rounded text-xs">
                                Alle
                            </button>
                            <button id="filter-today" class="lackner-secondary-button px-3 py-1 rounded text-xs">
                                Heute
                            </button>
                            <button id="filter-week" class="lackner-secondary-button px-3 py-1 rounded text-xs">
                                Diese Woche
                            </button>
                        </div>
                    </div>
                    
                    <div class="space-y-4">
                        <!-- Heutiger Eintrag -->
                        <div class="arbeitszeit-card p-4 bg-blue-50 rounded-lg border-l-4 border-blue-500">
                            <div class="flex items-center justify-between">
                                <div class="flex-1">
                                    <div class="flex items-center gap-2 mb-1">
                                        <span class="text-sm font-medium text-blue-900">Heute - Wartung</span>
                                        <span class="text-xs bg-blue-200 text-blue-800 px-2 py-1 rounded">Aktiv</span>
                                    </div>
                                    <div class="text-sm text-blue-800">07:15 - 15:47 (läuft)</div>
                                    <div class="text-xs text-blue-700 mt-1">Hauptbahnhof München • 8h 32min</div>
                                </div>
                                <div class="flex space-x-2">
                                    <button class="lackner-button px-3 py-1 rounded text-xs">
                                        <i class="fas fa-edit mr-1"></i>Bearbeiten
                                    </button>
                                    <button class="bg-gray-600 text-white px-3 py-1 rounded text-xs hover:bg-gray-700">
                                        <i class="fas fa-stop mr-1"></i>Beenden
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- Gestern -->
                        <div class="arbeitszeit-card p-4 bg-gray-50 rounded-lg border-l-4 border-gray-400">
                            <div class="flex items-center justify-between">
                                <div class="flex-1">
                                    <div class="flex items-center gap-2 mb-1">
                                        <span class="text-sm font-medium text-gray-900">Gestern - Reparatur</span>
                                        <span class="text-xs bg-gray-200 text-gray-800 px-2 py-1 rounded">Abgeschlossen</span>
                                    </div>
                                    <div class="text-sm text-gray-800">08:00 - 16:30</div>
                                    <div class="text-xs text-gray-700 mt-1">Sendlinger Tor • 8h 30min</div>
                                </div>
                                <div class="flex space-x-2">
                                    <button class="lackner-secondary-button px-3 py-1 rounded text-xs">
                                        <i class="fas fa-eye mr-1"></i>Details
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- Vorgestern -->
                        <div class="arbeitszeit-card p-4 bg-gray-50 rounded-lg border-l-4 border-gray-400">
                            <div class="flex items-center justify-between">
                                <div class="flex-1">
                                    <div class="flex items-center gap-2 mb-1">
                                        <span class="text-sm font-medium text-gray-900">Vorgestern - Notdienst</span>
                                        <span class="text-xs bg-gray-200 text-gray-800 px-2 py-1 rounded">Überstunden</span>
                                    </div>
                                    <div class="text-sm text-gray-800">07:00 - 18:45</div>
                                    <div class="text-xs text-gray-700 mt-1">Karlsplatz • 11h 45min (+3h 45min)</div>
                                </div>
                                <div class="flex space-x-2">
                                    <button class="lackner-secondary-button px-3 py-1 rounded text-xs">
                                        <i class="fas fa-eye mr-1"></i>Details
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Wöchentliche Übersicht -->
                <div class="bg-white rounded-lg shadow-md p-6 mb-8">
                    <div class="flex items-center mb-6">
                        <i class="fas fa-chart-bar text-purple-600 text-xl mr-3"></i>
                        <h2 class="text-xl font-semibold text-gray-900">Wöchentliche Übersicht</h2>
                    </div>
                    
                    <div class="grid grid-cols-1 md:grid-cols-7 gap-4">
                        <div class="text-center p-3 bg-gray-50 rounded-lg">
                            <div class="text-sm font-medium text-gray-700 mb-1">Mo</div>
                            <div class="text-lg font-bold text-blue-600">8:30</div>
                            <div class="text-xs text-gray-500">Normal</div>
                        </div>
                        <div class="text-center p-3 bg-gray-50 rounded-lg">
                            <div class="text-sm font-medium text-gray-700 mb-1">Di</div>
                            <div class="text-lg font-bold text-blue-600">8:15</div>
                            <div class="text-xs text-gray-500">Normal</div>
                        </div>
                        <div class="text-center p-3 bg-orange-50 rounded-lg">
                            <div class="text-sm font-medium text-gray-700 mb-1">Mi</div>
                            <div class="text-lg font-bold text-orange-600">11:45</div>
                            <div class="text-xs text-orange-500">Überstunden</div>
                        </div>
                        <div class="text-center p-3 bg-gray-50 rounded-lg">
                            <div class="text-sm font-medium text-gray-700 mb-1">Do</div>
                            <div class="text-lg font-bold text-blue-600">8:00</div>
                            <div class="text-xs text-gray-500">Normal</div>
                        </div>
                        <div class="text-center p-3 bg-green-50 rounded-lg">
                            <div class="text-sm font-medium text-gray-700 mb-1">Fr</div>
                            <div class="text-lg font-bold text-green-600">7:32</div>
                            <div class="text-xs text-green-500">Aktiv</div>
                        </div>
                        <div class="text-center p-3 bg-gray-50 rounded-lg">
                            <div class="text-sm font-medium text-gray-700 mb-1">Sa</div>
                            <div class="text-lg font-bold text-gray-400">-</div>
                            <div class="text-xs text-gray-500">Frei</div>
                        </div>
                        <div class="text-center p-3 bg-gray-50 rounded-lg">
                            <div class="text-sm font-medium text-gray-700 mb-1">So</div>
                            <div class="text-lg font-bold text-gray-400">-</div>
                            <div class="text-xs text-gray-500">Frei</div>
                        </div>
                    </div>
                    
                    <div class="mt-4 p-4 bg-blue-50 rounded-lg">
                        <div class="text-sm font-medium text-blue-900 mb-2">Wochenübersicht</div>
                        <div class="grid grid-cols-3 gap-4 text-xs">
                            <div class="flex justify-between">
                                <span>Gesamt:</span>
                                <span class="font-medium">43h 22min</span>
                            </div>
                            <div class="flex justify-between">
                                <span>Überstunden:</span>
                                <span class="font-medium text-orange-600">3h 22min</span>
                            </div>
                            <div class="flex justify-between">
                                <span>Durchschnitt:</span>
                                <span class="font-medium">8h 40min</span>
                            </div>
                        </div>
                    </div>
                </div>


            </main>
        </div>

        <!-- JavaScript für Interaktivität -->
        <script>
            // Mobile Menu Toggle
            const mobileMenuBtn = document.getElementById('mobile-menu-btn');
            const mobileMenu = document.getElementById('mobile-menu');
            const mobileOverlay = document.getElementById('mobile-overlay');
            const closeMobileMenu = document.getElementById('close-mobile-menu');

            function openMobileMenu() {{
                mobileMenu.classList.add('open');
                mobileOverlay.classList.remove('hidden');
                document.body.style.overflow = 'hidden';
            }}

            function closeMobileMenuFunc() {{
                mobileMenu.classList.remove('open');
                mobileOverlay.classList.add('hidden');
                document.body.style.overflow = '';
            }}

            mobileMenuBtn.addEventListener('click', openMobileMenu);
            closeMobileMenu.addEventListener('click', closeMobileMenuFunc);
            mobileOverlay.addEventListener('click', closeMobileMenuFunc);

            // User Menu
            document.getElementById('user-menu-btn').addEventListener('click', function() {{
                const dropdown = document.getElementById('user-dropdown');
                dropdown.classList.toggle('hidden');
            }});

            // Timer Funktionalität
            let timerRunning = false;
            let startTime = null;
            let pausedTime = 0;
            let timerInterval = null;

            function updateTimer() {{
                if (timerRunning && startTime) {{
                    const now = new Date();
                    const diff = now - startTime + pausedTime;
                    const hours = Math.floor(diff / 3600000);
                    const minutes = Math.floor((diff % 3600000) / 60000);
                    const seconds = Math.floor((diff % 60000) / 1000);
                    
                    document.getElementById('timer-display').textContent = 
                        `${{hours.toString().padStart(2, '0')}}:${{minutes.toString().padStart(2, '0')}}:${{seconds.toString().padStart(2, '0')}}`;
                }}
            }}

            function resetButtons() {{
                document.getElementById('start-btn').disabled = false;
                document.getElementById('pause-btn').disabled = true;
                document.getElementById('stop-btn').disabled = true;
                document.getElementById('pause-btn').textContent = 'Pause';
            }}

            document.getElementById('start-btn').addEventListener('click', function() {{
                if (!timerRunning) {{
                    timerRunning = true;
                    startTime = new Date();
                    timerInterval = setInterval(updateTimer, 1000);
                    this.disabled = true;
                    document.getElementById('pause-btn').disabled = false;
                    document.getElementById('stop-btn').disabled = false;
                }}
            }});

            document.getElementById('pause-btn').addEventListener('click', function() {{
                if (timerRunning) {{
                    // Pause
                    clearInterval(timerInterval);
                    timerRunning = false;
                    pausedTime += new Date() - startTime;
                    this.textContent = 'Fortsetzen';
                    document.getElementById('start-btn').disabled = false;
                }} else {{
                    // Fortsetzen
                    timerRunning = true;
                    startTime = new Date();
                    timerInterval = setInterval(updateTimer, 1000);
                    this.textContent = 'Pause';
                    document.getElementById('start-btn').disabled = true;
                }}
            }});

            document.getElementById('stop-btn').addEventListener('click', function() {{
                clearInterval(timerInterval);
                timerRunning = false;
                startTime = null;
                pausedTime = 0;
                document.getElementById('timer-display').textContent = '00:00:00';
                resetButtons();
            }});

            // Arbeitszeitformular
            document.getElementById('arbeitszeit-form').addEventListener('submit', function(e) {{
                e.preventDefault();
                
                const datum = document.getElementById('datum').value;
                const activityType = document.getElementById('activity-type').value;
                const startTime = document.getElementById('start-time').value;
                const endTime = document.getElementById('end-time').value;
                const location = document.getElementById('location').value;
                const notes = document.getElementById('notes').value;
                
                if (!datum || !startTime || !endTime) {{
                    alert('Bitte füllen Sie alle Pflichtfelder aus.');
                    return;
                }}
                
                if (startTime >= endTime) {{
                    alert('Die Endzeit muss nach der Startzeit liegen.');
                    return;
                }}
                
                // Hier würde normalerweise der API-Call erfolgen
                alert('Arbeitszeit-Eintrag erfolgreich gespeichert!');
                this.reset();
            }});

            // Formular zurücksetzen
            document.getElementById('reset-form').addEventListener('click', function() {{
                document.getElementById('arbeitszeit-form').reset();
            }});

            // Filter-Buttons
            document.getElementById('filter-all').addEventListener('click', function() {{
                // Alle Einträge anzeigen
                console.log('Alle Einträge anzeigen');
            }});

            document.getElementById('filter-today').addEventListener('click', function() {{
                // Nur heutige Einträge anzeigen
                console.log('Nur heutige Einträge anzeigen');
            }});

            document.getElementById('filter-week').addEventListener('click', function() {{
                // Nur diese Woche anzeigen
                console.log('Nur diese Woche anzeigen');
            }});

            // Click outside to close dropdowns
            document.addEventListener('click', function(event) {{
                if (!event.target.closest('.relative')) {{
                    document.getElementById('user-dropdown').classList.add('hidden');
                }}
            }});
        </script>
    </body>
    </html>
    """

@app.route('/urlaub')
def urlaub():
    if 'user' not in session:
        return redirect('/login')
    
    # Get vacations from database
    db_session = get_db_session()
    try:
        if session['user']['role'] == 'Admin':
            vacations = db_session.query(Vacation).all()
        else:
            vacations = db_session.query(Vacation).filter_by(user_id=session['user']['id']).all()
        
        # Convert to JSON for frontend
        vacations_data = []
        for v in vacations:
            vacation_data = {
                'id': v.id,
                'user_id': v.user_id,
                'user_name': v.user.name if v.user else 'Unbekannt',
                'start_date': v.start_date.isoformat() if v.start_date else None,
                'end_date': v.end_date.isoformat() if v.end_date else None,
                'type': v.type,
                'start_time': v.start_time.isoformat() if v.start_time else None,
                'end_time': v.end_time.isoformat() if v.end_time else None,
                'duration': v.duration,
                'comment': v.comment,
                'status': v.status,
                'rejection_note': v.rejection_note,
                'history': json.loads(v.history) if v.history else [],
                'created_at': v.created_at.isoformat() if v.created_at else None,
                'updated_at': v.updated_at.isoformat() if v.updated_at else None
            }
            vacations_data.append(vacation_data)
    
    finally:
        db_session.close()
    
    # Vollständige Urlaubsverwaltungsseite mit Lackner Design
    user = session['user']
    vacations_json = json.dumps(vacations_data)
    
    return f"""
    <!DOCTYPE html>
    <html lang="de">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Urlaubsverwaltung - Lackner Aufzüge</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
        <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
        <script src="https://cdn.jsdelivr.net/npm/flatpickr/dist/l10n/de.js"></script>
        <style>
            :root {{
                --lackner-blue: #60a5fa;
                --lackner-light-blue: #93c5fd;
                --lackner-dark-blue: #3b82f6;
                --lackner-gray: #6b7280;
                --lackner-light-gray: #f3f4f6;
                --lackner-white: #ffffff;
                --lackner-border: #e5e7eb;
            }}
            
            .lackner-header {{
                background: linear-gradient(135deg, var(--lackner-blue) 0%, var(--lackner-dark-blue) 100%);
            }}
            
            .lackner-button {{
                background: var(--lackner-blue);
                color: white;
                transition: all 0.3s ease;
            }}
            .lackner-button:hover {{
                background: var(--lackner-dark-blue);
                transform: translateY(-1px);
            }}
            
            .lackner-secondary-button {{
                background: var(--lackner-white);
                color: var(--lackner-blue);
                border: 2px solid var(--lackner-blue);
                transition: all 0.3s ease;
            }}
            .lackner-secondary-button:hover {{
                background: var(--lackner-blue);
                color: white;
            }}
            
            .mobile-menu {{
                transform: translateX(-100%);
                transition: transform 0.3s ease;
            }}
            .mobile-menu.open {{
                transform: translateX(0);
            }}
            
            .vacation-card {{
                transition: all 0.3s ease;
            }}
            .vacation-card:hover {{
                transform: translateY(-2px);
                box-shadow: 0 10px 25px rgba(0,0,0,0.1);
            }}
            
            .modal {{
                display: none;
                position: fixed;
                z-index: 1000;
                left: 0;
                top: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(0,0,0,0.5);
            }}
            
            .modal-content {{
                background-color: white;
                margin: 5% auto;
                padding: 0;
                border-radius: 8px;
                width: 90%;
                max-width: 600px;
                max-height: 90vh;
                overflow-y: auto;
            }}
            
            .status-pending {{
                background-color: #fef3c7;
                color: #92400e;
            }}
            
            .status-approved {{
                background-color: #d1fae5;
                color: #065f46;
            }}
            
            .status-rejected {{
                background-color: #fee2e2;
                color: #991b1b;
            }}
        </style>
    </head>
    <body class="bg-gray-50">
        <div class="min-h-screen">
            <!-- Haupt-Header mit Lackner Design -->
            <header class="lackner-header text-white shadow-lg">
                <div class="container mx-auto px-4 py-3">
                    <div class="flex justify-between items-center">
                        <!-- Logo und Titel -->
                        <div class="flex items-center space-x-4">
                            <div class="bg-white rounded-lg p-2 shadow-md">
                                <img src="https://lackner-aufzuege-gmbh.com/wp-content/uploads/2021/09/cropped-2205_lackner_r.png" 
                                     alt="Lackner Aufzüge" class="h-10">
                            </div>
                            <div>
                                <h1 class="text-xl font-bold">Urlaubsverwaltung</h1>
                                <p class="text-sm opacity-90">Lackner Aufzüge GmbH</p>
                            </div>
                        </div>
                        
                        <!-- Desktop Navigation -->
                        <nav class="hidden lg:flex items-center space-x-6">
                            <!-- Nur User-Menu und Notifications in der obersten Leiste -->
                        </nav>
                        
                        <!-- Rechte Seite: User -->
                        <div class="flex items-center space-x-4">
                            <!-- User Menu -->
                            <div class="relative">
                                <button id="user-menu-btn" class="flex items-center space-x-2 hover:bg-blue-700 rounded-lg p-2 transition-colors">
                                    <div class="w-8 h-8 bg-white rounded-full flex items-center justify-center">
                                        <i class="fas fa-user text-blue-600"></i>
                                    </div>
                                    <span class="hidden md:block text-white">{user['name']}</span>
                                    <i class="fas fa-chevron-down text-sm text-white"></i>
                                </button>
                                
                                <!-- User Dropdown -->
                                <div id="user-dropdown" class="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-xl z-50 hidden">
                                    <div class="p-3 border-b">
                                        <div class="font-medium text-gray-900">{user['name']}</div>
                                        <div class="text-sm text-gray-600">{user['email']}</div>
                                    </div>
                                    <div class="py-1">
                                        <a href="/profile" class="block px-3 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                            <i class="fas fa-user-cog mr-2"></i>Profil
                                        </a>
                                        <a href="/settings" class="block px-3 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                            <i class="fas fa-cog mr-2"></i>Einstellungen
                                        </a>
                                        <hr class="my-1">
                                        <a href="/logout" class="block px-3 py-2 text-sm text-red-600 hover:bg-gray-100">
                                            <i class="fas fa-sign-out-alt mr-2"></i>Abmelden
                                        </a>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Mobile Menu Button -->
                            <button id="mobile-menu-btn" class="lg:hidden text-white p-2 hover:bg-blue-700 rounded-lg transition-colors">
                                <i class="fas fa-bars text-xl"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </header>
            
            <!-- Mobile Navigation Menu -->
            <div id="mobile-menu" class="mobile-menu fixed inset-y-0 left-0 w-64 bg-white shadow-lg z-50 lg:hidden">
                <div class="p-4 border-b">
                    <div class="flex items-center justify-between">
                        <div class="flex items-center space-x-2">
                            <img src="https://lackner-aufzuege-gmbh.com/wp-content/uploads/2021/09/cropped-2205_lackner_r.png" 
                                 alt="Lackner Aufzüge" class="h-8">
                            <span class="font-bold text-gray-900">Menu</span>
                        </div>
                        <button id="close-mobile-menu" class="text-gray-500 hover:text-gray-700">
                            <i class="fas fa-times text-xl"></i>
                        </button>
                    </div>
                </div>
                <nav class="p-4">
                    <div class="space-y-2">
                        <a href="/" class="block px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-700 rounded-lg transition-colors">
                            <i class="fas fa-home mr-3"></i>Dashboard
                        </a>
                        <a href="/meine-auftraege" class="block px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-700 rounded-lg transition-colors">
                            <i class="fas fa-tasks mr-3"></i>Aufträge
                        </a>
                        <a href="/arbeitszeit" class="block px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-700 rounded-lg transition-colors">
                            <i class="fas fa-clock mr-3"></i>Arbeitszeit
                        </a>
                        <a href="/urlaub" class="block px-4 py-3 text-blue-700 bg-blue-50 rounded-lg">
                            <i class="fas fa-umbrella-beach mr-3"></i>Urlaub
                        </a>
                        <a href="/zeiterfassung" class="block px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-700 rounded-lg transition-colors">
                            <i class="fas fa-stopwatch mr-3"></i>Zeiterfassung
                        </a>
                        <hr class="my-4">
                        <a href="/logout" class="block px-4 py-3 text-red-600 hover:bg-red-50 rounded-lg transition-colors">
                            <i class="fas fa-sign-out-alt mr-3"></i>Abmelden
                        </a>
                    </div>
                </nav>
            </div>
            
            <!-- Mobile Menu Overlay -->
            <div id="mobile-overlay" class="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden hidden"></div>
            
            <!-- Untermenüband für Hauptnavigation -->
            <div class="bg-white shadow-sm border-b">
                <div class="container mx-auto px-4 py-3">
                    <nav class="flex items-center justify-center space-x-8">
                        <a href="/" class="flex items-center space-x-2 px-4 py-2 rounded-lg hover:bg-blue-50 transition-colors">
                            <i class="fas fa-home text-blue-600 text-lg"></i>
                            <span class="font-medium text-gray-700">Dashboard</span>
                        </a>
                        <a href="/meine-auftraege" class="flex items-center space-x-2 px-4 py-2 rounded-lg hover:bg-blue-50 transition-colors">
                            <i class="fas fa-tasks text-blue-600 text-lg"></i>
                            <span class="font-medium text-gray-700">Aufträge</span>
                        </a>
                        <a href="/arbeitszeit" class="flex items-center space-x-2 px-4 py-2 rounded-lg hover:bg-blue-50 transition-colors">
                            <i class="fas fa-clock text-blue-600 text-lg"></i>
                            <span class="font-medium text-gray-700">Arbeitszeit</span>
                        </a>
                        <a href="/urlaub" class="flex items-center space-x-2 px-4 py-2 rounded-lg bg-blue-50 text-blue-700 border border-blue-200">
                            <i class="fas fa-umbrella-beach text-blue-600 text-lg"></i>
                            <span class="font-medium">Urlaub</span>
                        </a>
                        <a href="/zeiterfassung" class="flex items-center space-x-2 px-4 py-2 rounded-lg hover:bg-blue-50 transition-colors">
                            <i class="fas fa-stopwatch text-blue-600 text-lg"></i>
                            <span class="font-medium text-gray-700">Zeiterfassung</span>
                        </a>
                    </nav>
                </div>
            </div>
            
            <main class="container mx-auto p-6">
                <!-- Begrüßung und Status -->
                <div class="mb-8">
                    <h1 class="text-3xl font-bold text-gray-900 mb-2">
                        Urlaubsverwaltung
                    </h1>
                    <p class="text-gray-600">Verwalten Sie Ihre Urlaubsanträge</p>
                </div>

                <!-- Urlaubs-Statistiken -->
                <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                    <div class="bg-white rounded-lg shadow-md p-6 text-center">
                        <div class="text-3xl font-bold text-blue-600 mb-2" id="total-vacations">0</div>
                        <div class="text-sm text-gray-600">Gesamt Anträge</div>
                        <div class="text-xs text-gray-500 mt-1">Dieses Jahr</div>
                    </div>
                    <div class="bg-white rounded-lg shadow-md p-6 text-center">
                        <div class="text-3xl font-bold text-gray-700 mb-2" id="pending-vacations">0</div>
                        <div class="text-sm text-gray-600">Ausstehend</div>
                        <div class="text-xs text-gray-500 mt-1">Warten auf Genehmigung</div>
                    </div>
                    <div class="bg-white rounded-lg shadow-md p-6 text-center">
                        <div class="text-3xl font-bold text-green-600 mb-2" id="approved-vacations">0</div>
                        <div class="text-sm text-gray-600">Genehmigt</div>
                        <div class="text-xs text-gray-500 mt-1">Bestätigte Anträge</div>
                    </div>
                    <div class="bg-white rounded-lg shadow-md p-6 text-center">
                        <div class="text-3xl font-bold text-red-600 mb-2" id="rejected-vacations">0</div>
                        <div class="text-sm text-gray-600">Abgelehnt</div>
                        <div class="text-xs text-gray-500 mt-1">Nicht genehmigt</div>
                    </div>
                </div>

                <!-- Filter und Aktionen -->
                <div class="bg-white rounded-lg shadow-md p-6 mb-8">
                    <div class="flex flex-col md:flex-row gap-4 items-center justify-between">
                        <div class="flex flex-wrap gap-2">
                            <button id="filter-all" class="lackner-button px-4 py-2 rounded-lg text-sm font-medium">
                                Alle
                            </button>
                            <button id="filter-pending" class="lackner-secondary-button px-4 py-2 rounded-lg text-sm font-medium">
                                Ausstehend
                            </button>
                            <button id="filter-approved" class="lackner-secondary-button px-4 py-2 rounded-lg text-sm font-medium">
                                Genehmigt
                            </button>
                            <button id="filter-rejected" class="lackner-secondary-button px-4 py-2 rounded-lg text-sm font-medium">
                                Abgelehnt
                            </button>
                        </div>
                        <div class="flex gap-2">
                            <button id="new-vacation-btn" class="lackner-button px-4 py-2 rounded-lg">
                                <i class="fas fa-plus mr-2"></i>Neuer Antrag
                            </button>
                            {f'<button id="export-btn" class="lackner-secondary-button px-4 py-2 rounded-lg"><i class="fas fa-download mr-2"></i>Export CSV</button>' if user['role'] == 'Admin' else ''}
                        </div>
                    </div>
                </div>

                <!-- Urlaubsanträge Tabelle -->
                <div class="bg-white rounded-lg shadow-md overflow-hidden">
                    <div class="px-6 py-4 border-b border-gray-200">
                        <h3 class="text-lg font-semibold text-gray-900">Urlaubsanträge</h3>
                    </div>
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Antrag
                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Zeitraum
                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Typ
                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Dauer
                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Status
                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Kommentar
                                    </th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Aktionen
                                    </th>
                                </tr>
                            </thead>
                            <tbody id="vacations-tbody" class="bg-white divide-y divide-gray-200">
                                <!-- Vacation rows will be populated by JavaScript -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </main>
        </div>

        <!-- Neuer Urlaubsantrag Modal -->
        <div id="vacation-modal" class="modal">
            <div class="modal-content">
                <div class="bg-blue-600 text-white px-6 py-4 rounded-t-lg">
                    <div class="flex justify-between items-center">
                        <h2 class="text-xl font-semibold" id="modal-title">Neuer Urlaubsantrag</h2>
                        <button id="close-modal" class="text-white hover:text-gray-200">
                            <i class="fas fa-times text-xl"></i>
                        </button>
                    </div>
                </div>
                <div class="p-6">
                    <form id="vacation-form">
                        <input type="hidden" id="vacation-id">
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                            <div>
                                <label for="start-date" class="block text-sm font-medium text-gray-700 mb-2">
                                    Startdatum *
                                </label>
                                <input type="text" id="start-date" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
                            </div>
                            <div>
                                <label for="end-date" class="block text-sm font-medium text-gray-700 mb-2">
                                    Enddatum *
                                </label>
                                <input type="text" id="end-date" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
                            </div>
                        </div>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                            <div>
                                <label for="vacation-type" class="block text-sm font-medium text-gray-700 mb-2">
                                    Typ *
                                </label>
                                <select id="vacation-type" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
                                    <option value="full_day">Ganzer Tag</option>
                                    <option value="hourly">Stundenweise</option>
                                </select>
                            </div>
                            <div id="time-fields" class="hidden">
                                <div class="grid grid-cols-2 gap-2">
                                    <div>
                                        <label for="start-time" class="block text-sm font-medium text-gray-700 mb-2">
                                            Startzeit
                                        </label>
                                        <input type="time" id="start-time" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                                    </div>
                                    <div>
                                        <label for="end-time" class="block text-sm font-medium text-gray-700 mb-2">
                                            Endzeit
                                        </label>
                                        <input type="time" id="end-time" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mb-4">
                            <label for="vacation-comment" class="block text-sm font-medium text-gray-700 mb-2">
                                Kommentar
                            </label>
                            <textarea id="vacation-comment" rows="3" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="Optional: Beschreibung des Urlaubsantrags..."></textarea>
                        </div>
                        
                        <div class="flex justify-end space-x-3">
                            <button type="button" id="cancel-vacation" class="lackner-secondary-button px-4 py-2 rounded-lg">
                                Abbrechen
                            </button>
                            <button type="submit" class="lackner-button px-4 py-2 rounded-lg">
                                <i class="fas fa-save mr-2"></i>Speichern
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Approve/Reject Modal -->
        <div id="action-modal" class="modal">
            <div class="modal-content">
                <div class="bg-blue-600 text-white px-6 py-4 rounded-t-lg">
                    <div class="flex justify-between items-center">
                        <h2 class="text-xl font-semibold" id="action-modal-title">Antrag bearbeiten</h2>
                        <button id="close-action-modal" class="text-white hover:text-gray-200">
                            <i class="fas fa-times text-xl"></i>
                        </button>
                    </div>
                </div>
                <div class="p-6">
                    <form id="action-form">
                        <input type="hidden" id="action-vacation-id">
                        <input type="hidden" id="action-type">
                        
                        <div class="mb-4">
                            <label for="action-note" class="block text-sm font-medium text-gray-700 mb-2">
                                <span id="note-label">Notiz</span>
                            </label>
                            <textarea id="action-note" rows="3" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="Optional: Notiz zur Aktion..."></textarea>
                        </div>
                        
                        <div class="flex justify-end space-x-3">
                            <button type="button" id="cancel-action" class="lackner-secondary-button px-4 py-2 rounded-lg">
                                Abbrechen
                            </button>
                            <button type="submit" class="lackner-button px-4 py-2 rounded-lg">
                                <i class="fas fa-check mr-2"></i>Bestätigen
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <script>
            // Vacation data from backend
            let vacations = {vacations_json};
            let currentFilter = 'all';
            
            // Initialize date pickers
            flatpickr("#start-date", {{
                locale: "de",
                dateFormat: "Y-m-d",
                defaultDate: "today"
            }});
            
            flatpickr("#end-date", {{
                locale: "de",
                dateFormat: "Y-m-d",
                defaultDate: "today"
            }});
            
            // Mobile Menu
            const mobileMenuBtn = document.getElementById('mobile-menu-btn');
            const mobileMenu = document.getElementById('mobile-menu');
            const mobileOverlay = document.getElementById('mobile-overlay');
            const closeMobileMenu = document.getElementById('close-mobile-menu');

            function openMobileMenu() {{
                mobileMenu.classList.add('open');
                mobileOverlay.classList.remove('hidden');
                document.body.style.overflow = 'hidden';
            }}

            function closeMobileMenuFunc() {{
                mobileMenu.classList.remove('open');
                mobileOverlay.classList.add('hidden');
                document.body.style.overflow = '';
            }}

            mobileMenuBtn.addEventListener('click', openMobileMenu);
            closeMobileMenu.addEventListener('click', closeMobileMenuFunc);
            mobileOverlay.addEventListener('click', closeMobileMenuFunc);

            // User Menu
            document.getElementById('user-menu-btn').addEventListener('click', function() {{
                const dropdown = document.getElementById('user-dropdown');
                dropdown.classList.toggle('hidden');
            }});

            // Modal functions
            function openModal(modalId) {{
                document.getElementById(modalId).style.display = 'block';
            }}

            function closeModal(modalId) {{
                document.getElementById(modalId).style.display = 'none';
            }}

            // Vacation type change
            document.getElementById('vacation-type').addEventListener('change', function() {{
                const timeFields = document.getElementById('time-fields');
                if (this.value === 'hourly') {{
                    timeFields.classList.remove('hidden');
                }} else {{
                    timeFields.classList.add('hidden');
                }}
            }});

            // New vacation button
            document.getElementById('new-vacation-btn').addEventListener('click', function() {{
                document.getElementById('modal-title').textContent = 'Neuer Urlaubsantrag';
                document.getElementById('vacation-id').value = '';
                document.getElementById('vacation-form').reset();
                document.getElementById('time-fields').classList.add('hidden');
                openModal('vacation-modal');
            }});

            // Close modal buttons
            document.getElementById('close-modal').addEventListener('click', function() {{
                closeModal('vacation-modal');
            }});

            document.getElementById('cancel-vacation').addEventListener('click', function() {{
                closeModal('vacation-modal');
            }});

            document.getElementById('close-action-modal').addEventListener('click', function() {{
                closeModal('action-modal');
            }});

            document.getElementById('cancel-action').addEventListener('click', function() {{
                closeModal('action-modal');
            }});

            // Vacation form submit
            document.getElementById('vacation-form').addEventListener('submit', function(e) {{
                e.preventDefault();
                
                const formData = {{
                    start_date: document.getElementById('start-date').value,
                    end_date: document.getElementById('end-date').value,
                    type: document.getElementById('vacation-type').value,
                    comment: document.getElementById('vacation-comment').value
                }};
                
                if (formData.type === 'hourly') {{
                    formData.start_time = document.getElementById('start-time').value;
                    formData.end_time = document.getElementById('end-time').value;
                }}
                
                const vacationId = document.getElementById('vacation-id').value;
                const url = vacationId ? `/api/urlaub/${{vacationId}}` : '/api/urlaub';
                const method = vacationId ? 'PUT' : 'POST';
                
                fetch(url, {{
                    method: method,
                    headers: {{
                        'Content-Type': 'application/json',
                    }},
                    body: JSON.stringify(formData)
                }})
                .then(response => response.json())
                .then(data => {{
                    if (data.status === 'success') {{
                        closeModal('vacation-modal');
                        loadVacations();
                        alert('Urlaubsantrag erfolgreich gespeichert!');
                    }} else {{
                        alert('Fehler: ' + data.error);
                    }}
                }})
                .catch(error => {{
                    console.error('Error:', error);
                    alert('Fehler beim Speichern des Antrags');
                }});
            }});

            // Action form submit
            document.getElementById('action-form').addEventListener('submit', function(e) {{
                e.preventDefault();
                
                const vacationId = document.getElementById('action-vacation-id').value;
                const actionType = document.getElementById('action-type').value;
                const note = document.getElementById('action-note').value;
                
                if (actionType === 'reject' && !note) {{
                    alert('Ablehnungsgrund ist erforderlich!');
                    return;
                }}
                
                const formData = new FormData();
                formData.append('note', note);
                
                fetch(`/api/urlaub/${{vacationId}}/${{actionType}}`, {{
                    method: 'POST',
                    body: formData
                }})
                .then(response => response.json())
                .then(data => {{
                    if (data.status === 'success') {{
                        closeModal('action-modal');
                        loadVacations();
                        alert(`Antrag erfolgreich ${{actionType === 'approve' ? 'genehmigt' : 'abgelehnt'}}!`);
                    }} else {{
                        alert('Fehler: ' + data.error);
                    }}
                }})
                .catch(error => {{
                    console.error('Error:', error);
                    alert('Fehler bei der Aktion');
                }});
            }});

            // Filter functions
            function setFilter(filter) {{
                currentFilter = filter;
                document.querySelectorAll('[id^="filter-"]').forEach(btn => {{
                    btn.classList.remove('lackner-button');
                    btn.classList.add('lackner-secondary-button');
                }});
                document.getElementById(`filter-${{filter}}`).classList.remove('lackner-secondary-button');
                document.getElementById(`filter-${{filter}}`).classList.add('lackner-button');
                renderVacations();
            }}

            // Render vacations
            function renderVacations() {{
                const tbody = document.getElementById('vacations-tbody');
                tbody.innerHTML = '';
                
                const filteredVacations = vacations.filter(v => {{
                    if (currentFilter === 'all') return true;
                    return v.status === currentFilter;
                }});
                
                filteredVacations.forEach(vacation => {{
                    const row = document.createElement('tr');
                    row.className = 'hover:bg-gray-50';
                    
                    const startDate = new Date(vacation.start_date).toLocaleDateString('de-DE');
                    const endDate = new Date(vacation.end_date).toLocaleDateString('de-DE');
                    const duration = vacation.duration ? `${vacation.duration} Stunden` : 'N/A';
                    const type = vacation.type === 'full_day' ? 'Ganzer Tag' : 'Stundenweise';
                    
                    let statusClass = '';
                    let statusText = '';
                    switch(vacation.status) {{
                        case 'pending':
                            statusClass = 'status-pending';
                            statusText = 'Ausstehend';
                            break;
                        case 'approved':
                            statusClass = 'status-approved';
                            statusText = 'Genehmigt';
                            break;
                        case 'rejected':
                            statusClass = 'status-rejected';
                            statusText = 'Abgelehnt';
                            break;
                    }}
                    
                    row.innerHTML = `
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm font-medium text-gray-900">#${{vacation.id}}</div>
                            <div class="text-sm text-gray-500">${{vacation.user_name}}</div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm text-gray-900">${{startDate}} - ${{endDate}}</div>
                            ${{vacation.start_time && vacation.end_time ? `<div class="text-sm text-gray-500">${{vacation.start_time}} - ${{vacation.end_time}}</div>` : ''}}
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${{type}}</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${{duration}}</td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <span class="px-2 py-1 text-xs font-medium rounded-full ${{statusClass}}">${{statusText}}</span>
                        </td>
                        <td class="px-6 py-4 text-sm text-gray-900">${{vacation.comment || '-'}}</td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            ${{getActionButtons(vacation)}}
                        </td>
                    `;
                    
                    tbody.appendChild(row);
                }});
                
                updateStatistics();
            }}

            function getActionButtons(vacation) {{
                const buttons = [];
                
                if (vacation.status === 'pending') {{
                    if ('{user['role']}' === 'Admin') {{
                        buttons.push(`<button onclick="approveVacation(${{vacation.id}})" class="text-green-600 hover:text-green-900 mr-2"><i class="fas fa-check"></i></button>`);
                        buttons.push(`<button onclick="rejectVacation(${{vacation.id}})" class="text-red-600 hover:text-red-900 mr-2"><i class="fas fa-times"></i></button>`);
                    }}
                    buttons.push(`<button onclick="editVacation(${{vacation.id}})" class="text-blue-600 hover:text-blue-900 mr-2"><i class="fas fa-edit"></i></button>`);
                }}
                
                if (vacation.status === 'rejected' || (vacation.status === 'pending' && '{user['role']}' === 'Admin')) {{
                    buttons.push(`<button onclick="deleteVacation(${{vacation.id}})" class="text-red-600 hover:text-red-900"><i class="fas fa-trash"></i></button>`);
                }}
                
                return buttons.join('');
            }}

            function approveVacation(id) {{
                document.getElementById('action-vacation-id').value = id;
                document.getElementById('action-type').value = 'approve';
                document.getElementById('action-modal-title').textContent = 'Antrag genehmigen';
                document.getElementById('note-label').textContent = 'Notiz (optional)';
                document.getElementById('action-note').placeholder = 'Optional: Notiz zur Genehmigung...';
                openModal('action-modal');
            }}

            function rejectVacation(id) {{
                document.getElementById('action-vacation-id').value = id;
                document.getElementById('action-type').value = 'reject';
                document.getElementById('action-modal-title').textContent = 'Antrag ablehnen';
                document.getElementById('note-label').textContent = 'Ablehnungsgrund *';
                document.getElementById('action-note').placeholder = 'Grund für die Ablehnung...';
                openModal('action-modal');
            }}

            function editVacation(id) {{
                const vacation = vacations.find(v => v.id === id);
                if (!vacation) return;
                
                document.getElementById('modal-title').textContent = 'Urlaubsantrag bearbeiten';
                document.getElementById('vacation-id').value = vacation.id;
                document.getElementById('start-date').value = vacation.start_date;
                document.getElementById('end-date').value = vacation.end_date;
                document.getElementById('vacation-type').value = vacation.type;
                document.getElementById('vacation-comment').value = vacation.comment || '';
                
                if (vacation.type === 'hourly') {{
                    document.getElementById('time-fields').classList.remove('hidden');
                    document.getElementById('start-time').value = vacation.start_time || '';
                    document.getElementById('end-time').value = vacation.end_time || '';
                }} else {{
                    document.getElementById('time-fields').classList.add('hidden');
                }}
                
                openModal('vacation-modal');
            }}

            function deleteVacation(id) {{
                if (!confirm('Möchten Sie diesen Antrag wirklich löschen?')) return;
                
                fetch(`/api/urlaub/${{id}}`, {{
                    method: 'DELETE'
                }})
                .then(response => response.json())
                .then(data => {{
                    if (data.status === 'success') {{
                        loadVacations();
                        alert('Antrag erfolgreich gelöscht!');
                    }} else {{
                        alert('Fehler: ' + data.error);
                    }}
                }})
                .catch(error => {{
                    console.error('Error:', error);
                    alert('Fehler beim Löschen des Antrags');
                }});
            }}

            function updateStatistics() {{
                const total = vacations.length;
                const pending = vacations.filter(v => v.status === 'pending').length;
                const approved = vacations.filter(v => v.status === 'approved').length;
                const rejected = vacations.filter(v => v.status === 'rejected').length;
                
                document.getElementById('total-vacations').textContent = total;
                document.getElementById('pending-vacations').textContent = pending;
                document.getElementById('approved-vacations').textContent = approved;
                document.getElementById('rejected-vacations').textContent = rejected;
            }}

            function loadVacations() {{
                fetch('/api/urlaub')
                .then(response => response.json())
                .then(data => {{
                    vacations = data;
                    renderVacations();
                }})
                .catch(error => {{
                    console.error('Error loading vacations:', error);
                }});
            }}

            // Filter event listeners
            document.getElementById('filter-all').addEventListener('click', () => setFilter('all'));
            document.getElementById('filter-pending').addEventListener('click', () => setFilter('pending'));
            document.getElementById('filter-approved').addEventListener('click', () => setFilter('approved'));
            document.getElementById('filter-rejected').addEventListener('click', () => setFilter('rejected'));

            // Export button
            {f'document.getElementById("export-btn").addEventListener("click", function() {{ window.location.href = "/api/urlaub/export"; }});' if user['role'] == 'Admin' else ''}

            // Click outside to close dropdowns
            document.addEventListener('click', function(event) {{
                if (!event.target.closest('.relative')) {{
                    document.getElementById('user-dropdown').classList.add('hidden');
                }}
            }});

            // Initialize
            renderVacations();
            
            // Wetter-Widget Funktionalität
            function updateWeather() {{
                // Simuliere Wetter-API Call
                const weatherData = {{
                    temperature: Math.floor(Math.random() * 15) + 10, // 10-25°C
                    condition: ['Sonnig', 'Leicht bewölkt', 'Bewölkt', 'Regnerisch'][Math.floor(Math.random() * 4)],
                    feelsLike: Math.floor(Math.random() * 10) + 8,
                    forecast: [
                        {{ day: 'Heute', temp: Math.floor(Math.random() * 15) + 10, icon: 'fa-sun' }},
                        {{ day: 'Morgen', temp: Math.floor(Math.random() * 15) + 10, icon: 'fa-cloud' }},
                        {{ day: 'Übermorgen', temp: Math.floor(Math.random() * 15) + 10, icon: 'fa-cloud-rain' }}
                    ]
                }};
                
                // Update Wetter-Display
                document.querySelector('.weather-card .text-3xl').textContent = weatherData.temperature + '°C';
                document.querySelector('.weather-card .text-sm.opacity-90').textContent = weatherData.condition;
                document.querySelector('.weather-card .text-xs.opacity-75').textContent = 'Gefühlt: ' + weatherData.feelsLike + '°C';
                
                // Update Forecast
                const forecastItems = document.querySelectorAll('.weather-card .space-y-2 > div');
                forecastItems.forEach((item, index) => {{
                    if (index < weatherData.forecast.length) {{
                        const icon = item.querySelector('i');
                        const temp = item.querySelector('.font-bold');
                        icon.className = 'fas ' + weatherData.forecast[index].icon + ' mr-2';
                        temp.textContent = weatherData.forecast[index].temp + '°C';
                    }}
                }});
            }}
            
            // Update Wetter alle 30 Minuten
            setInterval(updateWeather, 30 * 60 * 1000);
            
            // Initial Wetter-Update
            updateWeather();
        </script>
    </body>
    </html>
    """
                            
                            <div class="flex space-x-4">
                                <button type="submit" class="lackner-button px-6 py-3 rounded-lg font-medium">
                                    <i class="fas fa-paper-plane mr-2"></i>Antrag einreichen
                                </button>
                                <button type="button" id="reset-form" class="lackner-secondary-button px-6 py-3 rounded-lg font-medium">
                                    <i class="fas fa-undo mr-2"></i>Zurücksetzen
                                </button>
                            </div>
                        </form>
                    </div>

                    <!-- Nächster Urlaub -->
                    <div class="bg-white rounded-lg shadow-md p-6">
                        <div class="flex items-center mb-6">
                            <i class="fas fa-calendar-alt text-blue-600 text-xl mr-3"></i>
                            <h2 class="text-xl font-semibold text-gray-900">Nächster Urlaub</h2>
                        </div>
                        
                        <div class="urlaub-card p-4 bg-blue-50 rounded-lg border-l-4 border-blue-500">
                            <div class="flex items-center justify-between mb-3">
                                <div class="flex items-center">
                                    <i class="fas fa-umbrella-beach text-blue-600 mr-2"></i>
                                    <span class="font-medium text-blue-900">Sommerurlaub 2024</span>
                                </div>
                                <span class="text-xs bg-blue-200 text-blue-800 px-2 py-1 rounded">Genehmigt</span>
                            </div>
                            <div class="text-sm text-blue-800 mb-2">
                                <strong>15.08.2024 - 22.08.2024</strong>
                            </div>
                            <div class="text-xs text-blue-700">
                                8 Tage Urlaub • Resturlaub: 17 Tage
                            </div>
                        </div>
                        
                        <div class="mt-4 p-3 bg-gray-50 rounded-lg">
                            <div class="text-sm font-medium text-gray-900 mb-2">Urlaubsübersicht 2024</div>
                            <div class="space-y-2 text-xs">
                                <div class="flex justify-between">
                                    <span>Gesamturlaub:</span>
                                    <span class="font-medium">30 Tage</span>
                                </div>
                                <div class="flex justify-between">
                                    <span>Verbraucht:</span>
                                    <span class="font-medium text-green-600">5 Tage</span>
                                </div>
                                <div class="flex justify-between">
                                    <span>Geplant:</span>
                                    <span class="font-medium text-blue-600">8 Tage</span>
                                </div>
                                <div class="flex justify-between border-t pt-2">
                                    <span class="font-medium">Übrig:</span>
                                    <span class="font-medium text-purple-600">17 Tage</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Urlaubsanträge Übersicht -->
                <div class="bg-white rounded-lg shadow-md p-6 mb-8">
                    <div class="flex items-center justify-between mb-6">
                        <div class="flex items-center">
                            <i class="fas fa-list-alt text-gray-600 text-xl mr-3"></i>
                            <h2 class="text-xl font-semibold text-gray-900">Meine Urlaubsanträge</h2>
                        </div>
                        <div class="flex space-x-2">
                            <button id="filter-all" class="lackner-button px-3 py-1 rounded text-xs">
                                Alle
                            </button>
                            <button id="filter-pending" class="lackner-secondary-button px-3 py-1 rounded text-xs">
                                Pending
                            </button>
                            <button id="filter-approved" class="lackner-secondary-button px-3 py-1 rounded text-xs">
                                Genehmigt
                            </button>
                        </div>
                    </div>
                    
                    <div class="space-y-4">
                        <!-- Pending Antrag -->
                        <div class="urlaub-card p-4 bg-blue-50 rounded-lg border-l-4 border-blue-500">
                            <div class="flex items-center justify-between">
                                <div class="flex-1">
                                    <div class="flex items-center gap-2 mb-1">
                                        <span class="text-sm font-medium text-blue-900">Weihnachtsurlaub 2024</span>
                                        <span class="text-xs bg-blue-200 text-blue-800 px-2 py-1 rounded">Pending</span>
                                    </div>
                                    <div class="text-sm text-blue-800">23.12.2024 - 27.12.2024</div>
                                    <div class="text-xs text-blue-700 mt-1">5 Tage • Eingereicht: 15.07.2024</div>
                                </div>
                                <div class="flex space-x-2">
                                    <button class="lackner-button px-3 py-1 rounded text-xs">
                                        <i class="fas fa-edit mr-1"></i>Bearbeiten
                                    </button>
                                    <button class="bg-gray-600 text-white px-3 py-1 rounded text-xs hover:bg-gray-700">
                                        <i class="fas fa-trash mr-1"></i>Löschen
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- Genehmigter Antrag -->
                        <div class="urlaub-card p-4 bg-gray-50 rounded-lg border-l-4 border-gray-400">
                            <div class="flex items-center justify-between">
                                <div class="flex-1">
                                    <div class="flex items-center gap-2 mb-1">
                                        <span class="text-sm font-medium text-gray-900">Sommerurlaub 2024</span>
                                        <span class="text-xs bg-gray-200 text-gray-800 px-2 py-1 rounded">Genehmigt</span>
                                    </div>
                                    <div class="text-sm text-gray-800">15.08.2024 - 22.08.2024</div>
                                    <div class="text-xs text-gray-700 mt-1">8 Tage • Genehmigt: 20.06.2024</div>
                                </div>
                                <div class="flex space-x-2">
                                    <button class="lackner-secondary-button px-3 py-1 rounded text-xs">
                                        <i class="fas fa-eye mr-1"></i>Details
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- Abgelehnter Antrag -->
                        <div class="urlaub-card p-4 bg-gray-50 rounded-lg border-l-4 border-gray-400">
                            <div class="flex items-center justify-between">
                                <div class="flex-1">
                                    <div class="flex items-center gap-2 mb-1">
                                        <span class="text-sm font-medium text-gray-900">Osterurlaub 2024</span>
                                        <span class="text-xs bg-gray-200 text-gray-800 px-2 py-1 rounded">Abgelehnt</span>
                                    </div>
                                    <div class="text-sm text-gray-800">28.03.2024 - 02.04.2024</div>
                                    <div class="text-xs text-gray-700 mt-1">6 Tage • Abgelehnt: 15.02.2024</div>
                                    <div class="text-xs text-gray-600 mt-1">
                                        <strong>Grund:</strong> Zu viele Kollegen im Urlaub
                                    </div>
                                </div>
                                <div class="flex space-x-2">
                                    <button class="lackner-secondary-button px-3 py-1 rounded text-xs">
                                        <i class="fas fa-eye mr-1"></i>Details
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


            </main>
        </div>

        <!-- JavaScript für Interaktivität -->
        <script>
            // Mobile Menu Toggle
            const mobileMenuBtn = document.getElementById('mobile-menu-btn');
            const mobileMenu = document.getElementById('mobile-menu');
            const mobileOverlay = document.getElementById('mobile-overlay');
            const closeMobileMenu = document.getElementById('close-mobile-menu');

            function openMobileMenu() {{
                mobileMenu.classList.add('open');
                mobileOverlay.classList.remove('hidden');
                document.body.style.overflow = 'hidden';
            }}

            function closeMobileMenuFunc() {{
                mobileMenu.classList.remove('open');
                mobileOverlay.classList.add('hidden');
                document.body.style.overflow = '';
            }}

            mobileMenuBtn.addEventListener('click', openMobileMenu);
            closeMobileMenu.addEventListener('click', closeMobileMenuFunc);
            mobileOverlay.addEventListener('click', closeMobileMenuFunc);

            // User Menu
            document.getElementById('user-menu-btn').addEventListener('click', function() {{
                const dropdown = document.getElementById('user-dropdown');
                dropdown.classList.toggle('hidden');
            }});

            // Urlaubsformular
            document.getElementById('urlaub-form').addEventListener('submit', function(e) {{
                e.preventDefault();
                
                const startDate = document.getElementById('start-date').value;
                const endDate = document.getElementById('end-date').value;
                const urlaubType = document.getElementById('urlaub-type').value;
                const bemerkung = document.getElementById('bemerkung').value;
                
                if (!startDate || !endDate) {{
                    alert('Bitte füllen Sie alle Pflichtfelder aus.');
                    return;
                }}
                
                if (new Date(startDate) >= new Date(endDate)) {{
                    alert('Das Enddatum muss nach dem Startdatum liegen.');
                    return;
                }}
                
                // Hier würde normalerweise der API-Call erfolgen
                alert('Urlaubsantrag erfolgreich eingereicht!');
                this.reset();
            }});

            // Formular zurücksetzen
            document.getElementById('reset-form').addEventListener('click', function() {{
                document.getElementById('urlaub-form').reset();
            }});

            // Filter-Buttons
            document.getElementById('filter-all').addEventListener('click', function() {{
                // Alle Anträge anzeigen
                console.log('Alle Anträge anzeigen');
            }});

            document.getElementById('filter-pending').addEventListener('click', function() {{
                // Nur pending Anträge anzeigen
                console.log('Nur pending Anträge anzeigen');
            }});

            document.getElementById('filter-approved').addEventListener('click', function() {{
                // Nur genehmigte Anträge anzeigen
                console.log('Nur genehmigte Anträge anzeigen');
            }});

            // Click outside to close dropdowns
            document.addEventListener('click', function(event) {{
                if (!event.target.closest('.relative')) {{
                    document.getElementById('user-dropdown').classList.add('hidden');
                }}
            }});
        </script>
    </body>
    </html>
    """

@app.route('/buero')
@requires_role('Admin')
def buero():
    # Inline HTML für Büro
    return f"""
    <!DOCTYPE html>
    <html lang="de">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Büro - Zeiterfassung System</title>
        <script src="https://cdn.tailwindcss.com"></script>
    </head>
    <body class="bg-gray-100">
        <div class="min-h-screen">
            <header class="bg-blue-600 text-white p-4">
                <div class="container mx-auto flex justify-between items-center">
                    <h1 class="text-2xl font-bold">🏢 Büro</h1>
                    <div class="flex space-x-4">
                        <a href="/" class="hover:underline">Dashboard</a>
                        <a href="/logout" class="bg-red-600 px-4 py-2 rounded hover:bg-red-700">Abmelden</a>
                    </div>
                </div>
            </header>
            
            <main class="container mx-auto p-6">
                <div class="bg-white rounded-lg shadow p-6">
                    <h2 class="text-xl font-semibold mb-4">Administrator-Bereich</h2>
                    <p class="text-gray-600">Hier können Sie alle Bereiche verwalten.</p>
                    <p class="text-sm text-gray-500 mt-4">API-Endpunkte verfügbar für alle CRUD-Operationen</p>
                </div>
            </main>
        </div>
    </body>
    </html>
    """

@app.route('/health')
def health():
    return {'status': 'healthy', 'version': '1.0.0'}

@app.route('/meine-auftraege')
def meine_auftraege():
    if 'user' not in session:
        return redirect('/login')
    
    # Vollständige Auftragsverwaltungsseite mit Lackner Design
    user = session['user']
    return f"""
    <!DOCTYPE html>
    <html lang="de">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Meine Aufträge - Lackner Aufzüge</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
        <style>
            :root {{
                --lackner-blue: #60a5fa;
                --lackner-light-blue: #93c5fd;
                --lackner-dark-blue: #3b82f6;
                --lackner-gray: #6b7280;
                --lackner-light-gray: #f3f4f6;
                --lackner-white: #ffffff;
                --lackner-border: #e5e7eb;
            }}
            
            .lackner-header {{
                background: linear-gradient(135deg, var(--lackner-blue) 0%, var(--lackner-dark-blue) 100%);
            }}
            
            .lackner-button {{
                background: var(--lackner-blue);
                color: white;
                transition: all 0.3s ease;
            }}
            .lackner-button:hover {{
                background: var(--lackner-dark-blue);
                transform: translateY(-1px);
            }}
            
            .lackner-secondary-button {{
                background: var(--lackner-white);
                color: var(--lackner-blue);
                border: 2px solid var(--lackner-blue);
                transition: all 0.3s ease;
            }}
            .lackner-secondary-button:hover {{
                background: var(--lackner-blue);
                color: white;
            }}
            
            .mobile-menu {{
                transform: translateX(-100%);
                transition: transform 0.3s ease;
            }}
            .mobile-menu.open {{
                transform: translateX(0);
            }}
            
            .auftrag-card {{
                transition: all 0.3s ease;
            }}
            .auftrag-card:hover {{
                transform: translateY(-2px);
                box-shadow: 0 10px 25px rgba(0,0,0,0.1);
            }}
            
            .weather-card {{
                background: linear-gradient(135deg, #60a5fa 0%, #3b82f6 100%);
                transition: all 0.3s ease;
            }}
            .weather-card:hover {{
                transform: translateY(-2px);
                box-shadow: 0 10px 25px rgba(0,0,0,0.2);
            }}
        </style>
    </head>
    <body class="bg-gray-50">
        <div class="min-h-screen">
            <!-- Haupt-Header mit Lackner Design -->
            <header class="lackner-header text-white shadow-lg">
                <div class="container mx-auto px-4 py-3">
                    <div class="flex justify-between items-center">
                        <!-- Logo und Titel -->
                        <div class="flex items-center space-x-4">
                            <div class="bg-white rounded-lg p-2 shadow-md">
                                <img src="https://lackner-aufzuege-gmbh.com/wp-content/uploads/2021/09/cropped-2205_lackner_r.png" 
                                     alt="Lackner Aufzüge" class="h-10">
                            </div>
                            <div>
                                <h1 class="text-xl font-bold">Meine Aufträge</h1>
                                <p class="text-sm opacity-90">Lackner Aufzüge GmbH</p>
                            </div>
                        </div>
                        
                        <!-- Desktop Navigation -->
                        <nav class="hidden lg:flex items-center space-x-6">
                            <!-- Nur User-Menu und Notifications in der obersten Leiste -->
                        </nav>
                        
                        <!-- Rechte Seite: User -->
                        <div class="flex items-center space-x-4">
                            <!-- User Menu -->
                            <div class="relative">
                                <button id="user-menu-btn" class="flex items-center space-x-2 hover:bg-blue-700 rounded-lg p-2 transition-colors">
                                    <div class="w-8 h-8 bg-white rounded-full flex items-center justify-center">
                                        <i class="fas fa-user text-blue-600"></i>
                                    </div>
                                    <span class="hidden md:block text-white">{user['name']}</span>
                                    <i class="fas fa-chevron-down text-sm text-white"></i>
                                </button>
                                
                                <!-- User Dropdown -->
                                <div id="user-dropdown" class="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-xl z-50 hidden">
                                    <div class="p-3 border-b">
                                        <div class="font-medium text-gray-900">{user['name']}</div>
                                        <div class="text-sm text-gray-600">{user['email']}</div>
                                    </div>
                                    <div class="py-1">
                                        <a href="/profile" class="block px-3 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                            <i class="fas fa-user-cog mr-2"></i>Profil
                                        </a>
                                        <a href="/settings" class="block px-3 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                            <i class="fas fa-cog mr-2"></i>Einstellungen
                                        </a>
                                        <hr class="my-1">
                                        <a href="/logout" class="block px-3 py-2 text-sm text-red-600 hover:bg-gray-100">
                                            <i class="fas fa-sign-out-alt mr-2"></i>Abmelden
                                        </a>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Mobile Menu Button -->
                            <button id="mobile-menu-btn" class="lg:hidden text-white p-2 hover:bg-blue-700 rounded-lg transition-colors">
                                <i class="fas fa-bars text-xl"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </header>
            
            <!-- Mobile Navigation Menu -->
            <div id="mobile-menu" class="mobile-menu fixed inset-y-0 left-0 w-64 bg-white shadow-lg z-50 lg:hidden">
                <div class="p-4 border-b">
                    <div class="flex items-center justify-between">
                        <div class="flex items-center space-x-2">
                            <img src="https://lackner-aufzuege-gmbh.com/wp-content/uploads/2021/09/cropped-2205_lackner_r.png" 
                                 alt="Lackner Aufzüge" class="h-8">
                            <span class="font-bold text-gray-900">Menu</span>
                        </div>
                        <button id="close-mobile-menu" class="text-gray-500 hover:text-gray-700">
                            <i class="fas fa-times text-xl"></i>
                        </button>
                    </div>
                </div>
                <nav class="p-4">
                    <div class="space-y-2">
                        <a href="/" class="block px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-700 rounded-lg transition-colors">
                            <i class="fas fa-home mr-3"></i>Dashboard
                        </a>
                        <a href="/meine-auftraege" class="block px-4 py-3 text-blue-700 bg-blue-50 rounded-lg">
                            <i class="fas fa-tasks mr-3"></i>Aufträge
                        </a>
                        <a href="/arbeitszeit" class="block px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-700 rounded-lg transition-colors">
                            <i class="fas fa-clock mr-3"></i>Arbeitszeit
                        </a>
                        <a href="/urlaub" class="block px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-700 rounded-lg transition-colors">
                            <i class="fas fa-umbrella-beach mr-3"></i>Urlaub
                        </a>
                        <a href="/zeiterfassung" class="block px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-700 rounded-lg transition-colors">
                            <i class="fas fa-stopwatch mr-3"></i>Zeiterfassung
                        </a>
                        <hr class="my-4">
                        <a href="/profile" class="block px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-700 rounded-lg transition-colors">
                            <i class="fas fa-user-cog mr-3"></i>Profil
                        </a>
                        <a href="/settings" class="block px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-700 rounded-lg transition-colors">
                            <i class="fas fa-cog mr-3"></i>Einstellungen
                        </a>
                        <a href="/logout" class="block px-4 py-3 text-red-600 hover:bg-red-50 rounded-lg transition-colors">
                            <i class="fas fa-sign-out-alt mr-3"></i>Abmelden
                        </a>
                    </div>
                </nav>
            </div>
            
            <!-- Mobile Menu Overlay -->
            <div id="mobile-overlay" class="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden hidden"></div>
            
            <!-- Untermenüband für Hauptnavigation -->
            <div class="bg-white shadow-sm border-b">
                <div class="container mx-auto px-4 py-3">
                    <nav class="flex items-center justify-center space-x-8">
                        <a href="/" class="flex items-center space-x-2 px-4 py-2 rounded-lg hover:bg-blue-50 transition-colors">
                            <i class="fas fa-home text-blue-600 text-lg"></i>
                            <span class="font-medium text-gray-700">Dashboard</span>
                        </a>
                        <a href="/meine-auftraege" class="flex items-center space-x-2 px-4 py-2 rounded-lg bg-blue-50 text-blue-700 border border-blue-200">
                            <i class="fas fa-tasks text-blue-600 text-lg"></i>
                            <span class="font-medium">Aufträge</span>
                        </a>
                        <a href="/arbeitszeit" class="flex items-center space-x-2 px-4 py-2 rounded-lg hover:bg-blue-50 transition-colors">
                            <i class="fas fa-clock text-blue-600 text-lg"></i>
                            <span class="font-medium text-gray-700">Arbeitszeit</span>
                        </a>
                        <a href="/urlaub" class="flex items-center space-x-2 px-4 py-2 rounded-lg hover:bg-blue-50 transition-colors">
                            <i class="fas fa-umbrella-beach text-blue-600 text-lg"></i>
                            <span class="font-medium text-gray-700">Urlaub</span>
                        </a>
                        <a href="/zeiterfassung" class="flex items-center space-x-2 px-4 py-2 rounded-lg hover:bg-blue-50 transition-colors">
                            <i class="fas fa-stopwatch text-blue-600 text-lg"></i>
                            <span class="font-medium text-gray-700">Zeiterfassung</span>
                        </a>
                    </nav>
                </div>
            </div>
            
            <main class="container mx-auto p-6">
                <!-- Begrüßung und Status -->
                <div class="mb-8">
                    <h1 class="text-3xl font-bold text-gray-900 mb-2">
                        Meine Aufträge
                    </h1>
                    <p class="text-gray-600">Verwalten Sie Ihre Aufträge und Aufgaben</p>
                </div>

                <!-- Auftrags-Statistiken -->
                <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                    <div class="bg-white rounded-lg shadow-md p-6 text-center">
                        <div class="text-3xl font-bold text-blue-600 mb-2">12</div>
                        <div class="text-sm text-gray-600">Offene Aufträge</div>
                        <div class="text-xs text-gray-500 mt-1">Diese Woche</div>
                    </div>
                    <div class="bg-white rounded-lg shadow-md p-6 text-center">
                        <div class="text-3xl font-bold text-gray-700 mb-2">8</div>
                        <div class="text-sm text-gray-600">Erledigt</div>
                        <div class="text-xs text-gray-500 mt-1">Diese Woche</div>
                    </div>
                    <div class="bg-white rounded-lg shadow-md p-6 text-center">
                        <div class="text-3xl font-bold text-blue-600 mb-2">3</div>
                        <div class="text-sm text-gray-600">Notfälle</div>
                        <div class="text-xs text-gray-500 mt-1">Heute</div>
                    </div>
                    <div class="bg-white rounded-lg shadow-md p-6 text-center">
                        <div class="text-3xl font-bold text-gray-700 mb-2">2.5h</div>
                        <div class="text-sm text-gray-600">Durchschnitt</div>
                        <div class="text-xs text-gray-500 mt-1">Pro Auftrag</div>
                    </div>
                </div>

                <!-- Filter und Suche -->
                <div class="bg-white rounded-lg shadow-md p-6 mb-8">
                    <div class="flex flex-col md:flex-row gap-4 items-center justify-between">
                        <div class="flex flex-wrap gap-2">
                            <button class="lackner-button px-4 py-2 rounded-lg text-sm font-medium">
                                Alle
                            </button>
                            <button class="lackner-secondary-button px-4 py-2 rounded-lg text-sm font-medium">
                                Offen
                            </button>
                            <button class="lackner-secondary-button px-4 py-2 rounded-lg text-sm font-medium">
                                In Bearbeitung
                            </button>
                            <button class="lackner-secondary-button px-4 py-2 rounded-lg text-sm font-medium">
                                Erledigt
                            </button>
                            <button class="lackner-secondary-button px-4 py-2 rounded-lg text-sm font-medium">
                                Notfälle
                            </button>
                        </div>
                        <div class="flex gap-2">
                            <input type="text" placeholder="Auftrag suchen..." 
                                   class="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                            <button class="lackner-button px-4 py-2 rounded-lg">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Auftragsliste -->
                <div class="space-y-4">
                    <!-- Notfall-Auftrag -->
                    <div class="auftrag-card bg-white rounded-lg shadow-md p-6 border-l-4 border-blue-500">
                        <div class="flex items-start justify-between">
                            <div class="flex-1">
                                <div class="flex items-center gap-2 mb-2">
                                    <span class="text-lg font-semibold text-gray-900">#AUF-2024-001</span>
                                    <span class="text-xs bg-blue-200 text-blue-800 px-2 py-1 rounded">Notfall</span>
                                    <span class="text-xs bg-red-200 text-red-800 px-2 py-1 rounded">Hoch</span>
                                </div>
                                <h3 class="text-xl font-bold text-gray-900 mb-2">Hauptbahnhof München - Aufzug klemmt</h3>
                                <p class="text-gray-600 mb-3">Notruf ausgelöst, Aufzug klemmt zwischen 2. und 3. Stock. Dringende Reparatur erforderlich.</p>
                                <div class="flex items-center gap-4 text-sm text-gray-500 mb-3">
                                    <span><i class="fas fa-map-marker-alt mr-1"></i>Hauptbahnhof München</span>
                                    <span><i class="fas fa-clock mr-1"></i>08:30 - 12:00</span>
                                    <span><i class="fas fa-calendar mr-1"></i>Heute</span>
                                </div>
                                <div class="flex items-center gap-4">
                                    <span class="text-sm text-gray-600"><i class="fas fa-user mr-1"></i>Zugewiesen: {user['name']}</span>
                                    <span class="text-sm text-gray-600"><i class="fas fa-tools mr-1"></i>Wartung</span>
                                </div>
                            </div>
                            <div class="flex flex-col gap-2 ml-4">
                                <button class="lackner-button px-4 py-2 rounded-lg text-sm">
                                    <i class="fas fa-map-marker-alt mr-1"></i>Navigation
                                </button>
                                <button class="lackner-secondary-button px-4 py-2 rounded-lg text-sm">
                                    <i class="fas fa-eye mr-1"></i>Details
                                </button>
                                <button class="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg text-sm">
                                    <i class="fas fa-check mr-1"></i>Erledigt
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Normaler Auftrag -->
                    <div class="auftrag-card bg-white rounded-lg shadow-md p-6 border-l-4 border-gray-400">
                        <div class="flex items-start justify-between">
                            <div class="flex-1">
                                <div class="flex items-center gap-2 mb-2">
                                    <span class="text-lg font-semibold text-gray-900">#AUF-2024-002</span>
                                    <span class="text-xs bg-gray-200 text-gray-800 px-2 py-1 rounded">Offen</span>
                                    <span class="text-xs bg-yellow-200 text-yellow-800 px-2 py-1 rounded">Mittel</span>
                                </div>
                                <h3 class="text-xl font-bold text-gray-900 mb-2">Sendlinger Tor - Regelmäßige Wartung</h3>
                                <p class="text-gray-600 mb-3">Jährliche Wartung und Inspektion des Aufzugs. Ölwechsel und Sicherheitsprüfung erforderlich.</p>
                                <div class="flex items-center gap-4 text-sm text-gray-500 mb-3">
                                    <span><i class="fas fa-map-marker-alt mr-1"></i>Sendlinger Tor, München</span>
                                    <span><i class="fas fa-clock mr-1"></i>09:15 - 15:30</span>
                                    <span><i class="fas fa-calendar mr-1"></i>Morgen</span>
                                </div>
                                <div class="flex items-center gap-4">
                                    <span class="text-sm text-gray-600"><i class="fas fa-user mr-1"></i>Zugewiesen: {user['name']}</span>
                                    <span class="text-sm text-gray-600"><i class="fas fa-tools mr-1"></i>Wartung</span>
                                </div>
                            </div>
                            <div class="flex flex-col gap-2 ml-4">
                                <button class="lackner-button px-4 py-2 rounded-lg text-sm">
                                    <i class="fas fa-map-marker-alt mr-1"></i>Navigation
                                </button>
                                <button class="lackner-secondary-button px-4 py-2 rounded-lg text-sm">
                                    <i class="fas fa-eye mr-1"></i>Details
                                </button>
                                <button class="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg text-sm">
                                    <i class="fas fa-check mr-1"></i>Erledigt
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Weitere Aufträge -->
                    <div class="auftrag-card bg-white rounded-lg shadow-md p-6 border-l-4 border-gray-400">
                        <div class="flex items-start justify-between">
                            <div class="flex-1">
                                <div class="flex items-center gap-2 mb-2">
                                    <span class="text-lg font-semibold text-gray-900">#AUF-2024-003</span>
                                    <span class="text-xs bg-gray-200 text-gray-800 px-2 py-1 rounded">Offen</span>
                                    <span class="text-xs bg-green-200 text-green-800 px-2 py-1 rounded">Niedrig</span>
                                </div>
                                <h3 class="text-xl font-bold text-gray-900 mb-2">Karlsplatz - Türschließer Reparatur</h3>
                                <p class="text-gray-600 mb-3">Türschließer defekt, muss ausgetauscht werden. Keine Dringlichkeit.</p>
                                <div class="flex items-center gap-4 text-sm text-gray-500 mb-3">
                                    <span><i class="fas fa-map-marker-alt mr-1"></i>Karlsplatz, München</span>
                                    <span><i class="fas fa-clock mr-1"></i>10:30 - 14:00</span>
                                    <span><i class="fas fa-calendar mr-1"></i>Übermorgen</span>
                                </div>
                                <div class="flex items-center gap-4">
                                    <span class="text-sm text-gray-600"><i class="fas fa-user mr-1"></i>Zugewiesen: {user['name']}</span>
                                    <span class="text-sm text-gray-600"><i class="fas fa-tools mr-1"></i>Reparatur</span>
                                </div>
                            </div>
                            <div class="flex flex-col gap-2 ml-4">
                                <button class="lackner-button px-4 py-2 rounded-lg text-sm">
                                    <i class="fas fa-map-marker-alt mr-1"></i>Navigation
                                </button>
                                <button class="lackner-secondary-button px-4 py-2 rounded-lg text-sm">
                                    <i class="fas fa-eye mr-1"></i>Details
                                </button>
                                <button class="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg text-sm">
                                    <i class="fas fa-check mr-1"></i>Erledigt
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Erledigter Auftrag -->
                    <div class="auftrag-card bg-white rounded-lg shadow-md p-6 border-l-4 border-gray-400 opacity-75">
                        <div class="flex items-start justify-between">
                            <div class="flex-1">
                                <div class="flex items-center gap-2 mb-2">
                                    <span class="text-lg font-semibold text-gray-900">#AUF-2024-004</span>
                                    <span class="text-xs bg-green-200 text-green-800 px-2 py-1 rounded">Erledigt</span>
                                    <span class="text-xs bg-gray-200 text-gray-800 px-2 py-1 rounded">Niedrig</span>
                                </div>
                                <h3 class="text-xl font-bold text-gray-900 mb-2">Marienplatz - Sicherheitsprüfung</h3>
                                <p class="text-gray-600 mb-3">Jährliche Sicherheitsprüfung erfolgreich abgeschlossen. Alle Systeme funktionieren einwandfrei.</p>
                                <div class="flex items-center gap-4 text-sm text-gray-500 mb-3">
                                    <span><i class="fas fa-map-marker-alt mr-1"></i>Marienplatz, München</span>
                                    <span><i class="fas fa-clock mr-1"></i>08:00 - 11:30</span>
                                    <span><i class="fas fa-calendar mr-1"></i>Gestern</span>
                                </div>
                                <div class="flex items-center gap-4">
                                    <span class="text-sm text-gray-600"><i class="fas fa-user mr-1"></i>Zugewiesen: {user['name']}</span>
                                    <span class="text-sm text-gray-600"><i class="fas fa-tools mr-1"></i>Inspektion</span>
                                </div>
                            </div>
                            <div class="flex flex-col gap-2 ml-4">
                                <button class="lackner-secondary-button px-4 py-2 rounded-lg text-sm">
                                    <i class="fas fa-eye mr-1"></i>Details
                                </button>
                                <button class="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg text-sm">
                                    <i class="fas fa-undo mr-1"></i>Wiedereröffnen
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Pagination -->
                <div class="flex items-center justify-between mt-8">
                    <div class="text-sm text-gray-600">
                        Zeige 1-4 von 12 Aufträgen
                    </div>
                    <div class="flex gap-2">
                        <button class="px-3 py-2 text-gray-500 hover:text-gray-700 disabled:opacity-50">
                            <i class="fas fa-chevron-left"></i>
                        </button>
                        <button class="px-3 py-2 bg-blue-600 text-white rounded">1</button>
                        <button class="px-3 py-2 text-gray-600 hover:bg-gray-100 rounded">2</button>
                        <button class="px-3 py-2 text-gray-600 hover:bg-gray-100 rounded">3</button>
                        <button class="px-3 py-2 text-gray-500 hover:text-gray-700">
                            <i class="fas fa-chevron-right"></i>
                        </button>
                    </div>
                </div>
            </main>
        </div>

        <script>
            // Mobile Menu
            const mobileMenuBtn = document.getElementById('mobile-menu-btn');
            const mobileMenu = document.getElementById('mobile-menu');
            const mobileOverlay = document.getElementById('mobile-overlay');
            const closeMobileMenu = document.getElementById('close-mobile-menu');

            function openMobileMenu() {{
                mobileMenu.classList.add('open');
                mobileOverlay.classList.remove('hidden');
                document.body.style.overflow = 'hidden';
            }}

            function closeMobileMenuFunc() {{
                mobileMenu.classList.remove('open');
                mobileOverlay.classList.add('hidden');
                document.body.style.overflow = '';
            }}

            mobileMenuBtn.addEventListener('click', openMobileMenu);
            closeMobileMenu.addEventListener('click', closeMobileMenuFunc);
            mobileOverlay.addEventListener('click', closeMobileMenuFunc);

            // User Menu
            document.getElementById('user-menu-btn').addEventListener('click', function() {{
                const dropdown = document.getElementById('user-dropdown');
                dropdown.classList.toggle('hidden');
            }});

            // Click outside to close dropdowns
            document.addEventListener('click', function(event) {{
                if (!event.target.closest('.relative')) {{
                    document.getElementById('user-dropdown').classList.add('hidden');
                }}
            }});
        </script>
    </body>
    </html>
    """

# Initialize database
init_db()

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000) 