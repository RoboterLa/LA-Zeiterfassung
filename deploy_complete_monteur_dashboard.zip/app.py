from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from flask_cors import CORS
from functools import wraps
import os
import logging
from datetime import datetime

logging.basicConfig(level=logging.DEBUG)

print("🚀 App wird gestartet...")

app = Flask(__name__)
app.secret_key = os.getenv('FLASK_SECRET_KEY', 'default_secret_key')

# Azure-kompatible Session-Konfiguration
os.makedirs('/tmp/sessions', exist_ok=True)

# CORS für Frontend-Kommunikation - erweitert für Azure
CORS(app, 
     supports_credentials=True, 
     origins=[
         'http://localhost:3000',
         'https://localhost:3000', 
         'http://192.168.50.99:3000',
         'http://localhost:3001',
         'https://localhost:3001',
         'http://192.168.50.99:3001',
         'https://la-zeiterfassung-fyd4cge3d9e3cac4.azurewebsites.net',
         'http://la-zeiterfassung-fyd4cge3d9e3cac4.azurewebsites.net',
         '*'
     ],
     allow_headers=['Content-Type', 'Authorization'],
     methods=['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'])

# Test-User (in Produktion: Datenbank)
TEST_USERS = {
    'monteur@test.com': {
        'password': 'test123',
        'name': 'Monteur Test',
        'role': 'Monteur'
    },
    'admin@test.com': {
        'password': 'test123',
        'name': 'Admin Test',
        'role': 'Admin'
    }
}

# Role-Decorator
def requires_role(role):
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            if 'user' not in session or session['user'].get('role') != role:
                flash('Zugriff verweigert.')
                return redirect('/login')
            return f(*args, **kwargs)
        return decorated
    return decorator

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        app.logger.debug(f"Login attempt: {email}")
        
        if email in TEST_USERS and TEST_USERS[email]['password'] == password:
            user_data = TEST_USERS[email]
            session['user'] = {
                'email': email,
                'name': user_data['name'],
                'role': user_data['role']
            }
            app.logger.debug(f"User logged in: {session['user']}")
            
            if user_data['role'] == 'Admin':
                return redirect('/buero')
            return redirect('/')
        flash('Ungültige Anmeldedaten')
    
    # Einfache HTML-Ausgabe statt render_template_string
    return """
    <!DOCTYPE html>
    <html lang="de">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Anmeldung - Zeiterfassung System</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                background-color: #f5f5f5;
                margin: 0;
                padding: 20px;
                display: flex;
                justify-content: center;
                align-items: center;
                min-height: 100vh;
            }
            .login-container {
                background: white;
                padding: 40px;
                border-radius: 10px;
                box-shadow: 0 4px 20px rgba(0,0,0,0.1);
                width: 100%;
                max-width: 400px;
            }
            .header {
                text-align: center;
                margin-bottom: 30px;
            }
            .form-group {
                margin-bottom: 20px;
            }
            label {
                display: block;
                margin-bottom: 5px;
                font-weight: bold;
                color: #333;
            }
            input[type="email"], input[type="password"] {
                width: 100%;
                padding: 12px;
                border: 2px solid #ddd;
                border-radius: 5px;
                font-size: 16px;
                box-sizing: border-box;
            }
            input[type="email"]:focus, input[type="password"]:focus {
                border-color: #0066b3;
                outline: none;
            }
            .login-btn {
                width: 100%;
                background: #0066b3;
                color: white;
                padding: 12px;
                border: none;
                border-radius: 5px;
                font-size: 16px;
                cursor: pointer;
                margin-top: 10px;
            }
            .login-btn:hover {
                background: #0052a3;
            }
            .demo-info {
                background: #e3f2fd;
                padding: 15px;
                border-radius: 5px;
                margin-top: 20px;
                font-size: 14px;
            }
        </style>
    </head>
    <body>
        <div class="login-container">
            <div class="header">
                <h1>🚀 Zeiterfassung System</h1>
                <h2>Lackner Aufzüge</h2>
            </div>
            
            <form method="POST" action="/login">
                <div class="form-group">
                    <label for="email">E-Mail:</label>
                    <input type="email" id="email" name="email" required>
                </div>
                
                <div class="form-group">
                    <label for="password">Passwort:</label>
                    <input type="password" id="password" name="password" required>
                </div>
                
                <button type="submit" class="login-btn">🔐 Anmelden</button>
            </form>
            
            <div class="demo-info">
                <h4>📋 Test-Anmeldedaten:</h4>
                <p><strong>Monteur:</strong><br>
                E-Mail: monteur@test.com<br>
                Passwort: test123</p>
                
                <p><strong>Administrator:</strong><br>
                E-Mail: admin@test.com<br>
                Passwort: test123</p>
            </div>
        </div>
    </body>
    </html>
    """

@app.route('/logout')
def logout():
    app.logger.debug(f"Logout: {session.get('user')}")
    session.clear()
    session.modified = True
    
    # Response mit explizitem Cookie-Löschen
    response = redirect('/login')
    response.delete_cookie('session', domain='.azurewebsites.net')
    response.delete_cookie('session', domain='la-zeiterfassung-fyd4cge3d9e3cac4.azurewebsites.net')
    response.delete_cookie('session')  # Ohne Domain
    return response

@app.route('/')
def index():
    app.logger.debug(f"Index route - Session: {session}")
    if 'user' not in session:
        return redirect('/login')
    if session['user'].get('role') == 'Admin':
        return redirect('/buero')
    # Monteur-Frontend - Vollständiges Dashboard mit allen Features
    user = session['user']
    today = datetime.now().strftime('%Y-%m-%d')
    return f"""
    <!DOCTYPE html>
    <html lang="de">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Monteur Dashboard - Zeiterfassung System</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
        <script>
            tailwind.config = {{
                theme: {{
                    extend: {{
                        colors: {{
                            primary: '#0066b3',
                            secondary: '#f8fafc'
                        }}
                    }}
                }}
            }}
        </script>
    </head>
    <body class="bg-gray-50">
        <!-- Header -->
        <header class="bg-blue-600 text-white shadow-lg">
            <div class="container mx-auto px-4 py-3">
                <div class="flex justify-between items-center">
                    <div class="flex items-center space-x-4">
                        <i class="fas fa-clock text-2xl"></i>
                        <h1 class="text-xl font-bold">Zeiterfassung System</h1>
                    </div>
                    <div class="flex items-center space-x-4">
                        <span class="text-sm">Willkommen, {user['name']}</span>
                        <a href="/logout" class="bg-red-500 hover:bg-red-600 px-3 py-1 rounded text-sm">
                            <i class="fas fa-sign-out-alt mr-1"></i>Abmelden
                        </a>
                    </div>
                </div>
            </div>
        </header>

        <!-- Navigation -->
        <nav class="bg-white shadow-sm border-b">
            <div class="container mx-auto px-4">
                <div class="flex space-x-8 py-3">
                    <a href="/" class="text-blue-600 font-semibold border-b-2 border-blue-600 pb-2">
                        <i class="fas fa-home mr-2"></i>Dashboard
                    </a>
                    <a href="/zeiterfassung" class="text-gray-600 hover:text-blue-600">
                        <i class="fas fa-stopwatch mr-2"></i>Zeiterfassung
                    </a>
                    <a href="/arbeitszeit" class="text-gray-600 hover:text-blue-600">
                        <i class="fas fa-clock mr-2"></i>Arbeitszeit
                    </a>
                    <a href="/meine-auftraege" class="text-gray-600 hover:text-blue-600">
                        <i class="fas fa-tasks mr-2"></i>Meine Aufträge
                    </a>
                    <a href="/urlaub" class="text-gray-600 hover:text-blue-600">
                        <i class="fas fa-umbrella-beach mr-2"></i>Urlaub
                    </a>
                </div>
            </div>
        </nav>

        <!-- Main Content -->
        <main class="container mx-auto px-4 py-6">
            <!-- Dashboard Grid -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                
                <!-- Zeiterfassung Timer -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h2 class="text-lg font-semibold mb-4 text-gray-800">
                        <i class="fas fa-stopwatch mr-2 text-blue-600"></i>Zeiterfassung
                    </h2>
                    <div class="text-center">
                        <div class="text-3xl font-bold text-gray-700 mb-2" id="timer">00:00:00</div>
                        <div class="space-y-2">
                            <button onclick="startTimer()" class="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded w-full">
                                <i class="fas fa-play mr-1"></i>Arbeitszeit starten
                            </button>
                            <button onclick="stopTimer()" class="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded w-full">
                                <i class="fas fa-stop mr-1"></i>Arbeitszeit stoppen
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Wetter Widget -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h2 class="text-lg font-semibold mb-4 text-gray-800">
                        <i class="fas fa-cloud-sun mr-2 text-yellow-500"></i>Wetter
                    </h2>
                    <div class="text-center">
                        <div class="text-4xl mb-2">☀️</div>
                        <div class="text-2xl font-bold text-gray-700">22°C</div>
                        <div class="text-gray-600">Sonnig, Wien</div>
                        <div class="text-sm text-gray-500 mt-2">Perfekt für Außeneinsätze</div>
                    </div>
                </div>

                <!-- Schnellzugriff -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h2 class="text-lg font-semibold mb-4 text-gray-800">
                        <i class="fas fa-bolt mr-2 text-orange-500"></i>Schnellzugriff
                    </h2>
                    <div class="space-y-3">
                        <a href="/meine-auftraege" class="block bg-blue-50 hover:bg-blue-100 p-3 rounded border-l-4 border-blue-500">
                            <i class="fas fa-tasks mr-2 text-blue-600"></i>Meine Aufträge
                        </a>
                        <a href="/zeiterfassung" class="block bg-green-50 hover:bg-green-100 p-3 rounded border-l-4 border-green-500">
                            <i class="fas fa-stopwatch mr-2 text-green-600"></i>Zeiterfassung
                        </a>
                        <a href="/arbeitszeit" class="block bg-purple-50 hover:bg-purple-100 p-3 rounded border-l-4 border-purple-500">
                            <i class="fas fa-clock mr-2 text-purple-600"></i>Arbeitszeit
                        </a>
                    </div>
                </div>

                <!-- Heute -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h2 class="text-lg font-semibold mb-4 text-gray-800">
                        <i class="fas fa-calendar-day mr-2 text-green-600"></i>Heute ({today})
                    </h2>
                    <div class="space-y-3">
                        <div class="flex justify-between items-center p-2 bg-gray-50 rounded">
                            <span class="text-sm text-gray-600">Arbeitszeit:</span>
                            <span class="font-semibold text-gray-800">7h 30m</span>
                        </div>
                        <div class="flex justify-between items-center p-2 bg-gray-50 rounded">
                            <span class="text-sm text-gray-600">Aufträge:</span>
                            <span class="font-semibold text-gray-800">3</span>
                        </div>
                        <div class="flex justify-between items-center p-2 bg-gray-50 rounded">
                            <span class="text-sm text-gray-600">Status:</span>
                            <span class="bg-green-100 text-green-800 px-2 py-1 rounded text-xs">Aktiv</span>
                        </div>
                    </div>
                </div>

                <!-- Letzte Aktivitäten -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h2 class="text-lg font-semibold mb-4 text-gray-800">
                        <i class="fas fa-history mr-2 text-gray-600"></i>Aktivitäten
                    </h2>
                    <div class="space-y-2">
                        <div class="flex items-center text-sm">
                            <i class="fas fa-play text-green-500 mr-2"></i>
                            <span>Arbeitszeit gestartet - 08:00</span>
                        </div>
                        <div class="flex items-center text-sm">
                            <i class="fas fa-tools text-blue-500 mr-2"></i>
                            <span>Auftrag #1234 bearbeitet</span>
                        </div>
                        <div class="flex items-center text-sm">
                            <i class="fas fa-check text-green-500 mr-2"></i>
                            <span>Auftrag #1235 abgeschlossen</span>
                        </div>
                    </div>
                </div>

                <!-- Statistiken -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h2 class="text-lg font-semibold mb-4 text-gray-800">
                        <i class="fas fa-chart-bar mr-2 text-purple-600"></i>Diese Woche
                    </h2>
                    <div class="space-y-3">
                        <div class="flex justify-between items-center">
                            <span class="text-sm text-gray-600">Arbeitsstunden:</span>
                            <span class="font-semibold text-gray-800">37.5h</span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-sm text-gray-600">Aufträge:</span>
                            <span class="font-semibold text-gray-800">12</span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-sm text-gray-600">Durchschnitt:</span>
                            <span class="font-semibold text-gray-800">7.5h/Tag</span>
                        </div>
                    </div>
                </div>
            </div>
        </main>

        <script>
            // Timer Funktionalität
            let timer = 0;
            let timerInterval;
            let isRunning = false;
            
            function updateTimer() {{
                const hours = Math.floor(timer / 3600);
                const minutes = Math.floor((timer % 3600) / 60);
                const seconds = timer % 60;
                
                document.getElementById('timer').textContent = 
                    `${{hours.toString().padStart(2, '0')}}:${{minutes.toString().padStart(2, '0')}}:${{seconds.toString().padStart(2, '0')}}`;
            }}
            
            function startTimer() {{
                if (!isRunning) {{
                    isRunning = true;
                    timerInterval = setInterval(() => {{
                        timer++;
                        updateTimer();
                    }}, 1000);
                }}
            }}
            
            function stopTimer() {{
                if (isRunning) {{
                    isRunning = false;
                    clearInterval(timerInterval);
                }}
            }}
        </script>
    </body>
    </html>
    """

@app.route('/zeiterfassung')
def zeiterfassung():
    if 'user' not in session:
        return redirect('/login')
    if session['user'].get('role') == 'Admin':
        return redirect('/buero')
    
    user = session['user']
    return f"""
    <!DOCTYPE html>
    <html lang="de">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Zeiterfassung - Monteur Dashboard</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    </head>
    <body class="bg-gray-50">
        <!-- Header -->
        <header class="bg-blue-600 text-white shadow-lg">
            <div class="container mx-auto px-4 py-3">
                <div class="flex justify-between items-center">
                    <div class="flex items-center space-x-4">
                        <i class="fas fa-stopwatch text-2xl"></i>
                        <h1 class="text-xl font-bold">Zeiterfassung</h1>
                    </div>
                    <div class="flex items-center space-x-4">
                        <span class="text-sm">Willkommen, {user['name']}</span>
                        <a href="/logout" class="bg-red-500 hover:bg-red-600 px-3 py-1 rounded text-sm">
                            <i class="fas fa-sign-out-alt mr-1"></i>Abmelden
                        </a>
                    </div>
                </div>
            </div>
        </header>

        <!-- Navigation -->
        <nav class="bg-white shadow-sm border-b">
            <div class="container mx-auto px-4">
                <div class="flex space-x-8 py-3">
                    <a href="/" class="text-gray-600 hover:text-blue-600">
                        <i class="fas fa-home mr-2"></i>Dashboard
                    </a>
                    <a href="/zeiterfassung" class="text-blue-600 font-semibold border-b-2 border-blue-600 pb-2">
                        <i class="fas fa-stopwatch mr-2"></i>Zeiterfassung
                    </a>
                    <a href="/arbeitszeit" class="text-gray-600 hover:text-blue-600">
                        <i class="fas fa-clock mr-2"></i>Arbeitszeit
                    </a>
                    <a href="/meine-auftraege" class="text-gray-600 hover:text-blue-600">
                        <i class="fas fa-tasks mr-2"></i>Meine Aufträge
                    </a>
                    <a href="/urlaub" class="text-gray-600 hover:text-blue-600">
                        <i class="fas fa-umbrella-beach mr-2"></i>Urlaub
                    </a>
                </div>
            </div>
        </nav>

        <!-- Main Content -->
        <main class="container mx-auto px-4 py-6">
            <div class="bg-white rounded-lg shadow-md p-6">
                <h2 class="text-2xl font-bold mb-6 text-gray-800">
                    <i class="fas fa-stopwatch mr-2 text-blue-600"></i>Zeiterfassung
                </h2>
                
                <!-- Zeiterfassung Form -->
                <form class="space-y-6">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Aktivitätstyp</label>
                            <select class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                                <option value="maintenance">⚙️ Wartung</option>
                                <option value="repairs">🔧 Reparatur</option>
                                <option value="fixedprice">💼 Festpreis</option>
                                <option value="emergency">🚨 Notdienst</option>
                                <option value="office">🏢 Büro</option>
                                <option value="sick">🏥 Krank</option>
                                <option value="vacation">🏖️ Urlaub</option>
                                <option value="holiday">🎉 Feiertag</option>
                                <option value="overtime">⏰ Überstunden</option>
                                <option value="other">📋 Sonstige</option>
                            </select>
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Datum</label>
                            <input type="date" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" value="{datetime.now().strftime('%Y-%m-%d')}">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Startzeit</label>
                            <input type="time" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Endzeit</label>
                            <input type="time" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                        </div>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Bemerkungen</label>
                        <textarea rows="3" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" placeholder="Details zur Tätigkeit..."></textarea>
                    </div>
                    
                    <div class="flex justify-end space-x-4">
                        <button type="button" class="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50">
                            Abbrechen
                        </button>
                        <button type="submit" class="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                            <i class="fas fa-save mr-2"></i>Speichern
                        </button>
                    </div>
                </form>
            </div>
        </main>
    </body>
    </html>
    """

@app.route('/arbeitszeit')
def arbeitszeit():
    if 'user' not in session:
        return redirect('/login')
    if session['user'].get('role') == 'Admin':
        return redirect('/buero')
    
    user = session['user']
    return f"""
    <!DOCTYPE html>
    <html lang="de">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Arbeitszeit - Monteur Dashboard</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    </head>
    <body class="bg-gray-50">
        <!-- Header -->
        <header class="bg-blue-600 text-white shadow-lg">
            <div class="container mx-auto px-4 py-3">
                <div class="flex justify-between items-center">
                    <div class="flex items-center space-x-4">
                        <i class="fas fa-clock text-2xl"></i>
                        <h1 class="text-xl font-bold">Arbeitszeit</h1>
                    </div>
                    <div class="flex items-center space-x-4">
                        <span class="text-sm">Willkommen, {user['name']}</span>
                        <a href="/logout" class="bg-red-500 hover:bg-red-600 px-3 py-1 rounded text-sm">
                            <i class="fas fa-sign-out-alt mr-1"></i>Abmelden
                        </a>
                    </div>
                </div>
            </div>
        </header>

        <!-- Navigation -->
        <nav class="bg-white shadow-sm border-b">
            <div class="container mx-auto px-4">
                <div class="flex space-x-8 py-3">
                    <a href="/" class="text-gray-600 hover:text-blue-600">
                        <i class="fas fa-home mr-2"></i>Dashboard
                    </a>
                    <a href="/zeiterfassung" class="text-gray-600 hover:text-blue-600">
                        <i class="fas fa-stopwatch mr-2"></i>Zeiterfassung
                    </a>
                    <a href="/arbeitszeit" class="text-blue-600 font-semibold border-b-2 border-blue-600 pb-2">
                        <i class="fas fa-clock mr-2"></i>Arbeitszeit
                    </a>
                    <a href="/meine-auftraege" class="text-gray-600 hover:text-blue-600">
                        <i class="fas fa-tasks mr-2"></i>Meine Aufträge
                    </a>
                    <a href="/urlaub" class="text-gray-600 hover:text-blue-600">
                        <i class="fas fa-umbrella-beach mr-2"></i>Urlaub
                    </a>
                </div>
            </div>
        </nav>

        <!-- Main Content -->
        <main class="container mx-auto px-4 py-6">
            <div class="bg-white rounded-lg shadow-md p-6">
                <h2 class="text-2xl font-bold mb-6 text-gray-800">
                    <i class="fas fa-clock mr-2 text-blue-600"></i>Arbeitszeit Übersicht
                </h2>
                
                <!-- Statistiken -->
                <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                    <div class="bg-blue-50 p-4 rounded-lg">
                        <div class="text-2xl font-bold text-blue-600">37.5h</div>
                        <div class="text-sm text-gray-600">Diese Woche</div>
                    </div>
                    <div class="bg-green-50 p-4 rounded-lg">
                        <div class="text-2xl font-bold text-green-600">7.5h</div>
                        <div class="text-sm text-gray-600">Durchschnitt/Tag</div>
                    </div>
                    <div class="bg-yellow-50 p-4 rounded-lg">
                        <div class="text-2xl font-bold text-yellow-600">2.5h</div>
                        <div class="text-sm text-gray-600">Überstunden</div>
                    </div>
                    <div class="bg-purple-50 p-4 rounded-lg">
                        <div class="text-2xl font-bold text-purple-600">5</div>
                        <div class="text-sm text-gray-600">Arbeitstage</div>
                    </div>
                </div>
                
                <!-- Arbeitszeit Tabelle -->
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Datum</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Start</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ende</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Dauer</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <tr>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">2025-07-29</td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">08:00</td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">17:00</td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">9h</td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                        Abgeschlossen
                                    </span>
                                </td>
                            </tr>
                            <tr>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">2025-07-28</td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">08:30</td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">16:30</td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">8h</td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                        Abgeschlossen
                                    </span>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </body>
    </html>
    """

@app.route('/meine-auftraege')
def meine_auftraege():
    if 'user' not in session:
        return redirect('/login')
    if session['user'].get('role') == 'Admin':
        return redirect('/buero')
    
    user = session['user']
    return f"""
    <!DOCTYPE html>
    <html lang="de">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Meine Aufträge - Monteur Dashboard</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    </head>
    <body class="bg-gray-50">
        <!-- Header -->
        <header class="bg-blue-600 text-white shadow-lg">
            <div class="container mx-auto px-4 py-3">
                <div class="flex justify-between items-center">
                    <div class="flex items-center space-x-4">
                        <i class="fas fa-tasks text-2xl"></i>
                        <h1 class="text-xl font-bold">Meine Aufträge</h1>
                    </div>
                    <div class="flex items-center space-x-4">
                        <span class="text-sm">Willkommen, {user['name']}</span>
                        <a href="/logout" class="bg-red-500 hover:bg-red-600 px-3 py-1 rounded text-sm">
                            <i class="fas fa-sign-out-alt mr-1"></i>Abmelden
                        </a>
                    </div>
                </div>
            </div>
        </header>

        <!-- Navigation -->
        <nav class="bg-white shadow-sm border-b">
            <div class="container mx-auto px-4">
                <div class="flex space-x-8 py-3">
                    <a href="/" class="text-gray-600 hover:text-blue-600">
                        <i class="fas fa-home mr-2"></i>Dashboard
                    </a>
                    <a href="/zeiterfassung" class="text-gray-600 hover:text-blue-600">
                        <i class="fas fa-stopwatch mr-2"></i>Zeiterfassung
                    </a>
                    <a href="/arbeitszeit" class="text-gray-600 hover:text-blue-600">
                        <i class="fas fa-clock mr-2"></i>Arbeitszeit
                    </a>
                    <a href="/meine-auftraege" class="text-blue-600 font-semibold border-b-2 border-blue-600 pb-2">
                        <i class="fas fa-tasks mr-2"></i>Meine Aufträge
                    </a>
                    <a href="/urlaub" class="text-gray-600 hover:text-blue-600">
                        <i class="fas fa-umbrella-beach mr-2"></i>Urlaub
                    </a>
                </div>
            </div>
        </nav>

        <!-- Main Content -->
        <main class="container mx-auto px-4 py-6">
            <div class="bg-white rounded-lg shadow-md p-6">
                <h2 class="text-2xl font-bold mb-6 text-gray-800">
                    <i class="fas fa-tasks mr-2 text-blue-600"></i>Meine Aufträge
                </h2>
                
                <!-- Aufträge Grid -->
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <!-- Auftrag 1 -->
                    <div class="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                        <div class="flex justify-between items-start mb-3">
                            <h3 class="font-semibold text-gray-900">Reparatur Aufzug</h3>
                            <span class="px-2 py-1 text-xs font-semibold rounded-full bg-yellow-100 text-yellow-800">
                                In Bearbeitung
                            </span>
                        </div>
                        <p class="text-sm text-gray-600 mb-3">Hauptbahnhof, München - Aufzug klemmt, Notruf ausgelöst</p>
                        <div class="flex justify-between items-center text-sm text-gray-500">
                            <span>Heute, 14:00</span>
                            <span class="text-blue-600 font-medium">Priorität: Hoch</span>
                        </div>
                    </div>
                    
                    <!-- Auftrag 2 -->
                    <div class="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                        <div class="flex justify-between items-start mb-3">
                            <h3 class="font-semibold text-gray-900">Wartung Aufzug</h3>
                            <span class="px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">
                                Abgeschlossen
                            </span>
                        </div>
                        <p class="text-sm text-gray-600 mb-3">Bürogebäude, Wien - Regelmäßige Wartung</p>
                        <div class="flex justify-between items-center text-sm text-gray-500">
                            <span>Gestern, 10:00</span>
                            <span class="text-green-600 font-medium">Priorität: Normal</span>
                        </div>
                    </div>
                    
                    <!-- Auftrag 3 -->
                    <div class="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                        <div class="flex justify-between items-start mb-3">
                            <h3 class="font-semibold text-gray-900">Notdienst</h3>
                            <span class="px-2 py-1 text-xs font-semibold rounded-full bg-red-100 text-red-800">
                                Dringend
                            </span>
                        </div>
                        <p class="text-sm text-gray-600 mb-3">Krankenhaus, Salzburg - Aufzug steckt fest</p>
                        <div class="flex justify-between items-center text-sm text-gray-500">
                            <span>Morgen, 09:00</span>
                            <span class="text-red-600 font-medium">Priorität: Kritisch</span>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </body>
    </html>
    """

@app.route('/urlaub')
def urlaub():
    if 'user' not in session:
        return redirect('/login')
    if session['user'].get('role') == 'Admin':
        return redirect('/buero')
    
    user = session['user']
    return f"""
    <!DOCTYPE html>
    <html lang="de">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Urlaub - Monteur Dashboard</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    </head>
    <body class="bg-gray-50">
        <!-- Header -->
        <header class="bg-blue-600 text-white shadow-lg">
            <div class="container mx-auto px-4 py-3">
                <div class="flex justify-between items-center">
                    <div class="flex items-center space-x-4">
                        <i class="fas fa-umbrella-beach text-2xl"></i>
                        <h1 class="text-xl font-bold">Urlaub</h1>
                    </div>
                    <div class="flex items-center space-x-4">
                        <span class="text-sm">Willkommen, {user['name']}</span>
                        <a href="/logout" class="bg-red-500 hover:bg-red-600 px-3 py-1 rounded text-sm">
                            <i class="fas fa-sign-out-alt mr-1"></i>Abmelden
                        </a>
                    </div>
                </div>
            </div>
        </header>

        <!-- Navigation -->
        <nav class="bg-white shadow-sm border-b">
            <div class="container mx-auto px-4">
                <div class="flex space-x-8 py-3">
                    <a href="/" class="text-gray-600 hover:text-blue-600">
                        <i class="fas fa-home mr-2"></i>Dashboard
                    </a>
                    <a href="/zeiterfassung" class="text-gray-600 hover:text-blue-600">
                        <i class="fas fa-stopwatch mr-2"></i>Zeiterfassung
                    </a>
                    <a href="/arbeitszeit" class="text-gray-600 hover:text-blue-600">
                        <i class="fas fa-clock mr-2"></i>Arbeitszeit
                    </a>
                    <a href="/meine-auftraege" class="text-gray-600 hover:text-blue-600">
                        <i class="fas fa-tasks mr-2"></i>Meine Aufträge
                    </a>
                    <a href="/urlaub" class="text-blue-600 font-semibold border-b-2 border-blue-600 pb-2">
                        <i class="fas fa-umbrella-beach mr-2"></i>Urlaub
                    </a>
                </div>
            </div>
        </nav>

        <!-- Main Content -->
        <main class="container mx-auto px-4 py-6">
            <div class="bg-white rounded-lg shadow-md p-6">
                <h2 class="text-2xl font-bold mb-6 text-gray-800">
                    <i class="fas fa-umbrella-beach mr-2 text-blue-600"></i>Urlaub & Feiertage
                </h2>
                
                <!-- Urlaub Statistiken -->
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                    <div class="bg-blue-50 p-4 rounded-lg">
                        <div class="text-2xl font-bold text-blue-600">25</div>
                        <div class="text-sm text-gray-600">Verfügbare Tage</div>
                    </div>
                    <div class="bg-green-50 p-4 rounded-lg">
                        <div class="text-2xl font-bold text-green-600">15</div>
                        <div class="text-sm text-gray-600">Genommene Tage</div>
                    </div>
                    <div class="bg-yellow-50 p-4 rounded-lg">
                        <div class="text-2xl font-bold text-yellow-600">10</div>
                        <div class="text-sm text-gray-600">Verbleibende Tage</div>
                    </div>
                </div>
                
                <!-- Urlaub Antrag -->
                <div class="border border-gray-200 rounded-lg p-6 mb-6">
                    <h3 class="text-lg font-semibold mb-4 text-gray-800">Neuer Urlaubsantrag</h3>
                    <form class="space-y-4">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Von</label>
                                <input type="date" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Bis</label>
                                <input type="date" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                            </div>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Grund</label>
                            <textarea rows="3" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500" placeholder="Urlaubsgrund..."></textarea>
                        </div>
                        <div class="flex justify-end">
                            <button type="submit" class="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                                <i class="fas fa-paper-plane mr-2"></i>Antrag einreichen
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </main>
    </body>
    </html>
    """

@app.route('/buero')
@requires_role('Admin')
def buero():
    # Büro-Frontend - Direkt in Azure bereitstellen
    user = session['user']
    return f"""
    <!DOCTYPE html>
    <html lang="de">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Büro Interface - Zeiterfassung System</title>
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    </head>
    <body class="bg-gray-100">
        <!-- Header -->
        <header class="bg-blue-600 text-white shadow-lg">
            <div class="container mx-auto px-4 py-3">
                <div class="flex justify-between items-center">
                    <div class="flex items-center space-x-4">
                        <i class="fas fa-building text-2xl"></i>
                        <h1 class="text-xl font-bold">Büro Interface</h1>
                    </div>
                    <div class="flex items-center space-x-4">
                        <span class="text-sm">Administrator: {user['name']}</span>
                        <a href="/logout" class="bg-red-500 hover:bg-red-600 px-3 py-1 rounded text-sm">
                            <i class="fas fa-sign-out-alt mr-1"></i>Abmelden
                        </a>
                    </div>
                </div>
            </div>
        </header>

        <!-- Main Content -->
        <main class="container mx-auto px-4 py-6">
            <!-- Dashboard Grid -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                
                <!-- Mitarbeiter Übersicht -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h2 class="text-lg font-semibold mb-4 text-gray-800">
                        <i class="fas fa-users mr-2 text-blue-600"></i>Mitarbeiter
                    </h2>
                    <div class="space-y-3">
                        <div class="flex justify-between items-center p-2 bg-green-50 rounded">
                            <span class="text-sm">Aktive Monteure:</span>
                            <span class="font-semibold text-green-800">8</span>
                        </div>
                        <div class="flex justify-between items-center p-2 bg-yellow-50 rounded">
                            <span class="text-sm">Im Einsatz:</span>
                            <span class="font-semibold text-yellow-800">6</span>
                        </div>
                        <div class="flex justify-between items-center p-2 bg-red-50 rounded">
                            <span class="text-sm">Pause:</span>
                            <span class="font-semibold text-red-800">2</span>
                        </div>
                    </div>
                </div>

                <!-- Aufträge Verwaltung -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h2 class="text-lg font-semibold mb-4 text-gray-800">
                        <i class="fas fa-clipboard-list mr-2 text-green-600"></i>Aufträge
                    </h2>
                    <div class="space-y-3">
                        <div class="flex justify-between items-center p-2 bg-blue-50 rounded">
                            <span class="text-sm">Offen:</span>
                            <span class="font-semibold text-blue-800">15</span>
                        </div>
                        <div class="flex justify-between items-center p-2 bg-orange-50 rounded">
                            <span class="text-sm">In Bearbeitung:</span>
                            <span class="font-semibold text-orange-800">8</span>
                        </div>
                        <div class="flex justify-between items-center p-2 bg-green-50 rounded">
                            <span class="text-sm">Abgeschlossen:</span>
                            <span class="font-semibold text-green-800">12</span>
                        </div>
                    </div>
                </div>

                <!-- Schnellaktionen -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h2 class="text-lg font-semibold mb-4 text-gray-800">
                        <i class="fas fa-bolt mr-2 text-orange-500"></i>Schnellaktionen
                    </h2>
                    <div class="space-y-3">
                        <button class="w-full bg-blue-500 hover:bg-blue-600 text-white p-3 rounded">
                            <i class="fas fa-plus mr-2"></i>Neuen Auftrag erstellen
                        </button>
                        <button class="w-full bg-green-500 hover:bg-green-600 text-white p-3 rounded">
                            <i class="fas fa-user-plus mr-2"></i>Mitarbeiter hinzufügen
                        </button>
                        <button class="w-full bg-purple-500 hover:bg-purple-600 text-white p-3 rounded">
                            <i class="fas fa-chart-line mr-2"></i>Berichte generieren
                        </button>
                    </div>
                </div>

                <!-- Zeiterfassung Genehmigung -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h2 class="text-lg font-semibold mb-4 text-gray-800">
                        <i class="fas fa-clock mr-2 text-yellow-600"></i>Genehmigungen
                    </h2>
                    <div class="space-y-3">
                        <div class="flex justify-between items-center p-2 bg-yellow-50 rounded">
                            <span class="text-sm">Ausstehend:</span>
                            <span class="font-semibold text-yellow-800">5</span>
                        </div>
                        <div class="flex justify-between items-center p-2 bg-green-50 rounded">
                            <span class="text-sm">Genehmigt:</span>
                            <span class="font-semibold text-green-800">23</span>
                        </div>
                        <div class="flex justify-between items-center p-2 bg-red-50 rounded">
                            <span class="text-sm">Abgelehnt:</span>
                            <span class="font-semibold text-red-800">2</span>
                        </div>
                    </div>
                </div>

                <!-- Statistiken -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h2 class="text-lg font-semibold mb-4 text-gray-800">
                        <i class="fas fa-chart-bar mr-2 text-purple-600"></i>Statistiken
                    </h2>
                    <div class="space-y-3">
                        <div class="flex justify-between items-center">
                            <span class="text-sm text-gray-600">Durchschnittliche Arbeitszeit:</span>
                            <span class="font-semibold text-gray-800">7.8h</span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-sm text-gray-600">Aufträge pro Tag:</span>
                            <span class="font-semibold text-gray-800">4.2</span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-sm text-gray-600">Effizienz:</span>
                            <span class="font-semibold text-gray-800">94%</span>
                        </div>
                    </div>
                </div>

                <!-- Letzte Aktivitäten -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h2 class="text-lg font-semibold mb-4 text-gray-800">
                        <i class="fas fa-history mr-2 text-gray-600"></i>Aktivitäten
                    </h2>
                    <div class="space-y-2">
                        <div class="flex items-center text-sm">
                            <i class="fas fa-user text-blue-500 mr-2"></i>
                            <span>Monteur Müller hat Arbeitszeit gestartet</span>
                        </div>
                        <div class="flex items-center text-sm">
                            <i class="fas fa-check text-green-500 mr-2"></i>
                            <span>Auftrag #1234 wurde genehmigt</span>
                        </div>
                        <div class="flex items-center text-sm">
                            <i class="fas fa-plus text-purple-500 mr-2"></i>
                            <span>Neuer Auftrag #1235 erstellt</span>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </body>
    </html>
    """

@app.route('/api/status')
def api_status():
    user = session.get('user', None)
    app.logger.debug(f"API Status - Session user: {user}")
    
    # Konvertiere User-Daten in das Format, das das Frontend erwartet
    if user:
        frontend_user = {
            'id': str(user.get('id', '1')),
            'name': user.get('name', 'Unknown'),
            'email': user.get('email', ''),
            'role': user.get('role', 'Monteur'),
            'is_admin': user.get('role') == 'Admin',
            'can_approve': user.get('role') == 'Admin'
        }
    else:
        frontend_user = None
    
    response_data = {
        'message': 'Zeiterfassung App läuft!',
        'status': 'success',
        'environment': 'Azure' if os.getenv('WEBSITE_HOSTNAME') else 'Local',
        'user': frontend_user
    }
    
    return jsonify(response_data)

@app.route('/health')
def health():
    return jsonify({
        'status': 'healthy',
        'message': 'App ist bereit'
    })

print("✅ App bereit für gunicorn")
